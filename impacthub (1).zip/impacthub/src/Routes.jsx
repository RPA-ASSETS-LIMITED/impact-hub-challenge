import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import Header from "components/ui/Header";
import Homepage from "pages/homepage";
import SoftwareCatalog from "pages/software-catalog";
import SoftwareDetailApplication from "pages/software-detail-application";
import OrganizationVerification from "pages/organization-verification";
import NotFound from "pages/NotFound";

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <ScrollToTop />
        <Header />
        <RouterRoutes>
          <Route path="/" element={<Homepage />} />
          <Route path="/homepage" element={<Homepage />} />
          <Route path="/software-catalog" element={<SoftwareCatalog />} />
          <Route path="/software-detail-application" element={<SoftwareDetailApplication />} />
          <Route path="/organization-verification" element={<OrganizationVerification />} />
          <Route path="*" element={<NotFound />} />
        </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;