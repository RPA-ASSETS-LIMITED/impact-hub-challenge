import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

function ImplementationGuide({ implementation }) {
  const [activePhase, setActivePhase] = useState(0);

  // Mock implementation phases
  const implementationPhases = [
    {
      phase: 1,
      title: 'Planning & Preparation',
      duration: '3-5 days',
      description: 'Set up your account, define requirements, and prepare your data for migration.',
      tasks: [
        'Account setup and user provisioning',
        'Data audit and cleanup preparation',
        'Define user roles and permissions',
        'Schedule kickoff call with success manager',
        'Complete implementation checklist'
      ],
      deliverables: [
        'Configured Salesforce org',
        'User accounts created',
        'Implementation timeline',
        'Data migration plan'
      ],
      tips: [
        'Clean up your existing data before migration',
        'Identify key stakeholders early',
        'Set realistic expectations with your team'
      ]
    },
    {
      phase: 2,
      title: 'Data Migration & Setup',
      duration: '5-7 days',
      description: 'Import your existing data and configure the platform to match your workflows.',
      tasks: [
        'Export data from current systems',
        'Data mapping and transformation',
        'Import contacts, donors, and volunteers',
        'Configure custom fields and objects',
        'Set up automated workflows'
      ],
      deliverables: [
        'All data successfully migrated',
        'Custom fields configured',
        'Workflows activated',
        'Data validation report'
      ],
      tips: [
        'Start with a small data subset for testing',
        'Validate data accuracy before full import',
        'Keep backup of original data'
      ]
    },
    {
      phase: 3,
      title: 'Training & Onboarding',
      duration: '3-5 days',
      description: 'Train your team and customize the platform for your specific use cases.',
      tasks: [
        'Admin training sessions',
        'End-user training workshops',
        'Create custom reports and dashboards',
        'Set up integrations with other tools',
        'Configure security and access controls'
      ],
      deliverables: [
        'Trained admin users',
        'Custom dashboards created',
        'Integration setup complete',
        'User documentation'
      ],
      tips: [
        'Focus on core features first',
        'Record training sessions for future reference',
        'Create internal champions'
      ]
    },
    {
      phase: 4,
      title: 'Go-Live & Optimization',
      duration: '2-3 days',
      description: 'Launch the platform organization-wide and optimize based on initial usage.',
      tasks: [
        'Full team rollout',
        'Monitor system performance',
        'Gather user feedback',
        'Fine-tune configurations',
        'Plan ongoing optimization'
      ],
      deliverables: [
        'Platform fully operational',
        'Performance metrics baseline',
        'User feedback collected',
        'Optimization roadmap'
      ],
      tips: [
        'Start with a soft launch to key users',
        'Have support resources readily available',
        'Celebrate the successful launch'
      ]
    }
  ];

  const supportResources = [
    {
      title: 'Dedicated Success Manager',
      description: 'Personal guide throughout your implementation journey',
      icon: 'UserCheck',
      availability: 'Business hours support'
    },
    {
      title: 'Live Training Sessions',
      description: 'Interactive workshops tailored to your organization',
      icon: 'Video',
      availability: 'Weekly sessions available'
    },
    {
      title: 'Implementation Toolkit',
      description: 'Templates, checklists, and best practices guide',
      icon: 'FileText',
      availability: 'Immediate access'
    },
    {
      title: 'Community Forum',
      description: 'Connect with other nonprofits and share experiences',
      icon: 'MessageSquare',
      availability: '24/7 community support'
    },
    {
      title: 'Video Library',
      description: 'On-demand training videos and tutorials',
      icon: 'Play',
      availability: 'Self-paced learning'
    },
    {
      title: 'Data Migration Service',
      description: 'Professional assistance with complex data transfers',
      icon: 'Database',
      availability: 'Included in implementation'
    }
  ];

  const skillRequirements = [
    {
      skill: 'Basic Computer Skills',
      level: 'Required',
      description: 'Comfortable with web browsers and basic software navigation',
      color: 'success'
    },
    {
      skill: 'Data Management',
      level: 'Helpful',
      description: 'Understanding of spreadsheets and data organization',
      color: 'warning'
    },
    {
      skill: 'CRM Experience',
      level: 'Optional',
      description: 'Previous experience with customer relationship management systems',
      color: 'secondary'
    },
    {
      skill: 'Technical Administration',
      level: 'Optional',
      description: 'For advanced customization and integration setup',
      color: 'secondary'
    }
  ];

  const getSkillColor = (color) => {
    const colors = {
      success: 'bg-success-100 text-success-700 border-success-200',
      warning: 'bg-warning-100 text-warning-700 border-warning-200',
      secondary: 'bg-secondary-100 text-secondary-700 border-secondary-200'
    };
    return colors[color] || colors.secondary;
  };

  return (
    <div className="space-y-8">
      {/* Implementation Overview */}
      <div className="bg-gradient-to-br from-primary-50 to-secondary-50 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-text-primary mb-4">
          Implementation Overview
        </h3>
        <div className="grid md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Icon name="Clock" size={24} className="text-primary" />
            </div>
            <div className="text-2xl font-bold text-primary mb-1">
              {implementation.timeline}
            </div>
            <div className="text-sm text-text-secondary">Total Timeline</div>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-secondary-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Icon name="TrendingUp" size={24} className="text-secondary" />
            </div>
            <div className="text-2xl font-bold text-secondary mb-1">
              {implementation.technicalSkills}
            </div>
            <div className="text-sm text-text-secondary">Technical Skills</div>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-accent-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Icon name="Users" size={24} className="text-accent" />
            </div>
            <div className="text-2xl font-bold text-accent mb-1">
              Dedicated
            </div>
            <div className="text-sm text-text-secondary">Support Manager</div>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-trust-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Icon name="Award" size={24} className="text-trust" />
            </div>
            <div className="text-2xl font-bold text-trust mb-1">
              94%
            </div>
            <div className="text-sm text-text-secondary">Success Rate</div>
          </div>
        </div>
      </div>

      {/* Implementation Phases */}
      <div className="bg-white rounded-xl shadow-soft overflow-hidden">
        <div className="p-6 border-b border-border">
          <h3 className="text-xl font-semibold text-text-primary">
            Implementation Roadmap
          </h3>
          <p className="text-text-secondary mt-1">
            Step-by-step guide to get your organization up and running
          </p>
        </div>

        {/* Phase Navigation */}
        <div className="border-b border-border">
          <nav className="flex space-x-8 px-6" aria-label="Implementation phases">
            {implementationPhases.map((phase, index) => (
              <button
                key={phase.phase}
                onClick={() => setActivePhase(index)}
                className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200 ${
                  activePhase === index
                    ? 'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary hover:border-gray-300'
                }`}
              >
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                  activePhase === index
                    ? 'bg-primary text-white' :'bg-surface text-text-secondary'
                }`}>
                  {phase.phase}
                </div>
                <span>{phase.title}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Phase Content */}
        <div className="p-6">
          {implementationPhases[activePhase] && (
            <div className="space-y-6">
              <div>
                <div className="flex items-center space-x-4 mb-4">
                  <h4 className="text-xl font-semibold text-text-primary">
                    Phase {implementationPhases[activePhase].phase}: {implementationPhases[activePhase].title}
                  </h4>
                  <span className="px-3 py-1 bg-primary-100 text-primary text-sm font-medium rounded-full">
                    {implementationPhases[activePhase].duration}
                  </span>
                </div>
                <p className="text-text-secondary mb-6">
                  {implementationPhases[activePhase].description}
                </p>
              </div>

              <div className="grid lg:grid-cols-3 gap-6">
                {/* Tasks */}
                <div>
                  <h5 className="font-semibold text-text-primary mb-3 flex items-center space-x-2">
                    <Icon name="CheckSquare" size={18} className="text-primary" />
                    <span>Key Tasks</span>
                  </h5>
                  <ul className="space-y-2">
                    {implementationPhases[activePhase].tasks.map((task, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <Icon name="ArrowRight" size={14} className="text-text-muted mt-1 flex-shrink-0" />
                        <span className="text-sm text-text-secondary">{task}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Deliverables */}
                <div>
                  <h5 className="font-semibold text-text-primary mb-3 flex items-center space-x-2">
                    <Icon name="Package" size={18} className="text-secondary" />
                    <span>Deliverables</span>
                  </h5>
                  <ul className="space-y-2">
                    {implementationPhases[activePhase].deliverables.map((deliverable, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <Icon name="Check" size={14} className="text-secondary mt-1 flex-shrink-0" />
                        <span className="text-sm text-text-secondary">{deliverable}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Tips */}
                <div>
                  <h5 className="font-semibold text-text-primary mb-3 flex items-center space-x-2">
                    <Icon name="Lightbulb" size={18} className="text-accent" />
                    <span>Pro Tips</span>
                  </h5>
                  <ul className="space-y-2">
                    {implementationPhases[activePhase].tips.map((tip, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <Icon name="Star" size={14} className="text-accent mt-1 flex-shrink-0" />
                        <span className="text-sm text-text-secondary">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Skill Requirements */}
      <div className="bg-white rounded-xl shadow-soft p-6">
        <h3 className="text-xl font-semibold text-text-primary mb-4">
          Technical Skill Requirements
        </h3>
        <p className="text-text-secondary mb-6">
          Understanding what skills are needed helps ensure a smooth implementation
        </p>
        
        <div className="grid md:grid-cols-2 gap-4">
          {skillRequirements.map((skill, index) => (
            <div key={index} className="flex items-start space-x-4 p-4 rounded-lg border border-border">
              <div className={`px-3 py-1 rounded-full text-xs font-medium border ${getSkillColor(skill.color)}`}>
                {skill.level}
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-text-primary mb-1">{skill.skill}</h4>
                <p className="text-sm text-text-secondary">{skill.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Support Resources */}
      <div className="bg-white rounded-xl shadow-soft p-6">
        <h3 className="text-xl font-semibold text-text-primary mb-4">
          Available Support Resources
        </h3>
        <p className="text-text-secondary mb-6">
          You're not alone in this journey. Here's what's available to help you succeed
        </p>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {supportResources.map((resource, index) => (
            <div key={index} className="text-center p-4 rounded-lg border border-border hover:shadow-soft transition-all duration-200">
              <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                <Icon name={resource.icon} size={24} className="text-primary" />
              </div>
              <h4 className="font-semibold text-text-primary mb-2">{resource.title}</h4>
              <p className="text-sm text-text-secondary mb-3">{resource.description}</p>
              <span className="text-xs text-primary font-medium bg-primary-50 px-2 py-1 rounded-full">
                {resource.availability}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Success Stories */}
      <div className="bg-gradient-to-br from-secondary-50 to-accent-50 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-text-primary mb-4">
          Implementation Success Stories
        </h3>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg p-4">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 bg-secondary-100 rounded-full flex items-center justify-center">
                <Icon name="Heart" size={20} className="text-secondary" />
              </div>
              <div>
                <h4 className="font-semibold text-text-primary">Community Health Alliance</h4>
                <p className="text-sm text-text-secondary">Healthcare Nonprofit</p>
              </div>
            </div>
            <p className="text-sm text-text-secondary mb-3">
              "Implementation took exactly 2 weeks as promised. The data migration was seamless and our team was productive from day one."
            </p>
            <div className="flex items-center space-x-4 text-xs text-text-muted">
              <span>• 2 weeks implementation</span>
              <span>• 5,000+ contacts migrated</span>
              <span>• 15 users trained</span>
            </div>
          </div>
          
          <div className="bg-white rounded-lg p-4">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 bg-accent-100 rounded-full flex items-center justify-center">
                <Icon name="GraduationCap" size={20} className="text-accent" />
              </div>
              <div>
                <h4 className="font-semibold text-text-primary">Youth Education Foundation</h4>
                <p className="text-sm text-text-secondary">Education Nonprofit</p>
              </div>
            </div>
            <p className="text-sm text-text-secondary mb-3">
              "The success manager made all the difference. They understood our unique needs and configured everything perfectly."
            </p>
            <div className="flex items-center space-x-4 text-xs text-text-muted">
              <span>• 3 weeks implementation</span>
              <span>• Custom workflows</span>
              <span>• 25 users onboarded</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ImplementationGuide;