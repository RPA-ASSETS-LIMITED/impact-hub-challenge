import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

function SimilarToolsSection({ currentSoftware }) {
  // Mock similar tools data
  const similarTools = [
    {
      id: 'hubspot-nonprofit',
      name: 'HubSpot for Nonprofits',
      company: 'HubSpot',
      logo: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=200&h=200&fit=crop&crop=center',
      category: 'CRM & Marketing',
      originalPrice: 120,
      discountedPrice: 0,
      discountPercentage: 100,
      rating: 4.6,
      reviewCount: 89,
      description: 'All-in-one CRM, marketing, and sales platform designed for growing nonprofits.',
      keyFeatures: [
        'Contact Management',
        'Email Marketing',
        'Landing Pages',
        'Social Media Tools',
        'Analytics Dashboard'
      ],
      pros: [
        'Comprehensive marketing tools',
        'Easy to use interface',
        'Great integration ecosystem'
      ],
      cons: [
        'Can be overwhelming for small orgs',
        'Limited nonprofit-specific features'
      ]
    },
    {
      id: 'bloomerang-crm',
      name: 'Bloomerang',
      company: 'Bloomerang',
      logo: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=200&h=200&fit=crop&crop=center',
      category: 'Donor Management',
      originalPrice: 99,
      discountedPrice: 49,
      discountPercentage: 50,
      rating: 4.7,
      reviewCount: 156,
      description: 'Donor management software built specifically for nonprofits with retention focus.',
      keyFeatures: [
        'Donor Retention Analytics',
        'Automated Thank You Notes',
        'Wealth Screening',
        'Online Giving Forms',
        'Grant Tracking'
      ],
      pros: [
        'Built specifically for nonprofits',
        'Strong retention analytics',
        'Excellent customer support'
      ],
      cons: [
        'Limited volunteer management',
        'Fewer integrations than competitors'
      ]
    },
    {
      id: 'neoncrm',
      name: 'Neon CRM',
      company: 'Neon One',
      logo: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=200&h=200&fit=crop&crop=center',
      category: 'All-in-One Nonprofit',
      originalPrice: 89,
      discountedPrice: 29,
      discountPercentage: 67,
      rating: 4.4,
      reviewCount: 203,
      description: 'Complete nonprofit management platform with CRM, fundraising, and event tools.',
      keyFeatures: [
        'Donor Management',
        'Event Management',
        'Membership Tracking',
        'Online Fundraising',
        'Volunteer Coordination'
      ],
      pros: [
        'All-in-one solution',
        'Good value for money',
        'Strong event management'
      ],
      cons: [
        'Interface can feel dated',
        'Learning curve for advanced features'
      ]
    },
    {
      id: 'donorperfect',
      name: 'DonorPerfect',
      company: 'SofterWare',
      logo: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=200&h=200&fit=crop&crop=center',
      category: 'Fundraising Software',
      originalPrice: 79,
      discountedPrice: 39,
      discountPercentage: 51,
      rating: 4.3,
      reviewCount: 134,
      description: 'Comprehensive fundraising software with advanced reporting and donor analytics.',
      keyFeatures: [
        'Advanced Reporting',
        'Pledge Management',
        'Direct Mail Integration',
        'Grant Tracking',
        'Donor Analytics'
      ],
      pros: [
        'Powerful reporting capabilities',
        'Strong fundraising features',
        'Good customer training'
      ],
      cons: [
        'Complex setup process',
        'Limited modern integrations'
      ]
    }
  ];

  const comparisonFeatures = [
    'Donor Management',
    'Volunteer Management',
    'Grant Tracking',
    'Email Marketing',
    'Event Management',
    'Mobile App',
    'API Access',
    'Custom Reports'
  ];

  // Mock feature comparison data
  const getFeatureSupport = (toolId, feature) => {
    // Mock logic for feature support
    const supportMatrix = {
      'salesforce-nonprofit': {
        'Donor Management': 'full',
        'Volunteer Management': 'full',
        'Grant Tracking': 'full',
        'Email Marketing': 'full',
        'Event Management': 'partial',
        'Mobile App': 'full',
        'API Access': 'full',
        'Custom Reports': 'full'
      },
      'hubspot-nonprofit': {
        'Donor Management': 'full',
        'Volunteer Management': 'none',
        'Grant Tracking': 'none',
        'Email Marketing': 'full',
        'Event Management': 'partial',
        'Mobile App': 'full',
        'API Access': 'full',
        'Custom Reports': 'full'
      },
      'bloomerang-crm': {
        'Donor Management': 'full',
        'Volunteer Management': 'none',
        'Grant Tracking': 'partial',
        'Email Marketing': 'partial',
        'Event Management': 'none',
        'Mobile App': 'partial',
        'API Access': 'partial',
        'Custom Reports': 'full'
      },
      'neoncrm': {
        'Donor Management': 'full',
        'Volunteer Management': 'full',
        'Grant Tracking': 'partial',
        'Email Marketing': 'full',
        'Event Management': 'full',
        'Mobile App': 'partial',
        'API Access': 'partial',
        'Custom Reports': 'partial'
      },
      'donorperfect': {
        'Donor Management': 'full',
        'Volunteer Management': 'none',
        'Grant Tracking': 'full',
        'Email Marketing': 'partial',
        'Event Management': 'partial',
        'Mobile App': 'none',
        'API Access': 'partial',
        'Custom Reports': 'full'
      }
    };

    return supportMatrix[toolId]?.[feature] || 'none';
  };

  const getFeatureIcon = (support) => {
    switch (support) {
      case 'full':
        return <Icon name="CheckCircle" size={16} className="text-success" />;
      case 'partial':
        return <Icon name="MinusCircle" size={16} className="text-warning" />;
      case 'none':
        return <Icon name="XCircle" size={16} className="text-error" />;
      default:
        return <Icon name="HelpCircle" size={16} className="text-text-muted" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Similar Tools Grid */}
      <div>
        <h3 className="text-xl font-semibold text-text-primary mb-6">
          Similar Tools You Might Consider
        </h3>
        
        <div className="grid md:grid-cols-2 gap-6">
          {similarTools.map((tool) => (
            <div key={tool.id} className="bg-white rounded-xl shadow-soft border border-border p-6 hover:shadow-medium transition-all duration-300">
              {/* Tool Header */}
              <div className="flex items-start space-x-4 mb-4">
                <div className="w-12 h-12 bg-white rounded-lg shadow-soft p-2 flex-shrink-0">
                  <Image
                    src={tool.logo}
                    alt={`${tool.name} logo`}
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-text-primary mb-1">
                    {tool.name}
                  </h4>
                  <p className="text-sm text-text-secondary mb-2">
                    by {tool.company}
                  </p>
                  <div className="flex items-center space-x-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Icon
                          key={i}
                          name="Star"
                          size={14}
                          className={i < Math.floor(tool.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-text-secondary">
                      {tool.rating} ({tool.reviewCount})
                    </span>
                  </div>
                </div>
              </div>

              {/* Pricing */}
              <div className="mb-4">
                <div className="flex items-center space-x-2 mb-2">
                  {tool.discountedPrice === 0 ? (
                    <>
                      <span className="text-xl font-bold text-secondary">FREE</span>
                      <span className="text-sm line-through text-text-muted">
                        ${tool.originalPrice}/mo
                      </span>
                    </>
                  ) : (
                    <>
                      <span className="text-xl font-bold text-primary">
                        ${tool.discountedPrice}/mo
                      </span>
                      <span className="text-sm line-through text-text-muted">
                        ${tool.originalPrice}/mo
                      </span>
                    </>
                  )}
                  <span className="px-2 py-1 bg-accent-100 text-accent text-xs font-bold rounded-full">
                    {tool.discountPercentage}% OFF
                  </span>
                </div>
                <span className="px-2 py-1 bg-secondary-100 text-secondary text-xs font-medium rounded-full">
                  {tool.category}
                </span>
              </div>

              {/* Description */}
              <p className="text-sm text-text-secondary mb-4">
                {tool.description}
              </p>

              {/* Key Features */}
              <div className="mb-4">
                <h5 className="font-medium text-text-primary mb-2">Key Features:</h5>
                <div className="flex flex-wrap gap-1">
                  {tool.keyFeatures.slice(0, 3).map((feature, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-surface text-text-secondary text-xs rounded-full"
                    >
                      {feature}
                    </span>
                  ))}
                  {tool.keyFeatures.length > 3 && (
                    <span className="px-2 py-1 bg-surface text-text-secondary text-xs rounded-full">
                      +{tool.keyFeatures.length - 3} more
                    </span>
                  )}
                </div>
              </div>

              {/* Quick Pros/Cons */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <h6 className="text-xs font-medium text-success mb-1">Pros:</h6>
                  <ul className="space-y-1">
                    {tool.pros.slice(0, 2).map((pro, index) => (
                      <li key={index} className="text-xs text-text-secondary flex items-start space-x-1">
                        <Icon name="Plus" size={10} className="text-success mt-0.5 flex-shrink-0" />
                        <span>{pro}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h6 className="text-xs font-medium text-warning mb-1">Cons:</h6>
                  <ul className="space-y-1">
                    {tool.cons.slice(0, 2).map((con, index) => (
                      <li key={index} className="text-xs text-text-secondary flex items-start space-x-1">
                        <Icon name="Minus" size={10} className="text-warning mt-0.5 flex-shrink-0" />
                        <span>{con}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* CTA */}
              <Link
                to="/software-detail-application"
                className="btn-secondary w-full text-center text-sm py-2"
              >
                View Details
              </Link>
            </div>
          ))}
        </div>
      </div>

      {/* Feature Comparison Table */}
      <div className="bg-white rounded-xl shadow-soft overflow-hidden">
        <div className="p-6 border-b border-border">
          <h3 className="text-xl font-semibold text-text-primary">
            Feature Comparison
          </h3>
          <p className="text-text-secondary mt-1">
            Compare key features across similar platforms
          </p>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-surface">
              <tr>
                <th className="text-left p-4 font-medium text-text-primary">Feature</th>
                <th className="text-center p-4 font-medium text-text-primary">
                  {currentSoftware.name}
                  <div className="text-xs text-primary font-normal mt-1">Current</div>
                </th>
                {similarTools.slice(0, 3).map((tool) => (
                  <th key={tool.id} className="text-center p-4 font-medium text-text-primary min-w-32">
                    <div className="text-sm">{tool.name}</div>
                    <div className="text-xs text-text-secondary font-normal mt-1">
                      {tool.discountedPrice === 0 ? 'FREE' : `$${tool.discountedPrice}/mo`}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {comparisonFeatures.map((feature, index) => (
                <tr key={feature} className={index % 2 === 0 ? 'bg-white' : 'bg-surface'}>
                  <td className="p-4 font-medium text-text-primary">{feature}</td>
                  <td className="p-4 text-center">
                    {getFeatureIcon(getFeatureSupport(currentSoftware.id, feature))}
                  </td>
                  {similarTools.slice(0, 3).map((tool) => (
                    <td key={tool.id} className="p-4 text-center">
                      {getFeatureIcon(getFeatureSupport(tool.id, feature))}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="p-4 bg-surface border-t border-border">
          <div className="flex items-center justify-center space-x-6 text-sm">
            <div className="flex items-center space-x-2">
              <Icon name="CheckCircle" size={16} className="text-success" />
              <span className="text-text-secondary">Full Support</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="MinusCircle" size={16} className="text-warning" />
              <span className="text-text-secondary">Partial Support</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="XCircle" size={16} className="text-error" />
              <span className="text-text-secondary">Not Available</span>
            </div>
          </div>
        </div>
      </div>

      {/* Why Choose Current Software */}
      <div className="bg-gradient-to-br from-primary-50 to-secondary-50 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-text-primary mb-4">
          Why Choose {currentSoftware.name}?
        </h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Icon name="Award" size={24} className="text-primary" />
            </div>
            <h4 className="font-semibold text-text-primary mb-2">Industry Leader</h4>
            <p className="text-sm text-text-secondary">
              Most comprehensive nonprofit-specific features and proven track record
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-secondary-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Icon name="Users" size={24} className="text-secondary" />
            </div>
            <h4 className="font-semibold text-text-primary mb-2">Community Support</h4>
            <p className="text-sm text-text-secondary">
              Large community of nonprofit users and extensive training resources
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-accent-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Icon name="Zap" size={24} className="text-accent" />
            </div>
            <h4 className="font-semibold text-text-primary mb-2">Scalability</h4>
            <p className="text-sm text-text-secondary">
              Grows with your organization from startup to enterprise level
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SimilarToolsSection;