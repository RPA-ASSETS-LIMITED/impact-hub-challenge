import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

function ReviewsSection({ softwareId }) {
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [sortBy, setSortBy] = useState('newest');

  // Mock reviews data
  const reviews = [
    {
      id: 1,
      reviewer: {
        name: 'Sarah Chen',
        title: 'Executive Director',
        organization: 'Community Health Alliance',
        organizationType: 'Healthcare Nonprofit',
        organizationSize: '50-100 employees',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face'
      },
      rating: 5,
      date: '2024-01-15',
      verified: true,
      title: 'Transformed our donor management completely',
      content: `We've been using this platform for 8 months now and it's completely transformed how we manage our donors and volunteers. The automation features have saved us countless hours each week, and the reporting capabilities give us insights we never had before.

The implementation was smoother than expected - their nonprofit success manager walked us through everything and helped us migrate our data from our old spreadsheet system. The training materials are excellent and our team was up and running within two weeks.

What I love most is how it's designed specifically for nonprofits. Features like grant tracking and volunteer management aren't afterthoughts - they're core to the platform. Our donor retention has increased by 25% since implementation.`,
      helpful: 23,
      implementationTime: '2 weeks',
      wouldRecommend: true,
      pros: [
        'Excellent nonprofit-specific features','Outstanding customer support','Intuitive user interface','Powerful reporting capabilities'
      ],
      cons: [
        'Learning curve for advanced features','Mobile app could be improved'
      ]
    },
    {
      id: 2,
      reviewer: {
        name: 'Marcus Rodriguez',title: 'Operations Manager',organization: 'Youth Education Foundation',organizationType: 'Education Nonprofit',organizationSize: '25-50 employees',avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face'
      },
      rating: 4,
      date: '2024-01-08',
      verified: true,
      title: 'Great value for nonprofits, some limitations',
      content: `Overall very satisfied with this solution. Coming from a more expensive CRM, this has most of the features we need at a fraction of the cost. The donor management and email marketing tools work well for our needs.

Setup took about 3 weeks due to some data migration challenges, but their support team was responsive. The platform handles our 5,000+ contacts without any performance issues.

A few features we miss from our previous system, particularly around advanced workflow automation, but for the price point (free for us!), it's an excellent value. Perfect for small to medium nonprofits.`,
      helpful: 18,
      implementationTime: '3 weeks',
      wouldRecommend: true,
      pros: [
        'Excellent value for money',
        'Reliable performance',
        'Good integration options',
        'Responsive support team'
      ],
      cons: [
        'Limited advanced automation',
        'Reporting could be more flexible',
        'Some UI elements feel dated'
      ]
    },
    {
      id: 3,
      reviewer: {
        name: 'Jennifer Walsh',
        title: 'Development Coordinator',
        organization: 'Animal Rescue Network',
        organizationType: 'Animal Welfare',
        organizationSize: '10-25 employees',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face'
      },
      rating: 5,
      date: '2023-12-20',
      verified: true,
      title: 'Perfect for small nonprofits',
      content: `As a small animal rescue, we needed something powerful but not overwhelming. This platform hits the sweet spot perfectly. We can track our adopters, volunteers, and donors all in one place.

The volunteer management features are particularly strong - we can schedule shifts, track hours, and communicate with our 200+ volunteers seamlessly. The mobile app works well for our field volunteers too.

Implementation was straightforward - took us about 10 days to get everything set up and trained. The fact that it's free for nonprofits like us is incredible. We're saving over $2,000 per year compared to our old system.`,
      helpful: 15,
      implementationTime: '10 days',
      wouldRecommend: true,
      pros: [
        'Perfect for small organizations',
        'Strong volunteer management',
        'Easy to learn and use',
        'Great mobile experience'
      ],
      cons: [
        'Limited customization options',
        'Could use more integrations'
      ]
    },
    {
      id: 4,
      reviewer: {
        name: 'David Kim',
        title: 'Program Director',
        organization: 'Environmental Action Coalition',
        organizationType: 'Environmental Nonprofit',
        organizationSize: '100+ employees',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face'
      },
      rating: 4,
      date: '2023-12-10',
      verified: true,
      title: 'Solid platform with room for improvement',
      content: `We've been using this for about a year now across multiple programs. It handles our complex donor relationships well and the grant tracking features have streamlined our reporting process significantly.

The platform scales well - we have over 15,000 contacts and multiple user groups without performance issues. Integration with our accounting software was seamless.

Some areas for improvement: the user interface could be more modern, and we'd love to see more advanced analytics features. But overall, it's a solid platform that meets our needs and the price point is unbeatable.`,
      helpful: 12,
      implementationTime: '4 weeks',
      wouldRecommend: true,
      pros: [
        'Scales well for larger organizations','Strong grant tracking features','Good integration capabilities','Reliable uptime'
      ],
      cons: [
        'Interface feels outdated','Limited advanced analytics','Customization can be complex'
      ]
    }
  ];

  const filterOptions = [
    { value: 'all', label: 'All Reviews' },
    { value: 'Healthcare Nonprofit', label: 'Healthcare' },
    { value: 'Education Nonprofit', label: 'Education' },
    { value: 'Animal Welfare', label: 'Animal Welfare' },
    { value: 'Environmental Nonprofit', label: 'Environmental' }
  ];

  const sortOptions = [
    { value: 'newest', label: 'Newest First' },
    { value: 'oldest', label: 'Oldest First' },
    { value: 'highest', label: 'Highest Rated' },
    { value: 'lowest', label: 'Lowest Rated' },
    { value: 'helpful', label: 'Most Helpful' }
  ];

  const filteredReviews = reviews.filter(review => 
    selectedFilter === 'all' || review.reviewer.organizationType === selectedFilter
  );

  const sortedReviews = [...filteredReviews].sort((a, b) => {
    switch (sortBy) {
      case 'newest':
        return new Date(b.date) - new Date(a.date);
      case 'oldest':
        return new Date(a.date) - new Date(b.date);
      case 'highest':
        return b.rating - a.rating;
      case 'lowest':
        return a.rating - b.rating;
      case 'helpful':
        return b.helpful - a.helpful;
      default:
        return 0;
    }
  });

  const averageRating = reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length;
  const ratingDistribution = [5, 4, 3, 2, 1].map(rating => ({
    rating,
    count: reviews.filter(review => review.rating === rating).length,
    percentage: (reviews.filter(review => review.rating === rating).length / reviews.length) * 100
  }));

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-8">
      {/* Rating Summary */}
      <div className="bg-gradient-to-br from-primary-50 to-secondary-50 rounded-xl p-6">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Overall Rating */}
          <div className="text-center">
            <div className="text-4xl font-bold text-primary mb-2">
              {averageRating.toFixed(1)}
            </div>
            <div className="flex items-center justify-center mb-2">
              {[...Array(5)].map((_, i) => (
                <Icon
                  key={i}
                  name="Star"
                  size={20}
                  className={i < Math.floor(averageRating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}
                />
              ))}
            </div>
            <p className="text-text-secondary">
              Based on {reviews.length} verified reviews
            </p>
          </div>

          {/* Rating Distribution */}
          <div className="space-y-2">
            {ratingDistribution.map(({ rating, count, percentage }) => (
              <div key={rating} className="flex items-center space-x-3">
                <span className="text-sm font-medium text-text-primary w-8">
                  {rating}★
                </span>
                <div className="flex-1 bg-white rounded-full h-2">
                  <div
                    className="bg-yellow-400 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
                <span className="text-sm text-text-secondary w-8">
                  {count}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Filters and Sort */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center space-x-4">
          <label className="text-sm font-medium text-text-primary">Filter by:</label>
          <select
            value={selectedFilter}
            onChange={(e) => setSelectedFilter(e.target.value)}
            className="input-field py-2 text-sm"
          >
            {filterOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center space-x-4">
          <label className="text-sm font-medium text-text-primary">Sort by:</label>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="input-field py-2 text-sm"
          >
            {sortOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Reviews List */}
      <div className="space-y-6">
        {sortedReviews.map((review) => (
          <div key={review.id} className="bg-white rounded-xl shadow-soft p-6 border border-border">
            {/* Review Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start space-x-4">
                <Image
                  src={review.reviewer.avatar}
                  alt={review.reviewer.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <h4 className="font-semibold text-text-primary">
                      {review.reviewer.name}
                    </h4>
                    {review.verified && (
                      <div className="flex items-center space-x-1 px-2 py-1 bg-success-100 text-success-700 text-xs font-medium rounded-full">
                        <Icon name="CheckCircle" size={12} />
                        <span>Verified</span>
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-text-secondary">
                    {review.reviewer.title} at {review.reviewer.organization}
                  </p>
                  <p className="text-xs text-text-muted">
                    {review.reviewer.organizationType} • {review.reviewer.organizationSize}
                  </p>
                </div>
              </div>
              
              <div className="text-right">
                <div className="flex items-center space-x-1 mb-1">
                  {[...Array(5)].map((_, i) => (
                    <Icon
                      key={i}
                      name="Star"
                      size={16}
                      className={i < review.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}
                    />
                  ))}
                </div>
                <p className="text-xs text-text-muted">
                  {formatDate(review.date)}
                </p>
              </div>
            </div>

            {/* Review Content */}
            <div className="mb-4">
              <h5 className="font-semibold text-text-primary mb-2">
                {review.title}
              </h5>
              <div className="prose prose-sm max-w-none text-text-secondary">
                <p className="mb-4">{review.content}</p>
              </div>
            </div>

            {/* Pros and Cons */}
            <div className="grid md:grid-cols-2 gap-6 mb-4">
              <div>
                <h6 className="font-medium text-text-primary mb-2 flex items-center space-x-2">
                  <Icon name="ThumbsUp" size={16} className="text-success" />
                  <span>Pros</span>
                </h6>
                <ul className="space-y-1">
                  {review.pros.map((pro, index) => (
                    <li key={index} className="text-sm text-text-secondary flex items-start space-x-2">
                      <Icon name="Plus" size={12} className="text-success mt-1 flex-shrink-0" />
                      <span>{pro}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h6 className="font-medium text-text-primary mb-2 flex items-center space-x-2">
                  <Icon name="ThumbsDown" size={16} className="text-warning" />
                  <span>Cons</span>
                </h6>
                <ul className="space-y-1">
                  {review.cons.map((con, index) => (
                    <li key={index} className="text-sm text-text-secondary flex items-start space-x-2">
                      <Icon name="Minus" size={12} className="text-warning mt-1 flex-shrink-0" />
                      <span>{con}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Review Footer */}
            <div className="flex items-center justify-between pt-4 border-t border-border">
              <div className="flex items-center space-x-6 text-sm text-text-secondary">
                <span>Implementation: {review.implementationTime}</span>
                {review.wouldRecommend && (
                  <div className="flex items-center space-x-1 text-success">
                    <Icon name="CheckCircle" size={14} />
                    <span>Would recommend</span>
                  </div>
                )}
              </div>
              
              <button className="flex items-center space-x-2 text-sm text-text-secondary hover:text-primary transition-colors duration-200">
                <Icon name="ThumbsUp" size={14} />
                <span>Helpful ({review.helpful})</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Load More */}
      <div className="text-center">
        <button className="btn-secondary px-8 py-3">
          Load More Reviews
        </button>
      </div>
    </div>
  );
}

export default ReviewsSection;