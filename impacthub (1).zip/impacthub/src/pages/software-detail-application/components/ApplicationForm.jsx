import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

function ApplicationForm({ software, onClose, onSubmit }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    // Organization Details
    organizationName: '',
    organizationType: '',
    taxId: '',
    website: '',
    yearEstablished: '',
    annualBudget: '',
    
    // Contact Information
    contactName: '',
    contactTitle: '',
    contactEmail: '',
    contactPhone: '',
    
    // Use Case
    currentSolution: '',
    intendedUse: '',
    expectedUsers: '',
    implementationTimeline: '',
    
    // Supporting Documents
    taxExemptDocument: null,
    organizationProfile: null
  });

  const [errors, setErrors] = useState({});
  const totalSteps = 4;

  const organizationTypes = [
    '501(c)(3) Nonprofit',
    'Social Enterprise',
    'Community Organization',
    'Educational Institution',
    'Religious Organization',
    'Other'
  ];

  const budgetRanges = [
    'Under $100K',
    '$100K - $500K',
    '$500K - $1M',
    '$1M - $5M',
    '$5M - $10M',
    'Over $10M'
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateStep = (step) => {
    const newErrors = {};
    
    switch (step) {
      case 1:
        if (!formData.organizationName) newErrors.organizationName = 'Organization name is required';
        if (!formData.organizationType) newErrors.organizationType = 'Organization type is required';
        if (!formData.taxId) newErrors.taxId = 'Tax ID is required';
        if (!formData.website) newErrors.website = 'Website is required';
        break;
      case 2:
        if (!formData.contactName) newErrors.contactName = 'Contact name is required';
        if (!formData.contactEmail) newErrors.contactEmail = 'Email is required';
        if (!formData.contactPhone) newErrors.contactPhone = 'Phone number is required';
        break;
      case 3:
        if (!formData.intendedUse) newErrors.intendedUse = 'Please describe your intended use';
        if (!formData.expectedUsers) newErrors.expectedUsers = 'Expected number of users is required';
        break;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, totalSteps));
    }
  };

  const handlePrevious = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateStep(currentStep)) {
      onSubmit(formData);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-text-primary mb-4">
              Organization Details
            </h3>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Organization Name *
                </label>
                <input
                  type="text"
                  value={formData.organizationName}
                  onChange={(e) => handleInputChange('organizationName', e.target.value)}
                  className={`input-field ${errors.organizationName ? 'border-error' : ''}`}
                  placeholder="Enter your organization name"
                />
                {errors.organizationName && (
                  <p className="text-error text-sm mt-1">{errors.organizationName}</p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Organization Type *
                </label>
                <select
                  value={formData.organizationType}
                  onChange={(e) => handleInputChange('organizationType', e.target.value)}
                  className={`input-field ${errors.organizationType ? 'border-error' : ''}`}
                >
                  <option value="">Select organization type</option>
                  {organizationTypes.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
                {errors.organizationType && (
                  <p className="text-error text-sm mt-1">{errors.organizationType}</p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Tax ID / EIN *
                </label>
                <input
                  type="text"
                  value={formData.taxId}
                  onChange={(e) => handleInputChange('taxId', e.target.value)}
                  className={`input-field ${errors.taxId ? 'border-error' : ''}`}
                  placeholder="XX-XXXXXXX"
                />
                {errors.taxId && (
                  <p className="text-error text-sm mt-1">{errors.taxId}</p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Website *
                </label>
                <input
                  type="url"
                  value={formData.website}
                  onChange={(e) => handleInputChange('website', e.target.value)}
                  className={`input-field ${errors.website ? 'border-error' : ''}`}
                  placeholder="https://yourorganization.org"
                />
                {errors.website && (
                  <p className="text-error text-sm mt-1">{errors.website}</p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Year Established
                </label>
                <input
                  type="number"
                  value={formData.yearEstablished}
                  onChange={(e) => handleInputChange('yearEstablished', e.target.value)}
                  className="input-field"
                  placeholder="2020"
                  min="1900"
                  max={new Date().getFullYear()}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Annual Budget
                </label>
                <select
                  value={formData.annualBudget}
                  onChange={(e) => handleInputChange('annualBudget', e.target.value)}
                  className="input-field"
                >
                  <option value="">Select budget range</option>
                  {budgetRanges.map(range => (
                    <option key={range} value={range}>{range}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-text-primary mb-4">
              Primary Contact Information
            </h3>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={formData.contactName}
                  onChange={(e) => handleInputChange('contactName', e.target.value)}
                  className={`input-field ${errors.contactName ? 'border-error' : ''}`}
                  placeholder="John Doe"
                />
                {errors.contactName && (
                  <p className="text-error text-sm mt-1">{errors.contactName}</p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Job Title
                </label>
                <input
                  type="text"
                  value={formData.contactTitle}
                  onChange={(e) => handleInputChange('contactTitle', e.target.value)}
                  className="input-field"
                  placeholder="Executive Director"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={formData.contactEmail}
                  onChange={(e) => handleInputChange('contactEmail', e.target.value)}
                  className={`input-field ${errors.contactEmail ? 'border-error' : ''}`}
                  placeholder="john@organization.org"
                />
                {errors.contactEmail && (
                  <p className="text-error text-sm mt-1">{errors.contactEmail}</p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  value={formData.contactPhone}
                  onChange={(e) => handleInputChange('contactPhone', e.target.value)}
                  className={`input-field ${errors.contactPhone ? 'border-error' : ''}`}
                  placeholder="(555) 123-4567"
                />
                {errors.contactPhone && (
                  <p className="text-error text-sm mt-1">{errors.contactPhone}</p>
                )}
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-text-primary mb-4">
              Use Case & Requirements
            </h3>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Current Solution (if any)
                </label>
                <input
                  type="text"
                  value={formData.currentSolution}
                  onChange={(e) => handleInputChange('currentSolution', e.target.value)}
                  className="input-field"
                  placeholder="Excel spreadsheets, Google Sheets, etc."
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  How do you plan to use {software.name}? *
                </label>
                <textarea
                  value={formData.intendedUse}
                  onChange={(e) => handleInputChange('intendedUse', e.target.value)}
                  className={`input-field ${errors.intendedUse ? 'border-error' : ''}`}
                  rows={4}
                  placeholder="Describe your specific use case, goals, and expected outcomes..."
                />
                {errors.intendedUse && (
                  <p className="text-error text-sm mt-1">{errors.intendedUse}</p>
                )}
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    Expected Number of Users *
                  </label>
                  <select
                    value={formData.expectedUsers}
                    onChange={(e) => handleInputChange('expectedUsers', e.target.value)}
                    className={`input-field ${errors.expectedUsers ? 'border-error' : ''}`}
                  >
                    <option value="">Select user count</option>
                    <option value="1-5">1-5 users</option>
                    <option value="6-10">6-10 users</option>
                    <option value="11-25">11-25 users</option>
                    <option value="26-50">26-50 users</option>
                    <option value="51-100">51-100 users</option>
                    <option value="100+">100+ users</option>
                  </select>
                  {errors.expectedUsers && (
                    <p className="text-error text-sm mt-1">{errors.expectedUsers}</p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    Implementation Timeline
                  </label>
                  <select
                    value={formData.implementationTimeline}
                    onChange={(e) => handleInputChange('implementationTimeline', e.target.value)}
                    className="input-field"
                  >
                    <option value="">Select timeline</option>
                    <option value="immediate">Immediate (within 1 week)</option>
                    <option value="1-month">Within 1 month</option>
                    <option value="1-3-months">1-3 months</option>
                    <option value="3-6-months">3-6 months</option>
                    <option value="6-months+">6+ months</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-text-primary mb-4">
              Supporting Documents
            </h3>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Tax Exemption Document (Required)
                </label>
                <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                  <Icon name="Upload" size={32} className="text-text-muted mx-auto mb-2" />
                  <p className="text-text-secondary mb-2">
                    Upload your 501(c)(3) determination letter or equivalent
                  </p>
                  <input
                    type="file"
                    accept=".pdf,.jpg,.jpeg,.png"
                    onChange={(e) => handleInputChange('taxExemptDocument', e.target.files[0])}
                    className="hidden"
                    id="tax-document"
                  />
                  <label
                    htmlFor="tax-document"
                    className="btn-secondary cursor-pointer inline-block"
                  >
                    Choose File
                  </label>
                  {formData.taxExemptDocument && (
                    <p className="text-sm text-success mt-2">
                      ✓ {formData.taxExemptDocument.name}
                    </p>
                  )}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Organization Profile (Optional)
                </label>
                <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                  <Icon name="FileText" size={32} className="text-text-muted mx-auto mb-2" />
                  <p className="text-text-secondary mb-2">
                    Upload annual report, brochure, or organization overview
                  </p>
                  <input
                    type="file"
                    accept=".pdf,.doc,.docx"
                    onChange={(e) => handleInputChange('organizationProfile', e.target.files[0])}
                    className="hidden"
                    id="org-profile"
                  />
                  <label
                    htmlFor="org-profile"
                    className="btn-secondary cursor-pointer inline-block"
                  >
                    Choose File
                  </label>
                  {formData.organizationProfile && (
                    <p className="text-sm text-success mt-2">
                      ✓ {formData.organizationProfile.name}
                    </p>
                  )}
                </div>
              </div>
            </div>
            
            <div className="bg-primary-50 rounded-lg p-4">
              <h4 className="font-semibold text-primary mb-2">What happens next?</h4>
              <ul className="text-sm text-primary-700 space-y-1">
                <li>• We'll review your application within 2-3 business days</li>
                <li>• You'll receive an email confirmation with next steps</li>
                <li>• Upon approval, you'll get access credentials and setup instructions</li>
                <li>• Our team will schedule an onboarding call to help you get started</li>
              </ul>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-strong max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <h2 className="text-2xl font-bold text-text-primary">
              Apply for {software.name}
            </h2>
            <p className="text-text-secondary">
              Step {currentStep} of {totalSteps}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-surface rounded-lg transition-colors duration-200"
          >
            <Icon name="X" size={24} className="text-text-secondary" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="px-6 py-4 bg-surface">
          <div className="flex items-center space-x-2">
            {[...Array(totalSteps)].map((_, index) => (
              <div
                key={index}
                className={`flex-1 h-2 rounded-full transition-colors duration-300 ${
                  index + 1 <= currentStep ? 'bg-primary' : 'bg-border'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {renderStepContent()}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-border bg-surface">
          <button
            onClick={handlePrevious}
            disabled={currentStep === 1}
            className={`px-6 py-2 rounded-lg font-medium transition-colors duration-200 ${
              currentStep === 1
                ? 'text-text-muted cursor-not-allowed' :'text-text-secondary hover:text-text-primary hover:bg-white'
            }`}
          >
            Previous
          </button>
          
          <div className="flex items-center space-x-3">
            {currentStep < totalSteps ? (
              <button
                onClick={handleNext}
                className="btn-primary px-8 py-2"
              >
                Next
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                className="btn-primary px-8 py-2"
              >
                Submit Application
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default ApplicationForm;