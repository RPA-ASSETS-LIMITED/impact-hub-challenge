import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Image from '../../components/AppImage';
import ApplicationForm from './components/ApplicationForm';
import ReviewsSection from './components/ReviewsSection';
import SimilarToolsSection from './components/SimilarToolsSection';
import ImplementationGuide from './components/ImplementationGuide';

function SoftwareDetailApplication() {
  const [activeTab, setActiveTab] = useState('overview');
  const [isApplicationOpen, setIsApplicationOpen] = useState(false);
  const [applicationStatus, setApplicationStatus] = useState('not-started'); // not-started, in-progress, submitted, approved

  // Mock software data
  const softwareData = {
    id: 'salesforce-nonprofit',
    name: 'Salesforce Nonprofit Cloud',
    company: 'Salesforce',
    logo: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=200&h=200&fit=crop&crop=center',
    category: 'CRM & Donor Management',
    originalPrice: 150,
    discountedPrice: 0,
    discountPercentage: 100,
    rating: 4.8,
    reviewCount: 127,
    description: `Salesforce Nonprofit Cloud is the world's #1 CRM platform designed specifically for nonprofits. It helps organizations manage donors, volunteers, programs, and outcomes all in one integrated platform. With powerful automation, reporting, and collaboration tools, nonprofits can focus more on their mission and less on administrative tasks.

Built on the trusted Salesforce platform, Nonprofit Cloud provides enterprise-grade security, scalability, and reliability that growing organizations need. The platform includes specialized features for grant management, volunteer coordination, program tracking, and donor stewardship.`,
    keyFeatures: [
      'Donor & Constituent Management','Volunteer Management','Grant & Program Tracking','Fundraising Campaign Management','Automated Workflows','Custom Reporting & Dashboards','Email Marketing Integration','Mobile Access','Third-party Integrations','Advanced Security & Compliance'
    ],
    benefits: [
      'Increase donor retention by 35%','Reduce administrative time by 40%','Improve volunteer engagement by 50%','Streamline grant reporting processes','Better program outcome tracking'
    ],
    implementation: {
      timeline: '2-4 weeks',technicalSkills: 'Basic to Intermediate',support: 'Dedicated nonprofit success manager',training: 'Free online training modules + live sessions',dataImport: 'Assisted migration from existing systems'
    },
    eligibility: [
      '501(c)(3) tax-exempt status','Annual budget under $10M','Mission-driven organization','Commitment to 12-month usage'
    ],
    demoVideo: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    successMetrics: {
      totalSavings: '$1.8M',organizationsServed: 847,averageROI: '340%',implementationSuccess: '94%'
    }
  };

  const tabs = [
    { id: 'overview', name: 'Overview', icon: 'FileText' },
    { id: 'features', name: 'Features', icon: 'Star' },
    { id: 'implementation', name: 'Implementation', icon: 'Settings' },
    { id: 'reviews', name: 'Reviews', icon: 'MessageSquare' },
    { id: 'similar', name: 'Similar Tools', icon: 'Grid3X3' }
  ];

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleApplicationSubmit = (formData) => {
    setApplicationStatus('submitted');
    setIsApplicationOpen(false);
    // Mock submission logic
    setTimeout(() => {
      setApplicationStatus('approved');
    }, 3000);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-8">
            {/* Demo Video */}
            <div className="bg-white rounded-xl shadow-soft overflow-hidden">
              <div className="p-6 border-b border-border">
                <h3 className="text-xl font-semibold text-text-primary mb-2">
                  See {softwareData.name} in Action
                </h3>
                <p className="text-text-secondary">
                  Watch how nonprofits like yours are using this platform to amplify their impact
                </p>
              </div>
              <div className="aspect-video bg-gray-100">
                <iframe
                  width="100%"
                  height="100%"
                  src={softwareData.demoVideo}
                  title={`${softwareData.name} Demo`}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="w-full h-full"
                ></iframe>
              </div>
            </div>

            {/* Description */}
            <div className="bg-white rounded-xl shadow-soft p-6">
              <h3 className="text-xl font-semibold text-text-primary mb-4">About This Solution</h3>
              <div className="prose prose-lg max-w-none text-text-secondary">
                <p className="mb-4">{softwareData.description}</p>
              </div>
            </div>

            {/* Key Benefits */}
            <div className="bg-white rounded-xl shadow-soft p-6">
              <h3 className="text-xl font-semibold text-text-primary mb-4">Key Benefits</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {softwareData.benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-secondary-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Icon name="Check" size={14} className="text-secondary" />
                    </div>
                    <span className="text-text-secondary">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Success Metrics */}
            <div className="bg-gradient-to-br from-primary-50 to-secondary-50 rounded-xl p-6">
              <h3 className="text-xl font-semibold text-text-primary mb-6">Impact Metrics</h3>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary mb-1">
                    {softwareData.successMetrics.totalSavings}
                  </div>
                  <div className="text-sm text-text-secondary">Total Savings</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-secondary mb-1">
                    {softwareData.successMetrics.organizationsServed}
                  </div>
                  <div className="text-sm text-text-secondary">Organizations Served</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-accent mb-1">
                    {softwareData.successMetrics.averageROI}
                  </div>
                  <div className="text-sm text-text-secondary">Average ROI</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-trust mb-1">
                    {softwareData.successMetrics.implementationSuccess}
                  </div>
                  <div className="text-sm text-text-secondary">Success Rate</div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'features':
        return (
          <div className="bg-white rounded-xl shadow-soft p-6">
            <h3 className="text-xl font-semibold text-text-primary mb-6">Complete Feature Set</h3>
            <div className="grid md:grid-cols-2 gap-4">
              {softwareData.keyFeatures.map((feature, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-surface transition-colors duration-200">
                  <div className="w-8 h-8 bg-primary-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon name="Check" size={16} className="text-primary" />
                  </div>
                  <span className="text-text-primary font-medium">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        );

      case 'implementation':
        return <ImplementationGuide implementation={softwareData.implementation} />;

      case 'reviews':
        return <ReviewsSection softwareId={softwareData.id} />;

      case 'similar':
        return <SimilarToolsSection currentSoftware={softwareData} />;

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background pt-32 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <nav className="flex items-center space-x-2 text-sm text-text-secondary mb-8">
          <Link to="/homepage" className="hover:text-primary transition-colors duration-200">
            Home
          </Link>
          <Icon name="ChevronRight" size={16} />
          <Link to="/software-catalog" className="hover:text-primary transition-colors duration-200">
            Software Catalog
          </Link>
          <Icon name="ChevronRight" size={16} />
          <span className="text-text-primary">{softwareData.name}</span>
        </nav>

        {/* Hero Section */}
        <div className="bg-white rounded-xl shadow-soft p-6 lg:p-8 mb-8">
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-8">
            {/* Left Side - Software Info */}
            <div className="flex-1">
              <div className="flex items-start space-x-4 mb-6">
                <div className="w-16 h-16 bg-white rounded-xl shadow-soft p-2 flex-shrink-0">
                  <Image
                    src={softwareData.logo}
                    alt={`${softwareData.name} logo`}
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="flex-1">
                  <h1 className="text-2xl lg:text-3xl font-bold text-text-primary mb-2">
                    {softwareData.name}
                  </h1>
                  <p className="text-text-secondary mb-3">by {softwareData.company}</p>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Icon
                            key={i}
                            name="Star"
                            size={16}
                            className={i < Math.floor(softwareData.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}
                          />
                        ))}
                      </div>
                      <span className="text-sm font-medium text-text-primary ml-1">
                        {softwareData.rating}
                      </span>
                      <span className="text-sm text-text-secondary">
                        ({softwareData.reviewCount} reviews)
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="px-2 py-1 bg-secondary-100 text-secondary text-xs font-medium rounded-full">
                        {softwareData.category}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Side - Pricing & CTA */}
            <div className="lg:w-80 bg-gradient-to-br from-primary-50 to-secondary-50 rounded-xl p-6">
              <div className="text-center mb-6">
                <div className="flex items-center justify-center space-x-2 mb-2">
                  <span className="text-2xl font-bold text-text-primary line-through opacity-50">
                    ${softwareData.originalPrice}/mo
                  </span>
                  <span className="px-2 py-1 bg-secondary text-white text-xs font-bold rounded-full">
                    {softwareData.discountPercentage}% OFF
                  </span>
                </div>
                <div className="text-4xl font-bold text-secondary mb-1">
                  FREE
                </div>
                <p className="text-sm text-text-secondary">
                  For qualified nonprofits
                </p>
              </div>

              {/* Application Status */}
              {applicationStatus === 'not-started' && (
                <button
                  onClick={() => setIsApplicationOpen(true)}
                  className="btn-primary w-full mb-4 text-lg py-4"
                >
                  Apply Now
                </button>
              )}

              {applicationStatus === 'submitted' && (
                <div className="bg-warning-50 border border-warning-200 rounded-lg p-4 mb-4">
                  <div className="flex items-center space-x-2">
                    <Icon name="Clock" size={20} className="text-warning" />
                    <div>
                      <p className="font-medium text-warning-700">Application Submitted</p>
                      <p className="text-sm text-warning-600">Review in progress (2-3 days)</p>
                    </div>
                  </div>
                </div>
              )}

              {applicationStatus === 'approved' && (
                <div className="bg-success-50 border border-success-200 rounded-lg p-4 mb-4">
                  <div className="flex items-center space-x-2">
                    <Icon name="CheckCircle" size={20} className="text-success" />
                    <div>
                      <p className="font-medium text-success-700">Application Approved!</p>
                      <p className="text-sm text-success-600">Check your email for next steps</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Eligibility Requirements */}
              <div className="space-y-3">
                <h4 className="font-semibold text-text-primary">Eligibility Requirements:</h4>
                {softwareData.eligibility.map((requirement, index) => (
                  <div key={index} className="flex items-start space-x-2">
                    <Icon name="Check" size={16} className="text-secondary mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-text-secondary">{requirement}</span>
                  </div>
                ))}
              </div>

              {/* Talk to Similar Organizations */}
              <button className="w-full mt-6 px-4 py-3 border border-primary text-primary rounded-lg font-medium hover:bg-primary-50 transition-colors duration-200 flex items-center justify-center space-x-2">
                <Icon name="Users" size={18} />
                <span>Talk to Similar Organizations</span>
              </button>
            </div>
          </div>
        </div>

        {/* Tabs Navigation */}
        <div className="bg-white rounded-xl shadow-soft mb-8">
          <div className="border-b border-border">
            <nav className="flex space-x-8 px-6" aria-label="Tabs">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200 ${
                    activeTab === tab.id
                      ? 'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary hover:border-gray-300'
                  }`}
                >
                  <Icon name={tab.icon} size={18} />
                  <span>{tab.name}</span>
                </button>
              ))}
            </nav>
          </div>
          <div className="p-6">
            {renderTabContent()}
          </div>
        </div>

        {/* Application Form Modal */}
        {isApplicationOpen && (
          <ApplicationForm
            software={softwareData}
            onClose={() => setIsApplicationOpen(false)}
            onSubmit={handleApplicationSubmit}
          />
        )}
      </div>
    </div>
  );
}

export default SoftwareDetailApplication;