import React, { useState, useMemo } from 'react';

import Icon from '../../components/AppIcon';

import FilterSidebar from './components/FilterSidebar';
import SoftwareCard from './components/SoftwareCard';
import CompareModal from './components/CompareModal';
import FeaturedCollections from './components/FeaturedCollections';

function SoftwareCatalog() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilters, setSelectedFilters] = useState({
    category: [],
    impactArea: [],
    organizationSize: [],
    priceRange: [],
    complexity: [],
    discount: []
  });
  const [sortBy, setSortBy] = useState('popularity');
  const [viewMode, setViewMode] = useState('grid');
  const [compareList, setCompareList] = useState([]);
  const [showCompareModal, setShowCompareModal] = useState(false);

  // Mock software data
  const softwareData = [
    {
      id: 1,
      name: "Salesforce Nonprofit Cloud",
      category: "CRM",
      impactArea: ["General", "Fundraising"],
      originalPrice: 120,
      discountedPrice: 0,
      discount: 100,
      rating: 4.8,
      reviewCount: 847,
      complexity: "Advanced",
      setupTime: "2-4 weeks",
      organizationSize: ["Medium", "Large"],
      description: "Complete donor management and fundraising platform designed specifically for nonprofits.",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=250&fit=crop",
      features: ["Donor Management", "Grant Tracking", "Volunteer Management", "Reporting"],
      usedBy: 2847,
      tags: ["Popular", "Free Tier"],
      provider: "Salesforce.org",
      satisfaction: 94
    },
    {
      id: 2,
      name: "Slack for Nonprofits",
      category: "Communication",
      impactArea: ["General", "Team Collaboration"],
      originalPrice: 8,
      discountedPrice: 0,
      discount: 100,
      rating: 4.6,
      reviewCount: 1203,
      complexity: "Beginner",
      setupTime: "1-2 days",
      organizationSize: ["Small", "Medium", "Large"],
      description: "Team communication platform with special nonprofit pricing and features.",
      image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=250&fit=crop",
      features: ["Team Messaging", "File Sharing", "Video Calls", "App Integrations"],
      usedBy: 5621,
      tags: ["Quick Win", "Popular"],
      provider: "Slack Technologies",
      satisfaction: 92
    },
    {
      id: 3,
      name: "Asana for Good",
      category: "Project Management",
      impactArea: ["General", "Program Management"],
      originalPrice: 24,
      discountedPrice: 0,
      discount: 100,
      rating: 4.5,
      reviewCount: 934,
      complexity: "Intermediate",
      setupTime: "3-5 days",
      organizationSize: ["Small", "Medium"],
      description: "Project management tool helping nonprofits organize campaigns and programs effectively.",
      image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=250&fit=crop",
      features: ["Task Management", "Timeline View", "Team Collaboration", "Custom Fields"],
      usedBy: 3456,
      tags: ["Best for Remote Teams"],
      provider: "Asana",
      satisfaction: 89
    },
    {
      id: 4,
      name: "Canva for Nonprofits",
      category: "Design",
      impactArea: ["Marketing", "Communications"],
      originalPrice: 15,
      discountedPrice: 0,
      discount: 100,
      rating: 4.7,
      reviewCount: 2156,
      complexity: "Beginner",
      setupTime: "1 day",
      organizationSize: ["Small", "Medium", "Large"],
      description: "Design platform with templates and tools specifically for nonprofit marketing materials.",
      image: "https://images.unsplash.com/photo-1558655146-d09347e92766?w=400&h=250&fit=crop",
      features: ["Templates", "Brand Kit", "Social Media Tools", "Print Materials"],
      usedBy: 7892,
      tags: ["Quick Win", "Popular with Food Banks"],
      provider: "Canva",
      satisfaction: 96
    },
    {
      id: 5,
      name: "Microsoft 365 Nonprofit",
      category: "Productivity",
      impactArea: ["General", "Operations"],
      originalPrice: 22,
      discountedPrice: 0,
      discount: 100,
      rating: 4.4,
      reviewCount: 1567,
      complexity: "Intermediate",
      setupTime: "1-2 weeks",
      organizationSize: ["Medium", "Large"],
      description: "Complete office suite with email, document creation, and collaboration tools.",
      image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=250&fit=crop",
      features: ["Email & Calendar", "Office Apps", "OneDrive Storage", "Teams"],
      usedBy: 4321,
      tags: ["Essential"],
      provider: "Microsoft",
      satisfaction: 87
    },
    {
      id: 6,
      name: "Zoom for Nonprofits",
      category: "Communication",
      impactArea: ["General", "Remote Work"],
      originalPrice: 20,
      discountedPrice: 8,
      discount: 60,
      rating: 4.3,
      reviewCount: 892,
      complexity: "Beginner",
      setupTime: "1 day",
      organizationSize: ["Small", "Medium", "Large"],
      description: "Video conferencing solution with special nonprofit rates for virtual meetings and events.",
      image: "https://images.unsplash.com/photo-1587825140708-dfaf72ae4b04?w=400&h=250&fit=crop",
      features: ["Video Meetings", "Webinars", "Recording", "Breakout Rooms"],
      usedBy: 2134,
      tags: ["Best for Remote Teams"],
      provider: "Zoom",
      satisfaction: 91
    },
    {
      id: 7,
      name: "Mailchimp Nonprofit",
      category: "Marketing",
      impactArea: ["Communications", "Fundraising"],
      originalPrice: 35,
      discountedPrice: 15,
      discount: 57,
      rating: 4.2,
      reviewCount: 1456,
      complexity: "Intermediate",
      setupTime: "2-3 days",
      organizationSize: ["Small", "Medium"],
      description: "Email marketing platform with automation tools for donor engagement and newsletters.",
      image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=400&h=250&fit=crop",
      features: ["Email Campaigns", "Automation", "Analytics", "Landing Pages"],
      usedBy: 3789,
      tags: ["Under $50/month"],
      provider: "Mailchimp",
      satisfaction: 85
    },
    {
      id: 8,
      name: "QuickBooks Nonprofit",
      category: "Finance",
      impactArea: ["Financial Management"],
      originalPrice: 45,
      discountedPrice: 18,
      discount: 60,
      rating: 4.1,
      reviewCount: 678,
      complexity: "Advanced",
      setupTime: "1-2 weeks",
      organizationSize: ["Small", "Medium"],
      description: "Accounting software tailored for nonprofit financial management and reporting.",
      image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400&h=250&fit=crop",
      features: ["Accounting", "Invoicing", "Expense Tracking", "Financial Reports"],
      usedBy: 1567,
      tags: ["Essential", "Under $50/month"],
      provider: "Intuit",
      satisfaction: 83
    }
  ];

  // Filter and search logic
  const filteredSoftware = useMemo(() => {
    let filtered = softwareData;

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(software => 
        software.name.toLowerCase().includes(query) ||
        software.description.toLowerCase().includes(query) ||
        software.category.toLowerCase().includes(query) ||
        software.impactArea.some(area => area.toLowerCase().includes(query)) ||
        software.features.some(feature => feature.toLowerCase().includes(query))
      );
    }

    // Category filter
    if (selectedFilters.category.length > 0) {
      filtered = filtered.filter(software => 
        selectedFilters.category.includes(software.category)
      );
    }

    // Impact area filter
    if (selectedFilters.impactArea.length > 0) {
      filtered = filtered.filter(software => 
        software.impactArea.some(area => selectedFilters.impactArea.includes(area))
      );
    }

    // Organization size filter
    if (selectedFilters.organizationSize.length > 0) {
      filtered = filtered.filter(software => 
        software.organizationSize.some(size => selectedFilters.organizationSize.includes(size))
      );
    }

    // Price range filter
    if (selectedFilters.priceRange.length > 0) {
      filtered = filtered.filter(software => {
        const price = software.discountedPrice;
        return selectedFilters.priceRange.some(range => {
          switch(range) {
            case 'free': return price === 0;
            case 'under-25': return price > 0 && price <= 25;
            case '25-50': return price > 25 && price <= 50;
            case 'over-50': return price > 50;
            default: return true;
          }
        });
      });
    }

    // Complexity filter
    if (selectedFilters.complexity.length > 0) {
      filtered = filtered.filter(software => 
        selectedFilters.complexity.includes(software.complexity)
      );
    }

    // Discount filter
    if (selectedFilters.discount.length > 0) {
      filtered = filtered.filter(software => {
        return selectedFilters.discount.some(range => {
          switch(range) {
            case '50-75': return software.discount >= 50 && software.discount < 75;
            case '75-90': return software.discount >= 75 && software.discount < 90;
            case '90-100': return software.discount >= 90;
            default: return true;
          }
        });
      });
    }

    // Sort results
    switch(sortBy) {
      case 'price-low':
        return filtered.sort((a, b) => a.discountedPrice - b.discountedPrice);
      case 'price-high':
        return filtered.sort((a, b) => b.discountedPrice - a.discountedPrice);
      case 'rating':
        return filtered.sort((a, b) => b.rating - a.rating);
      case 'discount':
        return filtered.sort((a, b) => b.discount - a.discount);
      case 'name':
        return filtered.sort((a, b) => a.name.localeCompare(b.name));
      default: // popularity
        return filtered.sort((a, b) => b.usedBy - a.usedBy);
    }
  }, [searchQuery, selectedFilters, sortBy]);

  const handleFilterChange = (filterType, value) => {
    setSelectedFilters(prev => ({
      ...prev,
      [filterType]: prev[filterType].includes(value)
        ? prev[filterType].filter(item => item !== value)
        : [...prev[filterType], value]
    }));
  };

  const clearAllFilters = () => {
    setSelectedFilters({
      category: [],
      impactArea: [],
      organizationSize: [],
      priceRange: [],
      complexity: [],
      discount: []
    });
    setSearchQuery('');
  };

  const addToCompare = (software) => {
    if (compareList.length < 3 && !compareList.find(item => item.id === software.id)) {
      setCompareList([...compareList, software]);
    }
  };

  const removeFromCompare = (softwareId) => {
    setCompareList(compareList.filter(item => item.id !== softwareId));
  };

  const activeFilterCount = Object.values(selectedFilters).flat().length;

  return (
    <div className="min-h-screen bg-background pt-24 lg:pt-28">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary-50 to-secondary-50 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center mb-8">
            <h1 className="text-4xl lg:text-5xl font-bold text-text-primary mb-4">
              Software Catalog
            </h1>
            <p className="text-xl text-text-secondary max-w-3xl mx-auto">
              Discover premium business tools at nonprofit-friendly prices. Find the perfect software to amplify your impact.
            </p>
          </div>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Icon 
                name="Search" 
                size={20} 
                className="absolute left-4 top-1/2 transform -translate-y-1/2 text-text-muted"
              />
              <input
                type="text"
                placeholder="Search for tools... (e.g., 'CRM for animal rescue' or 'project management under $100')"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 text-lg border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white shadow-soft"
              />
            </div>
          </div>

          {/* Quick Stats */}
          <div className="flex flex-wrap justify-center gap-6 mt-8 text-sm text-text-secondary">
            <div className="flex items-center space-x-2">
              <Icon name="Package" size={16} className="text-primary" />
              <span>{softwareData.length} Tools Available</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="DollarSign" size={16} className="text-secondary" />
              <span>Up to 100% Discount</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Users" size={16} className="text-accent" />
              <span>Trusted by 2,847+ Organizations</span>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Collections */}
      <FeaturedCollections softwareData={softwareData} />

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters */}
          <div className="lg:w-80 flex-shrink-0">
            <FilterSidebar
              selectedFilters={selectedFilters}
              onFilterChange={handleFilterChange}
              onClearAll={clearAllFilters}
              activeFilterCount={activeFilterCount}
            />
          </div>

          {/* Main Content Area */}
          <div className="flex-1">
            {/* Toolbar */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
              <div className="flex items-center space-x-4">
                <span className="text-text-secondary">
                  {filteredSoftware.length} tools found
                </span>
                {activeFilterCount > 0 && (
                  <button
                    onClick={clearAllFilters}
                    className="text-sm text-primary hover:text-primary-700 font-medium"
                  >
                    Clear all filters ({activeFilterCount})
                  </button>
                )}
              </div>

              <div className="flex items-center space-x-4">
                {/* Sort Dropdown */}
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-3 py-2 border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
                >
                  <option value="popularity">Most Popular</option>
                  <option value="rating">Highest Rated</option>
                  <option value="discount">Best Discount</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="name">Name: A to Z</option>
                </select>

                {/* View Mode Toggle */}
                <div className="flex border border-border rounded-lg overflow-hidden">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`p-2 ${viewMode === 'grid' ? 'bg-primary text-white' : 'bg-white text-text-secondary hover:bg-surface'}`}
                  >
                    <Icon name="Grid3X3" size={16} />
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`p-2 ${viewMode === 'list' ? 'bg-primary text-white' : 'bg-white text-text-secondary hover:bg-surface'}`}
                  >
                    <Icon name="List" size={16} />
                  </button>
                </div>
              </div>
            </div>

            {/* Software Grid/List */}
            {filteredSoftware.length > 0 ? (
              <div className={`${
                viewMode === 'grid' ?'grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6' :'space-y-4'
              }`}>
                {filteredSoftware.map((software) => (
                  <SoftwareCard
                    key={software.id}
                    software={software}
                    viewMode={viewMode}
                    onAddToCompare={addToCompare}
                    isInCompare={compareList.some(item => item.id === software.id)}
                    compareDisabled={compareList.length >= 3}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <div className="w-24 h-24 bg-surface rounded-full flex items-center justify-center mx-auto mb-6">
                  <Icon name="Search" size={48} className="text-text-muted" />
                </div>
                <h3 className="text-xl font-semibold text-text-primary mb-2">
                  No tools found
                </h3>
                <p className="text-text-secondary mb-6">
                  Try adjusting your search or filters to find what you're looking for.
                </p>
                <button
                  onClick={clearAllFilters}
                  className="btn-primary"
                >
                  Clear all filters
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Compare Bar */}
      {compareList.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-border shadow-strong z-40">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <span className="font-semibold text-text-primary">
                  Compare Tools ({compareList.length}/3)
                </span>
                <div className="flex items-center space-x-2">
                  {compareList.map((software) => (
                    <div key={software.id} className="flex items-center space-x-2 bg-surface px-3 py-1 rounded-lg">
                      <span className="text-sm font-medium">{software.name}</span>
                      <button
                        onClick={() => removeFromCompare(software.id)}
                        className="text-text-muted hover:text-error"
                      >
                        <Icon name="X" size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setCompareList([])}
                  className="text-text-secondary hover:text-text-primary"
                >
                  Clear all
                </button>
                <button
                  onClick={() => setShowCompareModal(true)}
                  className="btn-primary"
                  disabled={compareList.length < 2}
                >
                  Compare Now
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Compare Modal */}
      {showCompareModal && (
        <CompareModal
          compareList={compareList}
          onClose={() => setShowCompareModal(false)}
          onRemove={removeFromCompare}
        />
      )}
    </div>
  );
}

export default SoftwareCatalog;