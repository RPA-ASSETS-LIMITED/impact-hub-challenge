import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

function SoftwareCard({ software, viewMode, onAddToCompare, isInCompare, compareDisabled }) {
  const {
    id,
    name,
    category,
    originalPrice,
    discountedPrice,
    discount,
    rating,
    reviewCount,
    complexity,
    setupTime,
    description,
    image,
    features,
    usedBy,
    tags,
    provider,
    satisfaction
  } = software;

  const formatPrice = (price) => {
    return price === 0 ? 'Free' : `$${price}/month`;
  };

  const getComplexityColor = (complexity) => {
    switch(complexity) {
      case 'Beginner': return 'text-secondary bg-secondary-50';
      case 'Intermediate': return 'text-accent bg-accent-50';
      case 'Advanced': return 'text-conversion bg-conversion-50';
      default: return 'text-text-muted bg-surface';
    }
  };

  if (viewMode === 'list') {
    return (
      <div className="bg-white rounded-lg shadow-soft border border-border hover:shadow-medium transition-all duration-300 p-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Image */}
          <div className="lg:w-48 flex-shrink-0">
            <div className="aspect-video rounded-lg overflow-hidden">
              <Image
                src={image}
                alt={name}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          </div>

          {/* Content */}
          <div className="flex-1">
            <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
              <div className="flex-1">
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center space-x-2 mb-1">
                      <h3 className="text-xl font-semibold text-text-primary hover:text-primary transition-colors duration-200">
                        <Link to="/software-detail-application">{name}</Link>
                      </h3>
                      {tags.includes('Popular') && (
                        <span className="bg-accent text-white text-xs px-2 py-1 rounded-full font-medium">
                          Popular
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-text-secondary mb-2">by {provider}</p>
                    <div className="flex items-center space-x-4 text-sm text-text-muted">
                      <span className="flex items-center space-x-1">
                        <Icon name="Tag" size={14} />
                        <span>{category}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Icon name="Clock" size={14} />
                        <span>{setupTime}</span>
                      </span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getComplexityColor(complexity)}`}>
                        {complexity}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Description */}
                <p className="text-text-secondary mb-4 line-clamp-2">{description}</p>

                {/* Features */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {features.slice(0, 4).map((feature, index) => (
                    <span
                      key={index}
                      className="bg-surface text-text-secondary text-xs px-2 py-1 rounded-lg"
                    >
                      {feature}
                    </span>
                  ))}
                  {features.length > 4 && (
                    <span className="text-xs text-text-muted">
                      +{features.length - 4} more
                    </span>
                  )}
                </div>

                {/* Stats */}
                <div className="flex items-center space-x-6 text-sm text-text-muted">
                  <div className="flex items-center space-x-1">
                    <Icon name="Star" size={14} className="text-accent fill-current" />
                    <span className="font-medium text-text-primary">{rating}</span>
                    <span>({reviewCount} reviews)</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Users" size={14} />
                    <span>{usedBy.toLocaleString()} organizations</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="ThumbsUp" size={14} />
                    <span>{satisfaction}% satisfaction</span>
                  </div>
                </div>
              </div>

              {/* Price & Actions */}
              <div className="lg:w-48 flex-shrink-0">
                <div className="text-right mb-4">
                  {originalPrice > 0 && discountedPrice !== originalPrice && (
                    <div className="text-sm text-text-muted line-through mb-1">
                      ${originalPrice}/month
                    </div>
                  )}
                  <div className="text-2xl font-bold text-text-primary mb-1">
                    {formatPrice(discountedPrice)}
                  </div>
                  {discount > 0 && (
                    <div className="inline-flex items-center bg-secondary text-white text-sm px-2 py-1 rounded-full font-medium">
                      <Icon name="Percent" size={12} className="mr-1" />
                      {discount}% off
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Link
                    to="/software-detail-application"
                    className="btn-primary w-full text-center block"
                  >
                    View Details
                  </Link>
                  <button
                    onClick={() => onAddToCompare(software)}
                    disabled={compareDisabled && !isInCompare}
                    className={`w-full px-4 py-2 text-sm font-medium rounded-lg border transition-colors duration-200 ${
                      isInCompare
                        ? 'bg-primary-50 text-primary border-primary'
                        : compareDisabled
                        ? 'bg-surface text-text-muted border-border cursor-not-allowed' :'bg-white text-text-secondary border-border hover:bg-surface hover:text-text-primary'
                    }`}
                  >
                    {isInCompare ? 'Added to Compare' : 'Add to Compare'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Grid view
  return (
    <div className="bg-white rounded-lg shadow-soft border border-border hover:shadow-medium transition-all duration-300 overflow-hidden group">
      {/* Image */}
      <div className="aspect-video overflow-hidden relative">
        <Image
          src={image}
          alt={name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {tags.includes('Popular') && (
          <div className="absolute top-3 left-3">
            <span className="bg-accent text-white text-xs px-2 py-1 rounded-full font-medium">
              Popular
            </span>
          </div>
        )}
        {discount > 0 && (
          <div className="absolute top-3 right-3">
            <span className="bg-secondary text-white text-xs px-2 py-1 rounded-full font-medium flex items-center space-x-1">
              <Icon name="Percent" size={10} />
              <span>{discount}% off</span>
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Header */}
        <div className="mb-3">
          <h3 className="text-lg font-semibold text-text-primary mb-1 hover:text-primary transition-colors duration-200">
            <Link to="/software-detail-application">{name}</Link>
          </h3>
          <p className="text-sm text-text-secondary">by {provider}</p>
        </div>

        {/* Meta Info */}
        <div className="flex items-center justify-between mb-3 text-sm text-text-muted">
          <span className="flex items-center space-x-1">
            <Icon name="Tag" size={14} />
            <span>{category}</span>
          </span>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getComplexityColor(complexity)}`}>
            {complexity}
          </span>
        </div>

        {/* Description */}
        <p className="text-text-secondary text-sm mb-4 line-clamp-2">{description}</p>

        {/* Features */}
        <div className="flex flex-wrap gap-1 mb-4">
          {features.slice(0, 3).map((feature, index) => (
            <span
              key={index}
              className="bg-surface text-text-secondary text-xs px-2 py-1 rounded-lg"
            >
              {feature}
            </span>
          ))}
          {features.length > 3 && (
            <span className="text-xs text-text-muted">
              +{features.length - 3}
            </span>
          )}
        </div>

        {/* Stats */}
        <div className="flex items-center justify-between mb-4 text-sm text-text-muted">
          <div className="flex items-center space-x-1">
            <Icon name="Star" size={14} className="text-accent fill-current" />
            <span className="font-medium text-text-primary">{rating}</span>
            <span>({reviewCount})</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="Users" size={14} />
            <span>{usedBy.toLocaleString()}</span>
          </div>
        </div>

        {/* Price */}
        <div className="mb-4">
          {originalPrice > 0 && discountedPrice !== originalPrice && (
            <div className="text-sm text-text-muted line-through">
              ${originalPrice}/month
            </div>
          )}
          <div className="text-xl font-bold text-text-primary">
            {formatPrice(discountedPrice)}
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2">
          <Link
            to="/software-detail-application"
            className="btn-primary w-full text-center block"
          >
            View Details
          </Link>
          <button
            onClick={() => onAddToCompare(software)}
            disabled={compareDisabled && !isInCompare}
            className={`w-full px-4 py-2 text-sm font-medium rounded-lg border transition-colors duration-200 ${
              isInCompare
                ? 'bg-primary-50 text-primary border-primary'
                : compareDisabled
                ? 'bg-surface text-text-muted border-border cursor-not-allowed' :'bg-white text-text-secondary border-border hover:bg-surface hover:text-text-primary'
            }`}
          >
            {isInCompare ? 'Added' : 'Compare'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default SoftwareCard;