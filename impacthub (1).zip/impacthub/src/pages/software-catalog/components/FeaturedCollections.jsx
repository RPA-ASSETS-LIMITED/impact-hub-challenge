import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

function FeaturedCollections({ softwareData }) {
  const collections = [
    {
      title: 'Newly Added Partners',
      icon: 'Plus',
      color: 'bg-conversion text-white',
      items: softwareData.filter(s => s.tags.includes('Popular')).slice(0, 3)
    },
    {
      title: 'Highest Impact Tools',
      icon: 'Award',
      color: 'bg-accent text-white',
      items: softwareData.sort((a, b) => b.satisfaction - a.satisfaction).slice(0, 3)
    },
    {
      title: 'Quick Wins for Small Nonprofits',
      icon: 'Zap',
      color: 'bg-trust text-white',
      items: softwareData.filter(s => s.complexity === 'Beginner' && s.organizationSize.includes('Small')).slice(0, 3)
    }
  ];

  const formatPrice = (price) => {
    return price === 0 ? 'Free' : `$${price}/month`;
  };

  return (
    <div className="bg-white border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <h2 className="text-2xl lg:text-3xl font-bold text-text-primary mb-4">
            Featured Collections
          </h2>
          <p className="text-text-secondary max-w-2xl mx-auto">
            Curated selections to help you discover the perfect tools for your organization's needs.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {collections.map((collection, collectionIndex) => (
            <div key={collectionIndex} className="bg-surface rounded-xl p-6 hover:shadow-soft transition-all duration-300">
              {/* Collection Header */}
              <div className="flex items-center space-x-3 mb-6">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${collection.color}`}>
                  <Icon name={collection.icon} size={20} />
                </div>
                <div>
                  <h3 className="font-semibold text-text-primary">{collection.title}</h3>
                  <p className="text-sm text-text-secondary">{collection.items.length} tools</p>
                </div>
              </div>

              {/* Collection Items */}
              <div className="space-y-4">
                {collection.items.map((software, index) => (
                  <div key={software.id} className="bg-white rounded-lg p-4 hover:shadow-soft transition-all duration-300 group">
                    <div className="flex items-center space-x-4">
                      {/* Software Image */}
                      <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                        <Image
                          src={software.image}
                          alt={software.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>

                      {/* Software Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-medium text-text-primary truncate group-hover:text-primary transition-colors duration-200">
                            <Link to="/software-detail-application">{software.name}</Link>
                          </h4>
                          <div className="flex items-center space-x-1 text-sm text-text-muted">
                            <Icon name="Star" size={14} className="text-accent fill-current" />
                            <span>{software.rating}</span>
                          </div>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-text-secondary">{software.category}</span>
                          <div className="text-right">
                            {software.originalPrice > 0 && software.discountedPrice !== software.originalPrice && (
                              <div className="text-xs text-text-muted line-through">
                                ${software.originalPrice}/mo
                              </div>
                            )}
                            <div className="text-sm font-semibold text-text-primary">
                              {formatPrice(software.discountedPrice)}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* View All Button */}
              <button className="w-full mt-4 px-4 py-2 text-sm font-medium text-primary hover:text-primary-700 hover:bg-primary-50 rounded-lg transition-colors duration-200 border border-primary-200 hover:border-primary-300">
                View All in Collection
              </button>
            </div>
          ))}
        </div>

        {/* Popular Tags */}
        <div className="mt-12 text-center">
          <h3 className="text-lg font-semibold text-text-primary mb-4">Popular Categories</h3>
          <div className="flex flex-wrap justify-center gap-3">
            {[
              { name: 'CRM & Donor Management', count: 12, icon: 'Heart' },
              { name: 'Project Management', count: 15, icon: 'CheckSquare' },
              { name: 'Communication Tools', count: 8, icon: 'MessageCircle' },
              { name: 'Design & Marketing', count: 6, icon: 'Palette' },
              { name: 'Finance & Accounting', count: 9, icon: 'Calculator' },
              { name: 'Productivity Suite', count: 10, icon: 'Briefcase' }
            ].map((category, index) => (
              <button
                key={index}
                className="flex items-center space-x-2 px-4 py-2 bg-white border border-border rounded-lg hover:bg-surface hover:border-primary-200 transition-all duration-200 group"
              >
                <Icon name={category.icon} size={16} className="text-primary group-hover:text-primary-700" />
                <span className="text-sm font-medium text-text-secondary group-hover:text-text-primary">
                  {category.name}
                </span>
                <span className="text-xs text-text-muted bg-surface px-2 py-0.5 rounded-full">
                  {category.count}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default FeaturedCollections;