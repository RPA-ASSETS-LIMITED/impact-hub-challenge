import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

function CompareModal({ compareList, onClose, onRemove }) {
  const formatPrice = (price) => {
    return price === 0 ? 'Free' : `$${price}/month`;
  };

  const getComplexityColor = (complexity) => {
    switch(complexity) {
      case 'Beginner': return 'text-secondary bg-secondary-50';
      case 'Intermediate': return 'text-accent bg-accent-50';
      case 'Advanced': return 'text-conversion bg-conversion-50';
      default: return 'text-text-muted bg-surface';
    }
  };

  const comparisonFeatures = [
    { key: 'price', label: 'Monthly Price', icon: 'DollarSign' },
    { key: 'rating', label: 'User Rating', icon: 'Star' },
    { key: 'complexity', label: 'Complexity', icon: 'Settings' },
    { key: 'setupTime', label: 'Setup Time', icon: 'Clock' },
    { key: 'usedBy', label: 'Organizations Using', icon: 'Users' },
    { key: 'satisfaction', label: 'Satisfaction Rate', icon: 'ThumbsUp' },
    { key: 'discount', label: 'Discount', icon: 'Percent' }
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-strong max-w-6xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-2xl font-bold text-text-primary">
            Compare Software Tools
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-surface rounded-lg transition-colors duration-200"
          >
            <Icon name="X" size={24} className="text-text-muted" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-auto max-h-[calc(90vh-80px)]">
          <div className="p-6">
            {/* Software Cards */}
            <div className={`grid grid-cols-1 ${compareList.length === 2 ? 'md:grid-cols-2' : 'md:grid-cols-3'} gap-6 mb-8`}>
              {compareList.map((software) => (
                <div key={software.id} className="bg-surface rounded-lg p-4 relative">
                  <button
                    onClick={() => onRemove(software.id)}
                    className="absolute top-2 right-2 p-1 hover:bg-white rounded-full transition-colors duration-200"
                  >
                    <Icon name="X" size={16} className="text-text-muted" />
                  </button>

                  <div className="aspect-video rounded-lg overflow-hidden mb-4">
                    <Image
                      src={software.image}
                      alt={software.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <h3 className="font-semibold text-text-primary mb-1">{software.name}</h3>
                  <p className="text-sm text-text-secondary mb-2">by {software.provider}</p>
                  <p className="text-sm text-text-muted line-clamp-2">{software.description}</p>
                </div>
              ))}
            </div>

            {/* Comparison Table */}
            <div className="bg-white rounded-lg border border-border overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-surface">
                    <tr>
                      <th className="text-left p-4 font-semibold text-text-primary w-48">
                        Features
                      </th>
                      {compareList.map((software) => (
                        <th key={software.id} className="text-center p-4 font-semibold text-text-primary min-w-48">
                          {software.name}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {comparisonFeatures.map((feature, index) => (
                      <tr key={feature.key} className={index % 2 === 0 ? 'bg-white' : 'bg-surface'}>
                        <td className="p-4 font-medium text-text-primary">
                          <div className="flex items-center space-x-2">
                            <Icon name={feature.icon} size={16} className="text-primary" />
                            <span>{feature.label}</span>
                          </div>
                        </td>
                        {compareList.map((software) => (
                          <td key={software.id} className="p-4 text-center">
                            {feature.key === 'price' && (
                              <div>
                                <div className="font-semibold text-text-primary">
                                  {formatPrice(software.discountedPrice)}
                                </div>
                                {software.originalPrice > 0 && software.discountedPrice !== software.originalPrice && (
                                  <div className="text-sm text-text-muted line-through">
                                    ${software.originalPrice}/month
                                  </div>
                                )}
                              </div>
                            )}
                            {feature.key === 'rating' && (
                              <div className="flex items-center justify-center space-x-1">
                                <Icon name="Star" size={16} className="text-accent fill-current" />
                                <span className="font-semibold">{software.rating}</span>
                                <span className="text-sm text-text-muted">({software.reviewCount})</span>
                              </div>
                            )}
                            {feature.key === 'complexity' && (
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getComplexityColor(software.complexity)}`}>
                                {software.complexity}
                              </span>
                            )}
                            {feature.key === 'setupTime' && (
                              <span className="text-text-secondary">{software.setupTime}</span>
                            )}
                            {feature.key === 'usedBy' && (
                              <span className="font-semibold text-text-primary">
                                {software.usedBy.toLocaleString()}
                              </span>
                            )}
                            {feature.key === 'satisfaction' && (
                              <span className="font-semibold text-secondary">
                                {software.satisfaction}%
                              </span>
                            )}
                            {feature.key === 'discount' && (
                              <span className="font-semibold text-secondary">
                                {software.discount}% off
                              </span>
                            )}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Features Comparison */}
            <div className="mt-8">
              <h3 className="text-lg font-semibold text-text-primary mb-4">Feature Comparison</h3>
              <div className="bg-white rounded-lg border border-border overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-surface">
                      <tr>
                        <th className="text-left p-4 font-semibold text-text-primary w-48">
                          Features
                        </th>
                        {compareList.map((software) => (
                          <th key={software.id} className="text-center p-4 font-semibold text-text-primary min-w-48">
                            {software.name}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {/* Get all unique features */}
                      {Array.from(new Set(compareList.flatMap(s => s.features))).map((feature, index) => (
                        <tr key={feature} className={index % 2 === 0 ? 'bg-white' : 'bg-surface'}>
                          <td className="p-4 font-medium text-text-primary">{feature}</td>
                          {compareList.map((software) => (
                            <td key={software.id} className="p-4 text-center">
                              {software.features.includes(feature) ? (
                                <Icon name="Check" size={20} className="text-secondary mx-auto" />
                              ) : (
                                <Icon name="X" size={20} className="text-text-muted mx-auto" />
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mt-8">
              {compareList.map((software) => (
                <Link
                  key={software.id}
                  to="/software-detail-application"
                  className="btn-primary flex-1 text-center"
                >
                  View {software.name} Details
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CompareModal;