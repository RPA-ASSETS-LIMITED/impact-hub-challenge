import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

function FilterSidebar({ selectedFilters, onFilterChange, onClearAll, activeFilterCount }) {
  const [expandedSections, setExpandedSections] = useState({
    category: true,
    impactArea: true,
    organizationSize: false,
    priceRange: true,
    complexity: false,
    discount: false
  });

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const filterSections = [
    {
      key: 'category',
      title: 'Software Category',
      icon: 'Grid3X3',
      options: [
        { value: 'CRM', label: 'CRM & Donor Management', count: 12 },
        { value: 'Communication', label: 'Communication', count: 8 },
        { value: 'Project Management', label: 'Project Management', count: 15 },
        { value: 'Design', label: 'Design & Marketing', count: 6 },
        { value: 'Productivity', label: 'Productivity', count: 10 },
        { value: 'Marketing', label: 'Email Marketing', count: 7 },
        { value: 'Finance', label: 'Finance & Accounting', count: 9 }
      ]
    },
    {
      key: 'impactArea',
      title: 'Impact Area',
      icon: 'Heart',
      options: [
        { value: 'General', label: 'General Operations', count: 45 },
        { value: 'Fundraising', label: 'Fundraising', count: 18 },
        { value: 'Team Collaboration', label: 'Team Collaboration', count: 12 },
        { value: 'Program Management', label: 'Program Management', count: 8 },
        { value: 'Marketing', label: 'Marketing & Outreach', count: 14 },
        { value: 'Communications', label: 'Communications', count: 11 },
        { value: 'Remote Work', label: 'Remote Work', count: 6 },
        { value: 'Operations', label: 'Operations', count: 9 },
        { value: 'Financial Management', label: 'Financial Management', count: 7 }
      ]
    },
    {
      key: 'organizationSize',
      title: 'Organization Size',
      icon: 'Users',
      options: [
        { value: 'Small', label: 'Small (1-25 people)', count: 28 },
        { value: 'Medium', label: 'Medium (26-100 people)', count: 35 },
        { value: 'Large', label: 'Large (100+ people)', count: 22 }
      ]
    },
    {
      key: 'priceRange',
      title: 'Price Range (Monthly)',
      icon: 'DollarSign',
      options: [
        { value: 'free', label: 'Free', count: 24 },
        { value: 'under-25', label: 'Under $25', count: 18 },
        { value: '25-50', label: '$25 - $50', count: 12 },
        { value: 'over-50', label: 'Over $50', count: 8 }
      ]
    },
    {
      key: 'complexity',
      title: 'Implementation Complexity',
      icon: 'Settings',
      options: [
        { value: 'Beginner', label: 'Beginner (1-2 days)', count: 15 },
        { value: 'Intermediate', label: 'Intermediate (3-7 days)', count: 28 },
        { value: 'Advanced', label: 'Advanced (1+ weeks)', count: 19 }
      ]
    },
    {
      key: 'discount',
      title: 'Discount Range',
      icon: 'Percent',
      options: [
        { value: '50-75', label: '50% - 75% off', count: 12 },
        { value: '75-90', label: '75% - 90% off', count: 18 },
        { value: '90-100', label: '90% - 100% off', count: 32 }
      ]
    }
  ];

  const smartFilters = [
    { label: 'Popular with Food Banks', icon: 'TrendingUp', color: 'text-accent' },
    { label: 'Best for Remote Teams', icon: 'Wifi', color: 'text-secondary' },
    { label: 'Under $50/month', icon: 'DollarSign', color: 'text-primary' },
    { label: 'Quick Wins for Small Nonprofits', icon: 'Zap', color: 'text-trust' },
    { label: 'Newly Added Partners', icon: 'Plus', color: 'text-conversion' },
    { label: 'Highest Impact Tools', icon: 'Award', color: 'text-accent' }
  ];

  return (
    <div className="bg-white rounded-lg shadow-soft border border-border p-6 sticky top-32">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-text-primary flex items-center space-x-2">
          <Icon name="Filter" size={20} className="text-primary" />
          <span>Filters</span>
        </h3>
        {activeFilterCount > 0 && (
          <button
            onClick={onClearAll}
            className="text-sm text-primary hover:text-primary-700 font-medium"
          >
            Clear all ({activeFilterCount})
          </button>
        )}
      </div>

      {/* Smart Filters */}
      <div className="mb-6">
        <h4 className="text-sm font-semibold text-text-primary mb-3 flex items-center space-x-2">
          <Icon name="Sparkles" size={16} className="text-accent" />
          <span>Smart Filters</span>
        </h4>
        <div className="space-y-2">
          {smartFilters.map((filter, index) => (
            <button
              key={index}
              className="w-full flex items-center space-x-2 px-3 py-2 text-sm text-left rounded-lg hover:bg-surface transition-colors duration-200 group"
            >
              <Icon name={filter.icon} size={14} className={`${filter.color} group-hover:scale-110 transition-transform duration-200`} />
              <span className="text-text-secondary group-hover:text-text-primary">{filter.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Filter Sections */}
      <div className="space-y-4">
        {filterSections.map((section) => (
          <div key={section.key} className="border-b border-border last:border-b-0 pb-4 last:pb-0">
            <button
              onClick={() => toggleSection(section.key)}
              className="w-full flex items-center justify-between py-2 text-left group"
            >
              <div className="flex items-center space-x-2">
                <Icon 
                  name={section.icon} 
                  size={16} 
                  className="text-primary group-hover:text-primary-700 transition-colors duration-200" 
                />
                <span className="font-medium text-text-primary group-hover:text-primary transition-colors duration-200">
                  {section.title}
                </span>
                {selectedFilters[section.key].length > 0 && (
                  <span className="bg-primary text-white text-xs px-2 py-0.5 rounded-full">
                    {selectedFilters[section.key].length}
                  </span>
                )}
              </div>
              <Icon 
                name={expandedSections[section.key] ? "ChevronUp" : "ChevronDown"} 
                size={16} 
                className="text-text-muted group-hover:text-text-primary transition-all duration-200"
              />
            </button>

            {expandedSections[section.key] && (
              <div className="mt-3 space-y-2 animate-slide-down">
                {section.options.map((option) => (
                  <label
                    key={option.value}
                    className="flex items-center space-x-3 cursor-pointer group hover:bg-surface rounded-lg p-2 transition-colors duration-200"
                  >
                    <input
                      type="checkbox"
                      checked={selectedFilters[section.key].includes(option.value)}
                      onChange={() => onFilterChange(section.key, option.value)}
                      className="w-4 h-4 text-primary border-border rounded focus:ring-primary-500 focus:ring-2"
                    />
                    <div className="flex-1 flex items-center justify-between">
                      <span className="text-sm text-text-secondary group-hover:text-text-primary transition-colors duration-200">
                        {option.label}
                      </span>
                      <span className="text-xs text-text-muted bg-surface px-2 py-0.5 rounded-full">
                        {option.count}
                      </span>
                    </div>
                  </label>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Help Section */}
      <div className="mt-6 pt-6 border-t border-border">
        <div className="bg-primary-50 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <Icon name="HelpCircle" size={20} className="text-primary flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-text-primary mb-1">
                Need Help Choosing?
              </h4>
              <p className="text-xs text-text-secondary mb-3">
                Our team can help you find the perfect tools for your organization's needs.
              </p>
              <button className="text-xs font-medium text-primary hover:text-primary-700 transition-colors duration-200">
                Get Personalized Recommendations →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default FilterSidebar;