import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';

import ImpactCalculator from './components/ImpactCalculator';
import SoftwareShowcase from './components/SoftwareShowcase';
import HowItWorks from './components/HowItWorks';
import TestimonialsCarousel from './components/TestimonialsCarousel';
import PartnerSpotlight from './components/PartnerSpotlight';
import MissionFilters from './components/MissionFilters';

function Homepage() {
  const [totalSavings, setTotalSavings] = useState(2300000);
  const [organizationsServed, setOrganizationsServed] = useState(1200);

  // Animate counters on mount
  useEffect(() => {
    const interval = setInterval(() => {
      setTotalSavings(prev => prev + Math.floor(Math.random() * 1000));
      if (Math.random() > 0.7) {
        setOrganizationsServed(prev => prev + 1);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section with Impact Calculator */}
      <section className="relative pt-24 lg:pt-32 pb-16 lg:pb-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-50 via-white to-secondary-50"></div>
        <div className="absolute top-0 right-0 w-1/3 h-full opacity-10">
          <div className="w-full h-full bg-gradient-to-l from-primary to-transparent"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left Column - Hero Content */}
            <div className="text-center lg:text-left">
              <div className="mb-6">
                <div className="inline-flex items-center space-x-2 bg-white/80 backdrop-blur-glass px-4 py-2 rounded-full shadow-soft mb-6">
                  <Icon name="Sparkles" size={16} className="text-accent" />
                  <span className="text-sm font-medium text-text-secondary">Trusted by 1,200+ Organizations</span>
                </div>
                
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-text-primary mb-6 leading-tight">
                  Your Mission Deserves the{' '}
                  <span className="text-gradient">Best Tools</span>
                </h1>
                
                <p className="text-xl lg:text-2xl text-text-secondary mb-8 leading-relaxed">
                  Access premium business software at nonprofit prices. Join thousands of impact organizations saving millions while scaling their mission.
                </p>
              </div>

              {/* Real-time Impact Counter */}
              <div className="bg-white/90 backdrop-blur-glass rounded-2xl p-6 lg:p-8 shadow-soft border border-border mb-8">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center">
                    <div className="flex items-center justify-center space-x-2 mb-2">
                      <Icon name="DollarSign" size={24} className="text-secondary" />
                      <span className="text-3xl lg:text-4xl font-bold text-secondary">
                        {formatCurrency(totalSavings)}+
                      </span>
                    </div>
                    <p className="text-sm font-medium text-text-secondary">Total Savings Delivered</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="flex items-center justify-center space-x-2 mb-2">
                      <Icon name="Users" size={24} className="text-primary" />
                      <span className="text-3xl lg:text-4xl font-bold text-primary">
                        {organizationsServed.toLocaleString()}+
                      </span>
                    </div>
                    <p className="text-sm font-medium text-text-secondary">Organizations Served</p>
                  </div>
                </div>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Link to="/software-catalog" className="btn-primary text-lg px-8 py-4 hover:transform hover:scale-105 transition-all duration-300">
                  Browse Software Catalog
                </Link>
                <button className="px-8 py-4 text-lg font-semibold text-primary border-2 border-primary rounded-lg hover:bg-primary hover:text-white transition-all duration-300">
                  Calculate Your Savings
                </button>
              </div>
            </div>

            {/* Right Column - Impact Calculator */}
            <div className="lg:pl-8">
              <ImpactCalculator />
            </div>
          </div>
        </div>
      </section>

      {/* Software Showcase */}
      <SoftwareShowcase />

      {/* How It Works */}
      <HowItWorks />

      {/* Mission Area Filters */}
      <MissionFilters />

      {/* Testimonials */}
      <TestimonialsCarousel />

      {/* Partner Spotlight */}
      <PartnerSpotlight />

      {/* Final CTA Section */}
      <section className="py-16 lg:py-24 bg-gradient-to-r from-primary to-secondary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-8">
            <Icon name="Rocket" size={48} color="white" className="mx-auto mb-6" />
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              Ready to Transform Your Impact?
            </h2>
            <p className="text-xl text-white/90 mb-8">
              Join thousands of organizations already saving money and scaling their mission with premium tools.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/software-catalog" className="bg-white text-primary px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-50 transition-all duration-300 hover:transform hover:scale-105">
              Start Browsing Tools
            </Link>
            <button className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white hover:text-primary transition-all duration-300">
              Verify Your Organization
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Homepage;