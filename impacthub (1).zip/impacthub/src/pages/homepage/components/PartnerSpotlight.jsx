import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

function PartnerSpotlight() {
  const [activePartner, setActivePartner] = useState(0);

  const partners = [
    {
      id: 1,
      name: "Salesforce",
      logo: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=120&h=120&fit=crop&crop=center",
      category: "CRM & Fundraising",
      commitment: "100% Free Nonprofit Cloud",
      description: `Salesforce leads the industry in supporting nonprofits with their comprehensive Nonprofit Cloud platform. Their commitment goes beyond software - they provide training, community support, and dedicated resources to help organizations maximize their impact.`,
      impactStats: {
        organizations: "40,000+",
        savings: "$8.2M",
        grants: "$250M+"
      },
      programs: [
        "Nonprofit Cloud (Free for qualifying orgs)",
        "Power of Us Hub community",
        "Trailhead nonprofit learning paths",
        "Pro bono consulting hours"
      ],
      quote: "We believe technology should amplify the incredible work nonprofits do every day.",
      spokesperson: "Sarah Johnson, VP of Nonprofit Success"
    },
    {
      id: 2,
      name: "Microsoft",
      logo: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=120&h=120&fit=crop&crop=center",
      category: "Productivity & Cloud",
      commitment: "Up to 86% Discount on Office 365",
      description: `Microsoft's nonprofit program provides comprehensive productivity tools that enable organizations to collaborate effectively, store data securely, and communicate seamlessly. Their Azure cloud platform offers scalable solutions for organizations of all sizes.`,
      impactStats: {
        organizations: "300,000+",
        savings: "$15.7M",
        grants: "$1.2B+"
      },
      programs: [
        "Office 365 Nonprofit (Up to 86% off)",
        "Azure credits for nonprofits",
        "Microsoft Teams for collaboration",
        "Power Platform for automation"
      ],
      quote: "Empowering nonprofits with technology to create lasting change in their communities.",
      spokesperson: "David Chen, Director of Nonprofit Partnerships"
    },
    {
      id: 3,
      name: "Adobe",
      logo: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=120&h=120&fit=crop&crop=center",
      category: "Creative & Design",
      commitment: "60% Off Creative Cloud",
      description: `Adobe's Creative Cloud for Nonprofits program recognizes that compelling visual storytelling is essential for mission-driven organizations. They provide professional-grade creative tools at accessible prices, plus training resources to build internal capacity.`,
      impactStats: {
        organizations: "25,000+",
        savings: "$4.8M",
        grants: "$50M+"
      },
      programs: [
        "Creative Cloud All Apps (60% discount)",
        "Adobe for Nonprofits training",
        "Creative Residency program",
        "Pro bono design partnerships"
      ],
      quote: "Great stories deserve great tools. We\'re here to help nonprofits tell theirs.",
      spokesperson: "Maria Rodriguez, Nonprofit Program Manager"
    },
    {
      id: 4,
      name: "Google",
      logo: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=120&h=120&fit=crop&crop=center",
      category: "Productivity & Advertising",
      commitment: "Free Workspace & $10K Ad Grants",
      description: `Google for Nonprofits offers a comprehensive suite of tools including free Google Workspace, $10,000 monthly in Google Ads grants, and access to Google Cloud Platform credits. Their program is designed to help nonprofits reach more people and operate more efficiently.`,
      impactStats: {
        organizations: "115,000+",
        savings: "$12.3M",
        grants: "$9B+"
      },
      programs: [
        "Google Workspace for Nonprofits (Free)",
        "Google Ad Grants ($10K/month)",
        "Google Cloud Platform credits",
        "YouTube Nonprofit Program"
      ],
      quote: "Technology should be accessible to organizations working to make the world better.",
      spokesperson: "Alex Kim, Google for Nonprofits Lead"
    }
  ];

  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-primary-50 via-white to-secondary-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-white px-4 py-2 rounded-full shadow-soft mb-6">
            <Icon name="Handshake" size={16} className="text-primary" />
            <span className="text-sm font-medium text-primary">Trusted Partners</span>
          </div>
          
          <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-6">
            Partner Spotlight
          </h2>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Meet the technology companies investing in social good by making their premium tools accessible to impact organizations.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-8">
          {/* Partner Selection Sidebar */}
          <div className="lg:col-span-4">
            <div className="bg-white rounded-2xl shadow-soft border border-border p-6 sticky top-8">
              <h3 className="text-lg font-semibold text-text-primary mb-6">Featured Partners</h3>
              
              <div className="space-y-3">
                {partners.map((partner, index) => (
                  <button
                    key={partner.id}
                    onClick={() => setActivePartner(index)}
                    className={`w-full flex items-center space-x-4 p-4 rounded-xl transition-all duration-300 text-left ${
                      activePartner === index
                        ? 'bg-primary-50 border-2 border-primary shadow-soft'
                        : 'hover:bg-surface border-2 border-transparent'
                    }`}
                  >
                    <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
                      <Image 
                        src={partner.logo}
                        alt={`${partner.name} logo`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className={`font-semibold truncate ${
                        activePartner === index ? 'text-primary' : 'text-text-primary'
                      }`}>
                        {partner.name}
                      </h4>
                      <p className="text-sm text-text-secondary truncate">
                        {partner.category}
                      </p>
                    </div>
                    <Icon 
                      name="ChevronRight" 
                      size={16} 
                      className={`transition-colors duration-300 ${
                        activePartner === index ? 'text-primary' : 'text-text-muted'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Partner Details */}
          <div className="lg:col-span-8">
            <div className="bg-white rounded-2xl shadow-medium border border-border overflow-hidden">
              {/* Header */}
              <div className="bg-gradient-to-r from-primary-50 to-secondary-50 p-8 border-b border-border">
                <div className="flex items-start space-x-6">
                  <div className="w-20 h-20 bg-white rounded-xl shadow-soft flex items-center justify-center overflow-hidden flex-shrink-0">
                    <Image 
                      src={partners[activePartner].logo}
                      alt={`${partners[activePartner].name} logo`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-text-primary mb-2">
                      {partners[activePartner].name}
                    </h3>
                    <p className="text-text-secondary mb-3">
                      {partners[activePartner].category}
                    </p>
                    <div className="inline-flex items-center space-x-2 bg-secondary text-white px-4 py-2 rounded-full">
                      <Icon name="Gift" size={16} />
                      <span className="font-semibold text-sm">
                        {partners[activePartner].commitment}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-8">
                {/* Description */}
                <div className="mb-8">
                  <p className="text-text-secondary leading-relaxed text-lg">
                    {partners[activePartner].description}
                  </p>
                </div>

                {/* Impact Stats */}
                <div className="grid grid-cols-3 gap-6 mb-8 p-6 bg-surface rounded-xl">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary mb-1">
                      {partners[activePartner].impactStats.organizations}
                    </div>
                    <div className="text-sm text-text-secondary">Organizations Served</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-secondary mb-1">
                      {partners[activePartner].impactStats.savings}
                    </div>
                    <div className="text-sm text-text-secondary">Annual Savings</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-accent mb-1">
                      {partners[activePartner].impactStats.grants}
                    </div>
                    <div className="text-sm text-text-secondary">Total Grants</div>
                  </div>
                </div>

                {/* Programs */}
                <div className="mb-8">
                  <h4 className="text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2">
                    <Icon name="Package" size={20} className="text-primary" />
                    <span>Available Programs</span>
                  </h4>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {partners[activePartner].programs.map((program, index) => (
                      <div key={index} className="flex items-start space-x-3 p-3 bg-primary-50 rounded-lg">
                        <Icon name="Check" size={16} className="text-primary flex-shrink-0 mt-0.5" strokeWidth={2.5} />
                        <span className="text-sm text-text-primary">{program}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Quote */}
                <div className="bg-gradient-to-r from-secondary-50 to-primary-50 rounded-xl p-6 border border-secondary-100">
                  <div className="flex items-start space-x-3">
                    <Icon name="Quote" size={24} className="text-secondary flex-shrink-0 mt-1" />
                    <div>
                      <blockquote className="text-text-primary font-medium mb-3 italic">
                        "{partners[activePartner].quote}"
                      </blockquote>
                      <cite className="text-sm text-text-secondary">
                        — {partners[activePartner].spokesperson}
                      </cite>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="bg-white rounded-2xl shadow-soft border border-border p-8 max-w-2xl mx-auto">
            <Icon name="Users" size={32} className="text-primary mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-text-primary mb-3">
              Become a Partner
            </h3>
            <p className="text-text-secondary mb-6">
              Join leading technology companies in supporting the social sector. Partner with us to make your tools accessible to impact organizations.
            </p>
            <button className="btn-primary px-8 py-3 hover:transform hover:scale-105 transition-all duration-300">
              Partner With Us
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default PartnerSpotlight;