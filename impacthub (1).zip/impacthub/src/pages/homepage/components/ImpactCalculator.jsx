import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

function ImpactCalculator() {
  const [selectedOrgType, setSelectedOrgType] = useState('');
  const [selectedSize, setSelectedSize] = useState('');
  const [calculatedSavings, setCalculatedSavings] = useState(0);

  const organizationTypes = [
    { id: 'nonprofit', name: 'Nonprofit Organization', multiplier: 1.2 },
    { id: 'social-enterprise', name: 'Social Enterprise', multiplier: 1.0 },
    { id: 'foundation', name: 'Foundation', multiplier: 1.5 },
    { id: 'educational', name: 'Educational Institution', multiplier: 1.3 },
    { id: 'healthcare', name: 'Healthcare Organization', multiplier: 1.4 },
  ];

  const organizationSizes = [
    { id: 'small', name: '1-10 employees', baseAmount: 5000 },
    { id: 'medium', name: '11-50 employees', baseAmount: 15000 },
    { id: 'large', name: '51-200 employees', baseAmount: 35000 },
    { id: 'enterprise', name: '200+ employees', baseAmount: 75000 },
  ];

  const calculateSavings = () => {
    if (!selectedOrgType || !selectedSize) return;

    const orgType = organizationTypes.find(type => type.id === selectedOrgType);
    const orgSize = organizationSizes.find(size => size.id === selectedSize);

    if (orgType && orgSize) {
      const savings = Math.round(orgSize.baseAmount * orgType.multiplier);
      setCalculatedSavings(savings);
    }
  };

  React.useEffect(() => {
    calculateSavings();
  }, [selectedOrgType, selectedSize]);

  return (
    <div className="bg-white rounded-2xl shadow-medium border border-border p-6 lg:p-8">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-gradient-to-br from-accent to-accent-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Calculator" size={32} color="white" />
        </div>
        <h3 className="text-2xl font-bold text-text-primary mb-2">Impact Calculator</h3>
        <p className="text-text-secondary">Discover your potential annual savings</p>
      </div>

      <div className="space-y-6">
        {/* Organization Type Selection */}
        <div>
          <label className="block text-sm font-semibold text-text-primary mb-3">
            Organization Type
          </label>
          <div className="space-y-2">
            {organizationTypes.map((type) => (
              <label key={type.id} className="flex items-center p-3 rounded-lg border border-border hover:bg-surface cursor-pointer transition-colors duration-200">
                <input
                  type="radio"
                  name="orgType"
                  value={type.id}
                  checked={selectedOrgType === type.id}
                  onChange={(e) => setSelectedOrgType(e.target.value)}
                  className="w-4 h-4 text-primary focus:ring-primary-500 border-border"
                />
                <span className="ml-3 text-sm font-medium text-text-primary">{type.name}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Organization Size Selection */}
        <div>
          <label className="block text-sm font-semibold text-text-primary mb-3">
            Organization Size
          </label>
          <div className="space-y-2">
            {organizationSizes.map((size) => (
              <label key={size.id} className="flex items-center p-3 rounded-lg border border-border hover:bg-surface cursor-pointer transition-colors duration-200">
                <input
                  type="radio"
                  name="orgSize"
                  value={size.id}
                  checked={selectedSize === size.id}
                  onChange={(e) => setSelectedSize(e.target.value)}
                  className="w-4 h-4 text-primary focus:ring-primary-500 border-border"
                />
                <span className="ml-3 text-sm font-medium text-text-primary">{size.name}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Results */}
        {calculatedSavings > 0 && (
          <div className="bg-gradient-to-r from-secondary-50 to-primary-50 rounded-xl p-6 border border-secondary-100">
            <div className="text-center">
              <div className="flex items-center justify-center space-x-2 mb-2">
                <Icon name="TrendingUp" size={24} className="text-secondary" />
                <span className="text-3xl font-bold text-secondary">
                  ${calculatedSavings.toLocaleString()}
                </span>
              </div>
              <p className="text-sm font-medium text-text-secondary mb-4">
                Estimated Annual Savings
              </p>
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <div className="text-lg font-bold text-primary">
                    {Math.round(calculatedSavings / 12).toLocaleString()}
                  </div>
                  <div className="text-xs text-text-secondary">Monthly Savings</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-accent">
                    {Math.round((calculatedSavings / 50000) * 100)}%
                  </div>
                  <div className="text-xs text-text-secondary">Cost Reduction</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* CTA */}
        <div className="pt-4">
          <button 
            className="w-full btn-primary text-center py-3 disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={!selectedOrgType || !selectedSize}
          >
            Get Started with These Savings
          </button>
          <p className="text-xs text-text-muted text-center mt-2">
            * Estimates based on average software costs and typical nonprofit discounts
          </p>
        </div>
      </div>
    </div>
  );
}

export default ImpactCalculator;