import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

function SoftwareShowcase() {
  const featuredSoftware = [
    {
      id: 1,
      name: "Salesforce Nonprofit Cloud",
      category: "CRM & Fundraising",
      originalPrice: 150,
      discountedPrice: 0,
      discount: "100%",
      logo: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=100&h=100&fit=crop&crop=center",
      description: "Complete donor management and fundraising platform",
      features: ["Donor Management", "Campaign Tracking", "Grant Management"],
      badge: "Most Popular"
    },
    {
      id: 2,
      name: "Slack for Nonprofits",
      category: "Communication",
      originalPrice: 8,
      discountedPrice: 0,
      discount: "100%",
      logo: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=100&h=100&fit=crop&crop=center",
      description: "Team collaboration and communication platform",
      features: ["Team Messaging", "File Sharing", "Video Calls"],
      badge: "Free"
    },
    {
      id: 3,
      name: "Zoom Pro",
      category: "Video Conferencing",
      originalPrice: 15,
      discountedPrice: 7.5,
      discount: "50%",
      logo: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=100&h=100&fit=crop&crop=center",
      description: "Professional video conferencing solution",
      features: ["HD Video", "Screen Sharing", "Recording"],
      badge: null
    },
    {
      id: 4,
      name: "Microsoft 365",
      category: "Productivity Suite",
      originalPrice: 22,
      discountedPrice: 3,
      discount: "86%",
      logo: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=100&h=100&fit=crop&crop=center",
      description: "Complete office productivity suite",
      features: ["Office Apps", "Cloud Storage", "Email"],
      badge: "Best Value"
    },
    {
      id: 5,
      name: "Canva Pro",
      category: "Design & Marketing",
      originalPrice: 15,
      discountedPrice: 0,
      discount: "100%",
      logo: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=100&h=100&fit=crop&crop=center",
      description: "Professional design and marketing tools",
      features: ["Templates", "Brand Kit", "Team Collaboration"],
      badge: "Creative"
    },
    {
      id: 6,
      name: "Mailchimp",
      category: "Email Marketing",
      originalPrice: 35,
      discountedPrice: 15,
      discount: "57%",
      logo: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=100&h=100&fit=crop&crop=center",
      description: "Email marketing and automation platform",
      features: ["Email Campaigns", "Automation", "Analytics"],
      badge: null
    },
    {
      id: 7,
      name: "Asana",
      category: "Project Management",
      originalPrice: 25,
      discountedPrice: 0,
      discount: "100%",
      logo: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=100&h=100&fit=crop&crop=center",
      description: "Team project management and collaboration",
      features: ["Task Management", "Timeline View", "Team Dashboards"],
      badge: "Productivity"
    },
    {
      id: 8,
      name: "Adobe Creative Cloud",
      category: "Creative Suite",
      originalPrice: 53,
      discountedPrice: 20,
      discount: "62%",
      logo: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=100&h=100&fit=crop&crop=center",
      description: "Professional creative software suite",
      features: ["Photoshop", "Illustrator", "InDesign"],
      badge: "Professional"
    }
  ];

  const getBadgeColor = (badge) => {
    switch (badge) {
      case 'Most Popular': return 'bg-primary text-white';
      case 'Free': return 'bg-secondary text-white';
      case 'Best Value': return 'bg-accent text-white';
      case 'Creative': return 'bg-purple-500 text-white';
      case 'Productivity': return 'bg-blue-500 text-white';
      case 'Professional': return 'bg-gray-800 text-white';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <section className="py-16 lg:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-primary-50 px-4 py-2 rounded-full mb-6">
            <Icon name="Star" size={16} className="text-primary" />
            <span className="text-sm font-medium text-primary">Premium Partners</span>
          </div>
          
          <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-6">
            Curated Software Showcase
          </h2>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Access premium business tools at nonprofit prices. Our partners offer exclusive discounts to verified impact organizations.
          </p>
        </div>

        {/* Software Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {featuredSoftware.map((software) => (
            <div key={software.id} className="group bg-white rounded-xl shadow-soft border border-border hover:shadow-medium transition-all duration-300 hover:transform hover:scale-105 overflow-hidden">
              {/* Badge */}
              {software.badge && (
                <div className="relative">
                  <div className={`absolute top-4 right-4 px-2 py-1 rounded-full text-xs font-semibold z-10 ${getBadgeColor(software.badge)}`}>
                    {software.badge}
                  </div>
                </div>
              )}

              <div className="p-6">
                {/* Logo and Header */}
                <div className="flex items-start space-x-4 mb-4">
                  <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
                    <Image 
                      src={software.logo} 
                      alt={`${software.name} logo`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-text-primary text-sm mb-1 truncate">
                      {software.name}
                    </h3>
                    <p className="text-xs text-text-secondary">{software.category}</p>
                  </div>
                </div>

                {/* Pricing */}
                <div className="mb-4">
                  <div className="flex items-center space-x-2 mb-2">
                    {software.discountedPrice === 0 ? (
                      <span className="text-lg font-bold text-secondary">FREE</span>
                    ) : (
                      <span className="text-lg font-bold text-primary">
                        ${software.discountedPrice}/mo
                      </span>
                    )}
                    {software.originalPrice > 0 && (
                      <span className="text-sm text-text-muted line-through">
                        ${software.originalPrice}/mo
                      </span>
                    )}
                  </div>
                  <div className="inline-flex items-center space-x-1 bg-secondary-50 px-2 py-1 rounded-full">
                    <Icon name="TrendingDown" size={12} className="text-secondary" />
                    <span className="text-xs font-semibold text-secondary">
                      {software.discount} OFF
                    </span>
                  </div>
                </div>

                {/* Description */}
                <p className="text-sm text-text-secondary mb-4 line-clamp-2">
                  {software.description}
                </p>

                {/* Features */}
                <div className="mb-4">
                  <div className="flex flex-wrap gap-1">
                    {software.features.slice(0, 2).map((feature, index) => (
                      <span key={index} className="text-xs bg-surface px-2 py-1 rounded-full text-text-secondary">
                        {feature}
                      </span>
                    ))}
                    {software.features.length > 2 && (
                      <span className="text-xs text-text-muted">
                        +{software.features.length - 2} more
                      </span>
                    )}
                  </div>
                </div>

                {/* CTA Button */}
                <Link 
                  to="/software-detail-application"
                  className="w-full btn-primary text-sm py-2 text-center block group-hover:transform group-hover:scale-105 transition-all duration-300"
                >
                  View Details
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* View All CTA */}
        <div className="text-center">
          <Link 
            to="/software-catalog" 
            className="inline-flex items-center space-x-2 btn-secondary px-8 py-4 text-lg hover:transform hover:scale-105 transition-all duration-300"
          >
            <span>View All Software</span>
            <Icon name="ArrowRight" size={20} />
          </Link>
          
          <div className="mt-6 flex items-center justify-center space-x-8 text-sm text-text-secondary">
            <div className="flex items-center space-x-2">
              <Icon name="Shield" size={16} className="text-trust" />
              <span>Verified Partners</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Clock" size={16} className="text-accent" />
              <span>Instant Access</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Users" size={16} className="text-secondary" />
              <span>Community Support</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default SoftwareShowcase;