import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

function MissionFilters() {
  const [activeFilter, setActiveFilter] = useState('all');

  const missionAreas = [
    {
      id: 'all',
      name: 'All Areas',
      icon: 'Globe',
      color: 'primary',
      count: 847
    },
    {
      id: 'education',
      name: 'Education',
      icon: 'GraduationCap',
      color: 'blue-600',
      count: 234,
      description: 'Schools, universities, and educational nonprofits'
    },
    {
      id: 'environment',
      name: 'Environment',
      icon: 'Leaf',
      color: 'green-600',
      count: 189,
      description: 'Conservation, sustainability, and climate action'
    },
    {
      id: 'health',
      name: 'Health',
      icon: 'Heart',
      color: 'red-600',
      count: 156,
      description: 'Healthcare, medical research, and wellness'
    },
    {
      id: 'social-services',
      name: 'Social Services',
      icon: 'Users',
      color: 'purple-600',
      count: 143,
      description: 'Community support and social welfare'
    },
    {
      id: 'arts-culture',
      name: 'Arts & Culture',
      icon: 'Palette',
      color: 'pink-600',
      count: 85,
      description: 'Museums, theaters, and cultural organizations'
    },
    {
      id: 'human-rights',
      name: 'Human Rights',
      icon: 'Scale',
      color: 'orange-600',
      count: 40,
      description: 'Advocacy, justice, and civil rights'
    }
  ];

  const organizationTypes = [
    {
      id: 'nonprofit',
      name: 'Nonprofit Organizations',
      icon: 'Building',
      description: '501(c)(3) and equivalent organizations',
      count: 456,
      examples: ['Food banks', 'Animal shelters', 'Community centers']
    },
    {
      id: 'social-enterprise',
      name: 'Social Enterprises',
      icon: 'TrendingUp',
      description: 'Mission-driven businesses creating social impact',
      count: 234,
      examples: ['B-Corps', 'Social ventures', 'Impact startups']
    },
    {
      id: 'foundation',
      name: 'Foundations',
      icon: 'Gift',
      description: 'Private and community foundations',
      count: 89,
      examples: ['Family foundations', 'Corporate foundations', 'Community funds']
    },
    {
      id: 'educational',
      name: 'Educational Institutions',
      icon: 'School',
      description: 'Schools, colleges, and educational organizations',
      count: 68,
      examples: ['Public schools', 'Universities', 'Training centers']
    }
  ];

  const featuredOrganizations = [
    {
      name: 'Bay Area Food Bank',
      type: 'Food Security',
      location: 'San Francisco, CA',
      image: 'https://images.pexels.com/photos/6646918/pexels-photo-6646918.jpeg?w=300&h=200&fit=crop',
      savings: '$45,000',
      tools: 3
    },
    {
      name: 'Green Future Initiative',
      type: 'Environmental',
      location: 'Portland, OR',
      image: 'https://images.pexels.com/photos/1108572/pexels-photo-1108572.jpeg?w=300&h=200&fit=crop',
      savings: '$32,000',
      tools: 5
    },
    {
      name: 'Education Equity Alliance',
      type: 'Education',
      location: 'Chicago, IL',
      image: 'https://images.pexels.com/photos/1181472/pexels-photo-1181472.jpeg?w=300&h=200&fit=crop',
      savings: '$28,000',
      tools: 4
    }
  ];

  const getColorClass = (color) => {
    const colorMap = {
      'primary': 'text-primary bg-primary-50 border-primary-200',
      'blue-600': 'text-blue-600 bg-blue-50 border-blue-200',
      'green-600': 'text-green-600 bg-green-50 border-green-200',
      'red-600': 'text-red-600 bg-red-50 border-red-200',
      'purple-600': 'text-purple-600 bg-purple-50 border-purple-200',
      'pink-600': 'text-pink-600 bg-pink-50 border-pink-200',
      'orange-600': 'text-orange-600 bg-orange-50 border-orange-200'
    };
    return colorMap[color] || colorMap['primary'];
  };

  return (
    <section className="py-16 lg:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-accent-50 px-4 py-2 rounded-full mb-6">
            <Icon name="Filter" size={16} className="text-accent" />
            <span className="text-sm font-medium text-accent">Smart Filtering</span>
          </div>
          
          <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-6">
            Find Tools for Your Mission
          </h2>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Discover software solutions tailored to your organization type and mission area. Join thousands of organizations already transforming their impact.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-8">
          {/* Mission Area Filters */}
          <div className="lg:col-span-8">
            <div className="mb-8">
              <h3 className="text-xl font-semibold text-text-primary mb-6 flex items-center space-x-2">
                <Icon name="Target" size={20} className="text-primary" />
                <span>Browse by Mission Area</span>
              </h3>
              
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {missionAreas.map((area) => (
                  <button
                    key={area.id}
                    onClick={() => setActiveFilter(area.id)}
                    className={`p-4 rounded-xl border-2 transition-all duration-300 text-left hover:transform hover:scale-105 ${
                      activeFilter === area.id
                        ? getColorClass(area.color) + ' shadow-soft'
                        : 'bg-white border-border hover:bg-surface hover:border-primary-200'
                    }`}
                  >
                    <div className="flex items-center space-x-3 mb-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        activeFilter === area.id ? 'bg-white/20' : 'bg-surface'
                      }`}>
                        <Icon 
                          name={area.icon} 
                          size={20} 
                          className={activeFilter === area.id ? 'text-current' : 'text-text-muted'}
                        />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-sm">{area.name}</h4>
                        <p className="text-xs opacity-75">{area.count} organizations</p>
                      </div>
                    </div>
                    {area.description && (
                      <p className="text-xs opacity-75 leading-relaxed">
                        {area.description}
                      </p>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Organization Types */}
            <div className="mb-8">
              <h3 className="text-xl font-semibold text-text-primary mb-6 flex items-center space-x-2">
                <Icon name="Building2" size={20} className="text-secondary" />
                <span>Organization Types</span>
              </h3>
              
              <div className="grid sm:grid-cols-2 gap-4">
                {organizationTypes.map((type) => (
                  <div key={type.id} className="bg-surface rounded-xl p-6 border border-border hover:shadow-soft transition-all duration-300">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center shadow-soft">
                        <Icon name={type.icon} size={24} className="text-secondary" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-text-primary mb-2">{type.name}</h4>
                        <p className="text-sm text-text-secondary mb-3">{type.description}</p>
                        <div className="flex items-center space-x-4 mb-3">
                          <span className="text-sm font-medium text-primary">{type.count} organizations</span>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {type.examples.map((example, index) => (
                            <span key={index} className="text-xs bg-white px-2 py-1 rounded-full text-text-muted">
                              {example}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="text-center">
              <Link 
                to="/software-catalog" 
                className="btn-primary px-8 py-4 text-lg hover:transform hover:scale-105 transition-all duration-300 inline-flex items-center space-x-2"
              >
                <span>Explore All Software</span>
                <Icon name="ArrowRight" size={20} />
              </Link>
            </div>
          </div>

          {/* Featured Organizations Sidebar */}
          <div className="lg:col-span-4">
            <div className="bg-gradient-to-br from-primary-50 to-secondary-50 rounded-2xl p-6 border border-primary-100 sticky top-8">
              <h3 className="text-lg font-semibold text-text-primary mb-6 flex items-center space-x-2">
                <Icon name="Award" size={20} className="text-primary" />
                <span>Featured Success Stories</span>
              </h3>
              
              <div className="space-y-4">
                {featuredOrganizations.map((org, index) => (
                  <div key={index} className="bg-white rounded-xl p-4 shadow-soft border border-border">
                    <div className="flex items-start space-x-3">
                      <div className="w-12 h-12 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                        <Image 
                          src={org.image}
                          alt={org.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-text-primary text-sm mb-1 truncate">
                          {org.name}
                        </h4>
                        <p className="text-xs text-text-secondary mb-2">{org.type} • {org.location}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Icon name="DollarSign" size={12} className="text-secondary" />
                            <span className="text-xs font-semibold text-secondary">{org.savings} saved</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Icon name="Package" size={12} className="text-primary" />
                            <span className="text-xs text-primary">{org.tools} tools</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 pt-6 border-t border-primary-200">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary mb-1">1,200+</div>
                  <div className="text-sm text-text-secondary mb-4">Organizations Served</div>
                  <button className="w-full btn-secondary text-sm py-2">
                    View All Success Stories
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default MissionFilters;