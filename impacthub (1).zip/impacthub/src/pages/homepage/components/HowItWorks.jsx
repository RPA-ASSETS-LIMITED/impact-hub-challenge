import React from 'react';
import Icon from '../../../components/AppIcon';

function HowItWorks() {
  const steps = [
    {
      id: 1,
      title: "Verify Your Impact",
      description: "Submit your organization details and mission documentation. Our team reviews and verifies your eligibility within 24-48 hours.",
      icon: "Shield",
      color: "primary",
      features: [
        "Quick verification process",
        "Secure document upload",
        "24-48 hour approval"
      ]
    },
    {
      id: 2,
      title: "Browse Curated Tools",
      description: "Explore our carefully selected catalog of premium software with exclusive nonprofit pricing and detailed comparison guides.",
      icon: "Search",
      color: "secondary",
      features: [
        "Curated software catalog",
        "Exclusive nonprofit pricing",
        "Detailed comparisons"
      ]
    },
    {
      id: 3,
      title: "Transform Your Mission",
      description: "Access your chosen tools instantly and join our community for implementation support, best practices, and ongoing guidance.",
      icon: "Rocket",
      color: "accent",
      features: [
        "Instant tool access",
        "Implementation support",
        "Community guidance"
      ]
    }
  ];

  const getColorClasses = (color) => {
    switch (color) {
      case 'primary':
        return {
          bg: 'bg-primary',
          bgLight: 'bg-primary-50',
          text: 'text-primary',
          border: 'border-primary-200'
        };
      case 'secondary':
        return {
          bg: 'bg-secondary',
          bgLight: 'bg-secondary-50',
          text: 'text-secondary',
          border: 'border-secondary-200'
        };
      case 'accent':
        return {
          bg: 'bg-accent',
          bgLight: 'bg-accent-50',
          text: 'text-accent',
          border: 'border-accent-200'
        };
      default:
        return {
          bg: 'bg-gray-600',
          bgLight: 'bg-gray-50',
          text: 'text-gray-600',
          border: 'border-gray-200'
        };
    }
  };

  return (
    <section className="py-16 lg:py-24 bg-surface">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-white px-4 py-2 rounded-full shadow-soft mb-6">
            <Icon name="MapPin" size={16} className="text-primary" />
            <span className="text-sm font-medium text-primary">Simple Process</span>
          </div>
          
          <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-6">
            How It Works
          </h2>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Get started in three simple steps. From verification to transformation, we guide you every step of the way.
          </p>
        </div>

        {/* Steps */}
        <div className="relative">
          {/* Connection Lines - Desktop */}
          <div className="hidden lg:block absolute top-24 left-0 right-0 h-0.5 bg-gradient-to-r from-primary via-secondary to-accent opacity-20"></div>
          
          <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
            {steps.map((step, index) => {
              const colors = getColorClasses(step.color);
              
              return (
                <div key={step.id} className="relative group">
                  {/* Step Card */}
                  <div className="bg-white rounded-2xl shadow-soft border border-border p-8 hover:shadow-medium transition-all duration-300 hover:transform hover:scale-105 relative z-10">
                    {/* Step Number & Icon */}
                    <div className="flex items-center justify-between mb-6">
                      <div className={`w-16 h-16 ${colors.bg} rounded-xl flex items-center justify-center shadow-soft group-hover:shadow-medium transition-all duration-300`}>
                        <Icon name={step.icon} size={32} color="white" strokeWidth={2} />
                      </div>
                      <div className={`w-8 h-8 ${colors.bgLight} ${colors.border} border-2 rounded-full flex items-center justify-center`}>
                        <span className={`text-sm font-bold ${colors.text}`}>{step.id}</span>
                      </div>
                    </div>

                    {/* Content */}
                    <div className="mb-6">
                      <h3 className="text-xl font-bold text-text-primary mb-3">
                        {step.title}
                      </h3>
                      <p className="text-text-secondary leading-relaxed">
                        {step.description}
                      </p>
                    </div>

                    {/* Features List */}
                    <div className="space-y-2">
                      {step.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center space-x-2">
                          <Icon name="Check" size={16} className={colors.text} strokeWidth={2.5} />
                          <span className="text-sm text-text-secondary">{feature}</span>
                        </div>
                      ))}
                    </div>

                    {/* Hover Effect Overlay */}
                    <div className={`absolute inset-0 ${colors.bgLight} rounded-2xl opacity-0 group-hover:opacity-10 transition-opacity duration-300 pointer-events-none`}></div>
                  </div>

                  {/* Connection Arrow - Mobile */}
                  {index < steps.length - 1 && (
                    <div className="lg:hidden flex justify-center my-6">
                      <div className={`w-8 h-8 ${colors.bg} rounded-full flex items-center justify-center`}>
                        <Icon name="ArrowDown" size={16} color="white" strokeWidth={2.5} />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="bg-white rounded-2xl shadow-soft border border-border p-8 max-w-2xl mx-auto">
            <div className="mb-6">
              <Icon name="Sparkles" size={32} className="text-accent mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-text-primary mb-3">
                Ready to Get Started?
              </h3>
              <p className="text-text-secondary">
                Join thousands of organizations already transforming their impact with premium tools.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="btn-primary px-8 py-3 hover:transform hover:scale-105 transition-all duration-300">
                Start Verification
              </button>
              <button className="px-8 py-3 font-semibold text-primary border-2 border-primary rounded-lg hover:bg-primary hover:text-white transition-all duration-300">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default HowItWorks;