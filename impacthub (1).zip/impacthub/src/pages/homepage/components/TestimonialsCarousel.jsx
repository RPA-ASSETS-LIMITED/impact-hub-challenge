import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

function TestimonialsCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const testimonials = [
    {
      id: 1,
      name: "Sarah Chen",
      title: "Executive Director",
      organization: "Bay Area Food Bank",
      organizationType: "Food Security",
      avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?w=100&h=100&fit=crop&crop=face",
      quote: `ImpactHub transformed our operations completely. With Salesforce Nonprofit Cloud and Microsoft 365, we've increased our food distribution capacity by 300% while reducing administrative overhead by 40%. The savings allowed us to hire two additional program coordinators.`,
      metrics: {
        savings: "$45,000",
        impact: "300% capacity increase",
        timeframe: "12 months"
      },
      tools: ["Salesforce", "Microsoft 365", "Slack"]
    },
    {
      id: 2,
      name: "Marcus Rodriguez",
      title: "Founder & CEO",
      organization: "Green Future Initiative",
      organizationType: "Environmental",
      avatar: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?w=100&h=100&fit=crop&crop=face",
      quote: `The premium design tools from Adobe Creative Cloud and Canva Pro helped us create compelling campaigns that increased our donor engagement by 250%. What used to cost us $2,000 monthly is now just $400 through ImpactHub's partnerships.`,
      metrics: {
        savings: "$19,200",
        impact: "250% engagement boost",
        timeframe: "8 months"
      },
      tools: ["Adobe Creative", "Canva Pro", "Mailchimp"]
    },
    {
      id: 3,
      name: "Dr. Amara Okafor",
      title: "Program Director",
      organization: "Education Equity Alliance",
      organizationType: "Education",
      avatar: "https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?w=100&h=100&fit=crop&crop=face",
      quote: `Project management was chaos before Asana and our communication scattered across emails. Now we coordinate 15 schools seamlessly, track student outcomes effectively, and our team productivity has doubled. The free access through ImpactHub made this transformation possible.`,
      metrics: {
        savings: "$18,000",
        impact: "100% productivity gain",
        timeframe: "6 months"
      },
      tools: ["Asana", "Zoom Pro", "Google Workspace"]
    },
    {
      id: 4,
      name: "James Thompson",
      title: "Operations Manager",
      organization: "Community Health Partners",
      organizationType: "Healthcare",
      avatar: "https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?w=100&h=100&fit=crop&crop=face",
      quote: `Transitioning to cloud-based systems seemed impossible on our budget. ImpactHub's Microsoft 365 and Zoom Pro deals enabled us to serve 500+ patients remotely during the pandemic. We've maintained these services and expanded our reach to rural communities.`,
      metrics: {
        savings: "$32,000",
        impact: "500+ remote patients",
        timeframe: "18 months"
      },
      tools: ["Microsoft 365", "Zoom Pro", "Salesforce Health"]
    }
  ];

  // Auto-play functionality
  useEffect(() => {
    if (!isAutoPlaying) return;

    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => 
        prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
      );
    }, 6000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, testimonials.length]);

  const goToSlide = (index) => {
    setCurrentIndex(index);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000); // Resume auto-play after 10 seconds
  };

  const nextSlide = () => {
    setCurrentIndex(currentIndex === testimonials.length - 1 ? 0 : currentIndex + 1);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const prevSlide = () => {
    setCurrentIndex(currentIndex === 0 ? testimonials.length - 1 : currentIndex - 1);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const getOrgTypeColor = (type) => {
    switch (type) {
      case 'Food Security': return 'bg-green-100 text-green-800';
      case 'Environmental': return 'bg-emerald-100 text-emerald-800';
      case 'Education': return 'bg-blue-100 text-blue-800';
      case 'Healthcare': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <section className="py-16 lg:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-secondary-50 px-4 py-2 rounded-full mb-6">
            <Icon name="MessageSquare" size={16} className="text-secondary" />
            <span className="text-sm font-medium text-secondary">Success Stories</span>
          </div>
          
          <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-6">
            Real Impact, Real Results
          </h2>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto">
            Discover how organizations like yours are transforming their operations and scaling their impact with premium tools.
          </p>
        </div>

        {/* Testimonial Carousel */}
        <div className="relative max-w-4xl mx-auto">
          {/* Main Testimonial Card */}
          <div className="bg-gradient-to-br from-white to-surface rounded-2xl shadow-medium border border-border p-8 lg:p-12 relative overflow-hidden">
            {/* Background Pattern */}
            <div className="absolute top-0 right-0 w-32 h-32 opacity-5">
              <Icon name="Quote" size={128} className="text-primary" />
            </div>

            <div className="relative z-10">
              {/* Testimonial Content */}
              <div className="mb-8">
                <div className="flex items-start space-x-2 mb-6">
                  <Icon name="Quote" size={24} className="text-primary flex-shrink-0 mt-1" />
                  <blockquote className="text-lg lg:text-xl text-text-primary leading-relaxed font-medium">
                    {testimonials[currentIndex].quote}
                  </blockquote>
                </div>
              </div>

              {/* Author Info */}
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 rounded-full overflow-hidden shadow-soft">
                    <Image 
                      src={testimonials[currentIndex].avatar}
                      alt={testimonials[currentIndex].name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-semibold text-text-primary text-lg">
                      {testimonials[currentIndex].name}
                    </h4>
                    <p className="text-text-secondary">
                      {testimonials[currentIndex].title}
                    </p>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className="text-sm text-text-secondary">
                        {testimonials[currentIndex].organization}
                      </span>
                      <span className={`text-xs px-2 py-1 rounded-full ${getOrgTypeColor(testimonials[currentIndex].organizationType)}`}>
                        {testimonials[currentIndex].organizationType}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-3 gap-4 lg:gap-6">
                  <div className="text-center">
                    <div className="text-lg lg:text-xl font-bold text-secondary">
                      {testimonials[currentIndex].metrics.savings}
                    </div>
                    <div className="text-xs text-text-secondary">Annual Savings</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg lg:text-xl font-bold text-primary">
                      {testimonials[currentIndex].metrics.impact}
                    </div>
                    <div className="text-xs text-text-secondary">Impact Growth</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg lg:text-xl font-bold text-accent">
                      {testimonials[currentIndex].metrics.timeframe}
                    </div>
                    <div className="text-xs text-text-secondary">Timeframe</div>
                  </div>
                </div>
              </div>

              {/* Tools Used */}
              <div className="mt-6 pt-6 border-t border-border">
                <div className="flex items-center space-x-2 mb-2">
                  <Icon name="Wrench" size={16} className="text-text-muted" />
                  <span className="text-sm font-medium text-text-secondary">Tools Used:</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {testimonials[currentIndex].tools.map((tool, index) => (
                    <span key={index} className="bg-primary-50 text-primary px-3 py-1 rounded-full text-sm font-medium">
                      {tool}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between mt-8">
            {/* Previous/Next Buttons */}
            <div className="flex space-x-2">
              <button
                onClick={prevSlide}
                className="w-12 h-12 bg-white border border-border rounded-full flex items-center justify-center hover:bg-surface transition-colors duration-300 shadow-soft hover:shadow-medium"
                aria-label="Previous testimonial"
              >
                <Icon name="ChevronLeft" size={20} className="text-text-secondary" />
              </button>
              <button
                onClick={nextSlide}
                className="w-12 h-12 bg-white border border-border rounded-full flex items-center justify-center hover:bg-surface transition-colors duration-300 shadow-soft hover:shadow-medium"
                aria-label="Next testimonial"
              >
                <Icon name="ChevronRight" size={20} className="text-text-secondary" />
              </button>
            </div>

            {/* Dots Indicator */}
            <div className="flex space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentIndex 
                      ? 'bg-primary w-8' :'bg-border hover:bg-primary-200'
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>

            {/* Auto-play Toggle */}
            <button
              onClick={() => setIsAutoPlaying(!isAutoPlaying)}
              className={`w-12 h-12 border border-border rounded-full flex items-center justify-center transition-colors duration-300 shadow-soft hover:shadow-medium ${
                isAutoPlaying ? 'bg-primary text-white' : 'bg-white text-text-secondary hover:bg-surface'
              }`}
              aria-label={isAutoPlaying ? 'Pause auto-play' : 'Resume auto-play'}
            >
              <Icon name={isAutoPlaying ? "Pause" : "Play"} size={16} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default TestimonialsCarousel;