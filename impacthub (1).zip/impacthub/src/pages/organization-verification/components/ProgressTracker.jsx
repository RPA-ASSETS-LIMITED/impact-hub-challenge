// src/pages/organization-verification/components/ProgressTracker.jsx
import React from 'react';
import Icon from '../../../components/AppIcon';

const ProgressTracker = ({ steps, currentStep, onStepClick }) => {
  const getStepStatus = (step) => {
    if (step.id < currentStep) return 'completed';
    if (step.id === currentStep) return 'current';
    return 'pending';
  };

  const getStepIcon = (step, status) => {
    if (status === 'completed') return 'CheckCircle2';
    if (status === 'current') return 'Circle';
    return 'Circle';
  };

  const getStepStyles = (status) => {
    switch (status) {
      case 'completed':
        return {
          container: 'cursor-pointer hover:bg-success-50 border-success-100',
          icon: 'text-success bg-success-50',
          title: 'text-success font-semibold',
          line: 'bg-success'
        };
      case 'current':
        return {
          container: 'bg-primary-50 border-primary-200',
          icon: 'text-primary bg-primary-100',
          title: 'text-primary font-semibold',
          line: 'bg-border'
        };
      default:
        return {
          container: 'border-border',
          icon: 'text-text-muted bg-surface',
          title: 'text-text-secondary',
          line: 'bg-border'
        };
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-soft border border-border p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Icon name="Map" size={20} className="text-primary" />
        <h3 className="font-semibold text-text-primary">Verification Progress</h3>
      </div>
      
      <div className="space-y-4">
        {steps?.map((step, index) => {
          const status = getStepStatus(step);
          const styles = getStepStyles(status);
          const isLast = index === steps.length - 1;
          
          return (
            <div key={step.id} className="relative">
              <div
                className={`p-4 rounded-lg border transition-all duration-200 ${
                  styles.container
                } ${status === 'completed' ? 'hover:shadow-soft' : ''}`}
                onClick={() => onStepClick?.(step.id)}
              >
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-full ${styles.icon}`}>
                    <Icon 
                      name={getStepIcon(step, status)} 
                      size={16} 
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className={`text-sm ${styles.title}`}>
                      {step.title}
                    </h4>
                    <p className="text-xs text-text-muted mt-1">
                      Step {step.id} of {steps.length}
                    </p>
                  </div>
                  {status === 'completed' && (
                    <Icon name="Check" size={16} className="text-success" />
                  )}
                </div>
              </div>
              
              {/* Connection Line */}
              {!isLast && (
                <div className="flex justify-center py-2">
                  <div className={`w-0.5 h-4 ${styles.line}`} />
                </div>
              )}
            </div>
          );
        })}
      </div>
      
      {/* Progress Percentage */}
      <div className="mt-6 pt-6 border-t border-border">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-text-primary">Overall Progress</span>
          <span className="text-sm font-semibold text-primary">
            {Math.round(((currentStep - 1) / steps.length) * 100)}%
          </span>
        </div>
        <div className="w-full bg-surface rounded-full h-2">
          <div
            className="bg-gradient-to-r from-primary to-secondary h-2 rounded-full transition-all duration-500"
            style={{ width: `${((currentStep - 1) / steps.length) * 100}%` }}
          />
        </div>
      </div>
    </div>
  );
};

export default ProgressTracker;