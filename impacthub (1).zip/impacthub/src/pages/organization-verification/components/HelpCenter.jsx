// src/pages/organization-verification/components/HelpCenter.jsx
import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const HelpCenter = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState('faq');
  const [chatMessage, setChatMessage] = useState('');
  const [chatHistory, setChatHistory] = useState([
    {
      id: 1,
      type: 'bot',
      message: 'Hello! I\'m here to help with your verification process. What can I assist you with today?',
      timestamp: new Date()
    }
  ]);

  const tabs = [
    { id: 'faq', label: 'FAQ', icon: 'HelpCircle' },
    { id: 'chat', label: 'Live Chat', icon: 'MessageCircle' },
    { id: 'contact', label: 'Contact', icon: 'Phone' }
  ];

  const faqs = [
    {
      id: 1,
      question: 'How long does the verification process take?',
      answer: 'Standard verification typically takes 3-5 business days. Expedited review is available for 24-48 hour processing with priority support.'
    },
    {
      id: 2,
      question: 'What documents do I need for verification?',
      answer: 'Required documents vary by organization type. For 501(c)(3) nonprofits, you\'ll need your IRS Determination Letter, Form 990, and state registration. B-Corps need certification documents, and social enterprises need business registration and impact statements.'
    },
    {
      id: 3,
      question: 'Can I save my progress and continue later?',
      answer: 'Yes! Your progress is automatically saved every 30 seconds. You can return to complete your application at any time using the same browser.'
    },
    {
      id: 4,
      question: 'What file formats are accepted for document upload?',
      answer: 'We accept PDF, JPG, PNG, DOC, DOCX, XLS, and XLSX files up to 10MB each. For best results, use high-quality scans or clear photos.'
    },
    {
      id: 5,
      question: 'What happens if my verification is rejected?',
      answer: 'If additional information is needed, we\'ll email you with specific feedback. You can resubmit documents or clarify information through your verification dashboard.'
    },
    {
      id: 6,
      question: 'How do I qualify for software discounts?',
      answer: 'Once verified, you\'ll gain access to our software catalog with nonprofit pricing. Discounts range from 10% to 90% off regular prices depending on the software partner.'
    },
    {
      id: 7,
      question: 'Can international organizations apply?',
      answer: 'Yes! We support international NGOs and social enterprises. You\'ll need to provide local registration documents and proof of international status.'
    },
    {
      id: 8,
      question: 'Is there a fee for verification?',
      answer: 'Standard verification is completely free. Expedited review with video consultation is available for priority processing.'
    }
  ];

  const handleSendMessage = () => {
    if (!chatMessage.trim()) return;
    
    const newMessage = {
      id: chatHistory.length + 1,
      type: 'user',
      message: chatMessage,
      timestamp: new Date()
    };
    
    setChatHistory(prev => [...prev, newMessage]);
    setChatMessage('');
    
    // Simulate bot response
    setTimeout(() => {
      const botResponse = {
        id: chatHistory.length + 2,
        type: 'bot',
        message: 'Thank you for your message. A support specialist will respond shortly. For immediate assistance, please check our FAQ section or call our support line.',
        timestamp: new Date()
      };
      setChatHistory(prev => [...prev, botResponse]);
    }, 1000);
  };

  const renderFAQ = () => (
    <div className="space-y-4">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-text-primary mb-2">
          Frequently Asked Questions
        </h3>
        <p className="text-text-secondary">
          Find answers to common questions about the verification process.
        </p>
      </div>
      
      <div className="space-y-4">
        {faqs.map((faq) => (
          <div key={faq.id} className="bg-surface rounded-lg p-4">
            <h4 className="font-medium text-text-primary mb-2 flex items-start space-x-2">
              <Icon name="ChevronRight" size={16} className="text-primary mt-0.5" />
              <span>{faq.question}</span>
            </h4>
            <p className="text-sm text-text-secondary pl-6">
              {faq.answer}
            </p>
          </div>
        ))}
      </div>
    </div>
  );

  const renderChat = () => (
    <div className="flex flex-col h-96">
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-text-primary mb-2">
          Live Chat Support
        </h3>
        <p className="text-text-secondary">
          Chat with our support team for real-time assistance.
        </p>
      </div>
      
      {/* Chat History */}
      <div className="flex-1 bg-surface rounded-lg p-4 mb-4 overflow-y-auto space-y-3">
        {chatHistory.map((msg) => (
          <div key={msg.id} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xs px-4 py-2 rounded-lg ${
              msg.type === 'user' ?'bg-primary text-white' :'bg-white border border-border text-text-primary'
            }`}>
              <p className="text-sm">{msg.message}</p>
              <p className={`text-xs mt-1 ${
                msg.type === 'user' ? 'text-primary-100' : 'text-text-muted'
              }`}>
                {msg.timestamp.toLocaleTimeString()}
              </p>
            </div>
          </div>
        ))}
      </div>
      
      {/* Chat Input */}
      <div className="flex space-x-2">
        <input
          type="text"
          placeholder="Type your message..."
          value={chatMessage}
          onChange={(e) => setChatMessage(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
          className="flex-1 px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
        />
        <button
          onClick={handleSendMessage}
          className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 transition-colors"
        >
          <Icon name="Send" size={16} />
        </button>
      </div>
    </div>
  );

  const renderContact = () => (
    <div className="space-y-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-text-primary mb-2">
          Contact Information
        </h3>
        <p className="text-text-secondary">
          Get in touch with our verification team directly.
        </p>
      </div>
      
      <div className="grid gap-4">
        <div className="bg-surface rounded-lg p-4">
          <div className="flex items-center space-x-3 mb-2">
            <Icon name="Phone" size={20} className="text-primary" />
            <h4 className="font-medium text-text-primary">Phone Support</h4>
          </div>
          <p className="text-text-secondary mb-2">(555) 123-4567</p>
          <p className="text-sm text-text-muted">
            Monday - Friday: 9:00 AM - 6:00 PM EST
          </p>
        </div>
        
        <div className="bg-surface rounded-lg p-4">
          <div className="flex items-center space-x-3 mb-2">
            <Icon name="Mail" size={20} className="text-primary" />
            <h4 className="font-medium text-text-primary">Email Support</h4>
          </div>
          <p className="text-text-secondary mb-2">verification@impacthub.org</p>
          <p className="text-sm text-text-muted">
            Response time: Within 24 hours
          </p>
        </div>
        
        <div className="bg-surface rounded-lg p-4">
          <div className="flex items-center space-x-3 mb-2">
            <Icon name="Calendar" size={20} className="text-primary" />
            <h4 className="font-medium text-text-primary">Schedule a Call</h4>
          </div>
          <p className="text-text-secondary mb-3">
            Book a 15-minute consultation with our verification team
          </p>
          <button className="btn-primary text-sm px-4 py-2">
            Schedule Call
          </button>
        </div>
        
        <div className="bg-surface rounded-lg p-4">
          <div className="flex items-center space-x-3 mb-2">
            <Icon name="Video" size={20} className="text-primary" />
            <h4 className="font-medium text-text-primary">Video Walkthrough</h4>
          </div>
          <p className="text-text-secondary mb-3">
            Watch a step-by-step guide to the verification process
          </p>
          <button className="border border-border text-text-primary px-4 py-2 rounded-lg hover:bg-surface transition-colors text-sm">
            Watch Video
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center space-x-3">
            <Icon name="LifeBuoy" size={24} className="text-primary" />
            <h2 className="text-xl font-bold text-text-primary">Help Center</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-text-muted hover:text-text-primary hover:bg-surface rounded-lg transition-colors"
          >
            <Icon name="X" size={20} />
          </button>
        </div>
        
        {/* Tab Navigation */}
        <div className="border-b border-border">
          <nav className="flex px-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-4 py-3 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary hover:border-border'
                }`}
              >
                <Icon name={tab.icon} size={16} />
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>
        
        {/* Content */}
        <div className="p-6 max-h-96 overflow-y-auto">
          {activeTab === 'faq' && renderFAQ()}
          {activeTab === 'chat' && renderChat()}
          {activeTab === 'contact' && renderContact()}
        </div>
      </div>
    </div>
  );
};

export default HelpCenter;