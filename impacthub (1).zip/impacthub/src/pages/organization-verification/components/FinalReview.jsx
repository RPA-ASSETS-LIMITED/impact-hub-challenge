// src/pages/organization-verification/components/FinalReview.jsx
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const FinalReview = ({ verificationData, onSubmit, onExpedite }) => {
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [showExpediteModal, setShowExpediteModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = () => {
    if (!agreedToTerms) return;
    
    setIsSubmitting(true);
    
    // Simulate submission delay
    setTimeout(() => {
      onSubmit();
      setIsSubmitting(false);
    }, 2000);
  };

  const handleExpediteRequest = () => {
    onExpedite();
    setShowExpediteModal(false);
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getEntityTypeLabel = (type) => {
    const labels = {
      '501c3': '501(c)(3) Nonprofit',
      'bcorp': 'B-Corporation',
      'social-enterprise': 'Social Enterprise',
      'international-ngo': 'International NGO'
    };
    return labels[type] || type;
  };

  if (verificationData?.status === 'submitted') {
    return (
      <div className="p-8 text-center">
        <div className="max-w-md mx-auto">
          <div className="mb-6">
            <div className="mx-auto w-16 h-16 bg-success-100 rounded-full flex items-center justify-center mb-4">
              <Icon name="CheckCircle2" size={32} className="text-success" />
            </div>
            <h2 className="text-2xl font-bold text-text-primary mb-2">
              Verification Submitted!
            </h2>
            <p className="text-text-secondary">
              Thank you for submitting your verification application. We'll review your information and get back to you soon.
            </p>
          </div>
          
          <div className="bg-primary-50 rounded-lg p-6 mb-6">
            <h3 className="font-semibold text-primary mb-2">What Happens Next?</h3>
            <ul className="text-sm text-primary-700 space-y-2 text-left">
              <li className="flex items-center space-x-2">
                <Icon name="Clock" size={14} />
                <span>Review typically takes 3-5 business days</span>
              </li>
              <li className="flex items-center space-x-2">
                <Icon name="Mail" size={14} />
                <span>You'll receive email updates on your application status</span>
              </li>
              <li className="flex items-center space-x-2">
                <Icon name="Phone" size={14} />
                <span>Our team may contact you if additional information is needed</span>
              </li>
            </ul>
          </div>
          
          <div className="space-y-3">
            <Link 
              to="/software-catalog"
              className="block w-full btn-primary py-3"
            >
              Browse Software Catalog
            </Link>
            <Link 
              to="/"
              className="block w-full border border-border text-text-primary py-3 rounded-lg hover:bg-surface transition-colors"
            >
              Return to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-text-primary mb-2">
          Final Review
        </h2>
        <p className="text-text-secondary">
          Please review all the information you've provided before submitting your verification application.
        </p>
      </div>

      <div className="space-y-8">
        {/* Organization Information */}
        <div className="bg-white rounded-xl border border-border p-6">
          <div className="flex items-center space-x-3 mb-4">
            <Icon name="Building" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-text-primary">Organization Information</h3>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1">
                Organization Name
              </label>
              <p className="text-text-primary font-medium">{verificationData?.organizationName}</p>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-text-secondary mb-1">
                EIN / Tax ID
              </label>
              <p className="text-text-primary font-medium">{verificationData?.ein}</p>
            </div>
            
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-text-secondary mb-1">
                Entity Type
              </label>
              <p className="text-text-primary font-medium">
                {getEntityTypeLabel(verificationData?.entityType)}
              </p>
            </div>
          </div>
        </div>

        {/* Documents */}
        <div className="bg-white rounded-xl border border-border p-6">
          <div className="flex items-center space-x-3 mb-4">
            <Icon name="FileText" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-text-primary">Uploaded Documents</h3>
          </div>
          
          {verificationData?.documents && verificationData.documents.length > 0 ? (
            <div className="space-y-3">
              {verificationData.documents.map((doc, index) => (
                <div key={doc.id || index} className="flex items-center justify-between p-3 bg-surface rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Icon name="FileCheck" size={16} className="text-success" />
                    <div>
                      <p className="font-medium text-text-primary">{doc.name}</p>
                      <p className="text-sm text-text-secondary">
                        {formatFileSize(doc.size)} • Uploaded {new Date(doc.uploadDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="bg-success-50 text-success px-3 py-1 rounded-full text-sm font-medium">
                    Verified
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-text-secondary">No documents uploaded</p>
          )}
        </div>

        {/* Impact Information */}
        <div className="bg-white rounded-xl border border-border p-6">
          <div className="flex items-center space-x-3 mb-4">
            <Icon name="Target" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-text-primary">Impact Information</h3>
          </div>
          
          {/* Mission */}
          {verificationData?.impactData?.mission && (
            <div className="mb-4">
              <label className="block text-sm font-medium text-text-secondary mb-2">
                Mission Statement
              </label>
              <p className="text-text-primary bg-surface rounded-lg p-3">
                {verificationData.impactData.mission}
              </p>
            </div>
          )}
          
          {/* Metrics */}
          {verificationData?.impactData?.metrics && verificationData.impactData.metrics.length > 0 && (
            <div className="mb-4">
              <label className="block text-sm font-medium text-text-secondary mb-2">
                Impact Metrics ({verificationData.impactData.metrics.length})
              </label>
              <div className="grid md:grid-cols-2 gap-3">
                {verificationData.impactData.metrics.map((metric) => (
                  <div key={metric.id} className="bg-surface rounded-lg p-3">
                    <p className="font-medium text-text-primary">{metric.name}</p>
                    <p className="text-sm text-text-secondary">
                      {metric.value} {metric.unit}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Programs and Testimonials counts */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-surface rounded-lg p-3">
              <p className="text-sm text-text-secondary">Programs Added</p>
              <p className="text-lg font-semibold text-text-primary">
                {verificationData?.impactData?.programs?.length || 0}
              </p>
            </div>
            <div className="bg-surface rounded-lg p-3">
              <p className="text-sm text-text-secondary">Testimonials Added</p>
              <p className="text-lg font-semibold text-text-primary">
                {verificationData?.impactData?.testimonials?.length || 0}
              </p>
            </div>
          </div>
        </div>

        {/* Processing Timeline */}
        <div className="bg-gradient-to-r from-primary-50 to-secondary-50 rounded-xl border border-primary-100 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <Icon name="Clock" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-text-primary">Processing Timeline</h3>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-primary mb-2">Standard Review</h4>
              <p className="text-sm text-primary-700 mb-3">
                3-5 business days • Free
              </p>
              <ul className="text-sm text-primary-600 space-y-1">
                <li>• Thorough document review</li>
                <li>• Impact validation</li>
                <li>• Email status updates</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-secondary mb-2">Expedited Review</h4>
              <p className="text-sm text-secondary-700 mb-3">
                24-48 hours • Priority support
              </p>
              <ul className="text-sm text-secondary-600 space-y-1">
                <li>• Fast-track processing</li>
                <li>• Video call with specialist</li>
                <li>• Real-time support</li>
              </ul>
              <button
                onClick={() => setShowExpediteModal(true)}
                className="mt-3 text-sm text-secondary hover:text-secondary-700 font-medium flex items-center space-x-1"
              >
                <Icon name="Zap" size={14} />
                <span>Request Expedited Review</span>
              </button>
            </div>
          </div>
        </div>

        {/* Terms and Conditions */}
        <div className="bg-white rounded-xl border border-border p-6">
          <div className="flex items-start space-x-3">
            <input
              type="checkbox"
              id="terms"
              checked={agreedToTerms}
              onChange={(e) => setAgreedToTerms(e.target.checked)}
              className="mt-1 h-4 w-4 text-primary border-border rounded focus:ring-primary"
            />
            <div>
              <label htmlFor="terms" className="text-sm text-text-primary cursor-pointer">
                I agree to the{' '}
                <Link to="/terms" className="text-primary hover:text-primary-700 underline">
                  Terms of Service
                </Link>{' '}
                and{' '}
                <Link to="/privacy" className="text-primary hover:text-primary-700 underline">
                  Privacy Policy
                </Link>
                . I confirm that all information provided is accurate and truthful.
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-between pt-8 border-t border-border mt-8">
        <button
          onClick={() => window.history.back()}
          className="px-6 py-3 text-text-secondary hover:text-text-primary transition-colors flex items-center space-x-2"
        >
          <Icon name="ArrowLeft" size={16} />
          <span>Back to Impact Validation</span>
        </button>
        
        <button
          onClick={handleSubmit}
          disabled={!agreedToTerms || isSubmitting}
          className={`px-8 py-3 rounded-lg font-semibold flex items-center space-x-2 transition-all ${
            agreedToTerms && !isSubmitting
              ? 'bg-success text-white hover:bg-success-600' :'bg-surface text-text-muted cursor-not-allowed'
          }`}
        >
          {isSubmitting ? (
            <>
              <Icon name="Loader" size={16} className="animate-spin" />
              <span>Submitting...</span>
            </>
          ) : (
            <>
              <Icon name="Send" size={16} />
              <span>Submit for Verification</span>
            </>
          )}
        </button>
      </div>

      {/* Expedite Modal */}
      {showExpediteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full p-6">
            <div className="flex items-center space-x-3 mb-4">
              <Icon name="Zap" size={24} className="text-secondary" />
              <h3 className="text-lg font-semibold text-text-primary">
                Request Expedited Review
              </h3>
            </div>
            
            <p className="text-text-secondary mb-6">
              Get your verification completed in 24-48 hours with priority support and a video call with our verification specialist.
            </p>
            
            <div className="bg-secondary-50 rounded-lg p-4 mb-6">
              <h4 className="font-medium text-secondary mb-2">Expedited Benefits:</h4>
              <ul className="text-sm text-secondary-700 space-y-1">
                <li>• Priority queue processing</li>
                <li>• 30-minute video consultation</li>
                <li>• Real-time status updates</li>
                <li>• Dedicated support specialist</li>
              </ul>
            </div>
            
            <div className="flex space-x-3">
              <button
                onClick={() => setShowExpediteModal(false)}
                className="flex-1 px-4 py-2 border border-border text-text-primary rounded-lg hover:bg-surface transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleExpediteRequest}
                className="flex-1 px-4 py-2 bg-secondary text-white rounded-lg hover:bg-secondary-700 transition-colors"
              >
                Request Expedite
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FinalReview;