// src/pages/organization-verification/components/ImpactValidation.jsx
import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const ImpactValidation = ({ impactData, onDataUpdate, onNext }) => {
  const [activeTab, setActiveTab] = useState('mission');
  const [newMetric, setNewMetric] = useState({ name: '', value: '', unit: '' });
  const [newTestimonial, setNewTestimonial] = useState({ name: '', role: '', content: '', organization: '' });
  const [newProgram, setNewProgram] = useState({ name: '', description: '', beneficiaries: '', outcomes: '' });
  const [errors, setErrors] = useState({});

  const tabs = [
    { id: 'mission', label: 'Mission & Story', icon: 'Target' },
    { id: 'metrics', label: 'Impact Metrics', icon: 'TrendingUp' },
    { id: 'testimonials', label: 'Testimonials', icon: 'MessageSquare' },
    { id: 'programs', label: 'Programs', icon: 'Layers' }
  ];

  const handleMissionChange = (value) => {
    onDataUpdate({
      ...impactData,
      mission: value
    });
    if (errors.mission) {
      setErrors(prev => ({ ...prev, mission: null }));
    }
  };

  const addMetric = () => {
    if (newMetric.name && newMetric.value) {
      const updatedMetrics = [...(impactData?.metrics || []), {
        id: Date.now(),
        ...newMetric
      }];
      onDataUpdate({
        ...impactData,
        metrics: updatedMetrics
      });
      setNewMetric({ name: '', value: '', unit: '' });
    }
  };

  const removeMetric = (id) => {
    const updatedMetrics = impactData?.metrics?.filter(metric => metric.id !== id) || [];
    onDataUpdate({
      ...impactData,
      metrics: updatedMetrics
    });
  };

  const addTestimonial = () => {
    if (newTestimonial.name && newTestimonial.content) {
      const updatedTestimonials = [...(impactData?.testimonials || []), {
        id: Date.now(),
        ...newTestimonial
      }];
      onDataUpdate({
        ...impactData,
        testimonials: updatedTestimonials
      });
      setNewTestimonial({ name: '', role: '', content: '', organization: '' });
    }
  };

  const removeTestimonial = (id) => {
    const updatedTestimonials = impactData?.testimonials?.filter(testimonial => testimonial.id !== id) || [];
    onDataUpdate({
      ...impactData,
      testimonials: updatedTestimonials
    });
  };

  const addProgram = () => {
    if (newProgram.name && newProgram.description) {
      const updatedPrograms = [...(impactData?.programs || []), {
        id: Date.now(),
        ...newProgram
      }];
      onDataUpdate({
        ...impactData,
        programs: updatedPrograms
      });
      setNewProgram({ name: '', description: '', beneficiaries: '', outcomes: '' });
    }
  };

  const removeProgram = (id) => {
    const updatedPrograms = impactData?.programs?.filter(program => program.id !== id) || [];
    onDataUpdate({
      ...impactData,
      programs: updatedPrograms
    });
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!impactData?.mission?.trim()) {
      newErrors.mission = 'Mission statement is required';
    }
    
    if (!impactData?.metrics?.length) {
      newErrors.metrics = 'At least one impact metric is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateForm()) {
      onNext();
    }
  };

  const renderMissionTab = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-text-primary mb-2">
          Organization Mission <span className="text-error">*</span>
        </label>
        <p className="text-sm text-text-secondary mb-3">
          Describe your organization's mission and the social problem you're addressing.
        </p>
        <textarea
          rows={6}
          placeholder="Tell us about your mission, the problem you're solving, and the impact you're making..."
          value={impactData?.mission || ''}
          onChange={(e) => handleMissionChange(e.target.value)}
          className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition-colors resize-none ${
            errors.mission ? 'border-error' : 'border-border'
          }`}
        />
        {errors.mission && (
          <p className="mt-1 text-sm text-error flex items-center space-x-1">
            <Icon name="AlertCircle" size={14} />
            <span>{errors.mission}</span>
          </p>
        )}
        <p className="mt-2 text-sm text-text-muted">
          {impactData?.mission?.length || 0}/1000 characters
        </p>
      </div>
    </div>
  );

  const renderMetricsTab = () => (
    <div className="space-y-6">
      <div>
        <h4 className="font-semibold text-text-primary mb-3">
          Impact Metrics <span className="text-error">*</span>
        </h4>
        <p className="text-sm text-text-secondary mb-4">
          Share quantifiable measures of your organization's impact.
        </p>
        
        {/* Add New Metric */}
        <div className="bg-surface rounded-lg p-4 mb-4">
          <h5 className="font-medium text-text-primary mb-3">Add Impact Metric</h5>
          <div className="grid md:grid-cols-3 gap-3">
            <input
              type="text"
              placeholder="Metric name (e.g., People Served)"
              value={newMetric.name}
              onChange={(e) => setNewMetric({...newMetric, name: e.target.value})}
              className="px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
            />
            <input
              type="text"
              placeholder="Value (e.g., 1,250)"
              value={newMetric.value}
              onChange={(e) => setNewMetric({...newMetric, value: e.target.value})}
              className="px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
            />
            <div className="flex space-x-2">
              <input
                type="text"
                placeholder="Unit (optional)"
                value={newMetric.unit}
                onChange={(e) => setNewMetric({...newMetric, unit: e.target.value})}
                className="flex-1 px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
              />
              <button
                onClick={addMetric}
                className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 transition-colors"
              >
                <Icon name="Plus" size={16} />
              </button>
            </div>
          </div>
        </div>
        
        {/* Metrics List */}
        {impactData?.metrics && impactData.metrics.length > 0 && (
          <div className="space-y-3">
            {impactData.metrics.map((metric) => (
              <div key={metric.id} className="flex items-center justify-between p-4 bg-white rounded-lg border border-border">
                <div>
                  <h6 className="font-medium text-text-primary">{metric.name}</h6>
                  <p className="text-sm text-text-secondary">
                    {metric.value} {metric.unit}
                  </p>
                </div>
                <button
                  onClick={() => removeMetric(metric.id)}
                  className="p-2 text-text-muted hover:text-error hover:bg-error-50 rounded-lg transition-colors"
                >
                  <Icon name="Trash2" size={16} />
                </button>
              </div>
            ))}
          </div>
        )}
        
        {errors.metrics && (
          <p className="mt-2 text-sm text-error flex items-center space-x-1">
            <Icon name="AlertCircle" size={14} />
            <span>{errors.metrics}</span>
          </p>
        )}
      </div>
    </div>
  );

  const renderTestimonialsTab = () => (
    <div className="space-y-6">
      <div>
        <h4 className="font-semibold text-text-primary mb-3">Testimonials</h4>
        <p className="text-sm text-text-secondary mb-4">
          Share testimonials from beneficiaries, partners, or community members.
        </p>
        
        {/* Add New Testimonial */}
        <div className="bg-surface rounded-lg p-4 mb-4">
          <h5 className="font-medium text-text-primary mb-3">Add Testimonial</h5>
          <div className="space-y-3">
            <div className="grid md:grid-cols-2 gap-3">
              <input
                type="text"
                placeholder="Name"
                value={newTestimonial.name}
                onChange={(e) => setNewTestimonial({...newTestimonial, name: e.target.value})}
                className="px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
              />
              <input
                type="text"
                placeholder="Role/Title"
                value={newTestimonial.role}
                onChange={(e) => setNewTestimonial({...newTestimonial, role: e.target.value})}
                className="px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
              />
            </div>
            <input
              type="text"
              placeholder="Organization (optional)"
              value={newTestimonial.organization}
              onChange={(e) => setNewTestimonial({...newTestimonial, organization: e.target.value})}
              className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
            />
            <textarea
              rows={3}
              placeholder="Testimonial content..."
              value={newTestimonial.content}
              onChange={(e) => setNewTestimonial({...newTestimonial, content: e.target.value})}
              className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary resize-none"
            />
            <button
              onClick={addTestimonial}
              className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 transition-colors flex items-center space-x-2"
            >
              <Icon name="Plus" size={16} />
              <span>Add Testimonial</span>
            </button>
          </div>
        </div>
        
        {/* Testimonials List */}
        {impactData?.testimonials && impactData.testimonials.length > 0 && (
          <div className="space-y-3">
            {impactData.testimonials.map((testimonial) => (
              <div key={testimonial.id} className="p-4 bg-white rounded-lg border border-border">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h6 className="font-medium text-text-primary">{testimonial.name}</h6>
                    <p className="text-sm text-text-secondary">
                      {testimonial.role}
                      {testimonial.organization && ` at ${testimonial.organization}`}
                    </p>
                  </div>
                  <button
                    onClick={() => removeTestimonial(testimonial.id)}
                    className="p-2 text-text-muted hover:text-error hover:bg-error-50 rounded-lg transition-colors"
                  >
                    <Icon name="Trash2" size={16} />
                  </button>
                </div>
                <p className="text-text-secondary italic">"{testimonial.content}"</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  const renderProgramsTab = () => (
    <div className="space-y-6">
      <div>
        <h4 className="font-semibold text-text-primary mb-3">Programs & Initiatives</h4>
        <p className="text-sm text-text-secondary mb-4">
          Describe your key programs and their outcomes.
        </p>
        
        {/* Add New Program */}
        <div className="bg-surface rounded-lg p-4 mb-4">
          <h5 className="font-medium text-text-primary mb-3">Add Program</h5>
          <div className="space-y-3">
            <input
              type="text"
              placeholder="Program name"
              value={newProgram.name}
              onChange={(e) => setNewProgram({...newProgram, name: e.target.value})}
              className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
            />
            <textarea
              rows={3}
              placeholder="Program description..."
              value={newProgram.description}
              onChange={(e) => setNewProgram({...newProgram, description: e.target.value})}
              className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary resize-none"
            />
            <div className="grid md:grid-cols-2 gap-3">
              <input
                type="text"
                placeholder="Target beneficiaries"
                value={newProgram.beneficiaries}
                onChange={(e) => setNewProgram({...newProgram, beneficiaries: e.target.value})}
                className="px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
              />
              <input
                type="text"
                placeholder="Key outcomes"
                value={newProgram.outcomes}
                onChange={(e) => setNewProgram({...newProgram, outcomes: e.target.value})}
                className="px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
              />
            </div>
            <button
              onClick={addProgram}
              className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 transition-colors flex items-center space-x-2"
            >
              <Icon name="Plus" size={16} />
              <span>Add Program</span>
            </button>
          </div>
        </div>
        
        {/* Programs List */}
        {impactData?.programs && impactData.programs.length > 0 && (
          <div className="space-y-3">
            {impactData.programs.map((program) => (
              <div key={program.id} className="p-4 bg-white rounded-lg border border-border">
                <div className="flex justify-between items-start mb-3">
                  <h6 className="font-medium text-text-primary">{program.name}</h6>
                  <button
                    onClick={() => removeProgram(program.id)}
                    className="p-2 text-text-muted hover:text-error hover:bg-error-50 rounded-lg transition-colors"
                  >
                    <Icon name="Trash2" size={16} />
                  </button>
                </div>
                <p className="text-text-secondary mb-2">{program.description}</p>
                {(program.beneficiaries || program.outcomes) && (
                  <div className="grid md:grid-cols-2 gap-3 text-sm">
                    {program.beneficiaries && (
                      <div>
                        <span className="font-medium text-text-primary">Beneficiaries: </span>
                        <span className="text-text-secondary">{program.beneficiaries}</span>
                      </div>
                    )}
                    {program.outcomes && (
                      <div>
                        <span className="font-medium text-text-primary">Outcomes: </span>
                        <span className="text-text-secondary">{program.outcomes}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-text-primary mb-2">
          Impact Validation
        </h2>
        <p className="text-text-secondary">
          Showcase your organization's mission and demonstrate the impact you're making in your community.
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="mb-8">
        <div className="border-b border-border">
          <nav className="flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 pb-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary hover:border-border'
                }`}
              >
                <Icon name={tab.icon} size={16} />
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Tab Content */}
      <div className="mb-8">
        {activeTab === 'mission' && renderMissionTab()}
        {activeTab === 'metrics' && renderMetricsTab()}
        {activeTab === 'testimonials' && renderTestimonialsTab()}
        {activeTab === 'programs' && renderProgramsTab()}
      </div>

      {/* Action Buttons */}
      <div className="flex justify-between pt-6 border-t border-border">
        <button
          onClick={() => window.history.back()}
          className="px-6 py-3 text-text-secondary hover:text-text-primary transition-colors flex items-center space-x-2"
        >
          <Icon name="ArrowLeft" size={16} />
          <span>Back to Documents</span>
        </button>
        
        <button
          onClick={handleNext}
          className="btn-primary px-8 py-3 flex items-center space-x-2"
        >
          <span>Continue to Review</span>
          <Icon name="ArrowRight" size={16} />
        </button>
      </div>
    </div>
  );
};

export default ImpactValidation;