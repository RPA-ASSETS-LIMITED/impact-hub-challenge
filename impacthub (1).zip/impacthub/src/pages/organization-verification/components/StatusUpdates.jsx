// src/pages/organization-verification/components/StatusUpdates.jsx
import React from 'react';
import Icon from '../../../components/AppIcon';

const StatusUpdates = ({ status, estimatedCompletion, expediteScheduled }) => {
  const getStatusInfo = () => {
    switch (status) {
      case 'in-progress':
        return {
          icon: 'Clock',
          color: 'text-warning',
          bgColor: 'bg-warning-50',
          borderColor: 'border-warning-100',
          title: 'In Progress',
          description: 'Your verification is being processed'
        };
      case 'submitted':
        return {
          icon: 'Send',
          color: 'text-primary',
          bgColor: 'bg-primary-50',
          borderColor: 'border-primary-100',
          title: 'Submitted',
          description: 'Application submitted for review'
        };
      case 'under-review':
        return {
          icon: 'Eye',
          color: 'text-secondary',
          bgColor: 'bg-secondary-50',
          borderColor: 'border-secondary-100',
          title: 'Under Review',
          description: 'Our team is reviewing your documents'
        };
      case 'approved':
        return {
          icon: 'CheckCircle2',
          color: 'text-success',
          bgColor: 'bg-success-50',
          borderColor: 'border-success-100',
          title: 'Approved',
          description: 'Verification completed successfully'
        };
      case 'needs-attention':
        return {
          icon: 'AlertTriangle',
          color: 'text-error',
          bgColor: 'bg-error-50',
          borderColor: 'border-error-100',
          title: 'Needs Attention',
          description: 'Additional information required'
        };
      default:
        return {
          icon: 'Circle',
          color: 'text-text-muted',
          bgColor: 'bg-surface',
          borderColor: 'border-border',
          title: 'Not Started',
          description: 'Begin your verification process'
        };
    }
  };

  const statusInfo = getStatusInfo();

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (dateString) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  return (
    <div className="space-y-4">
      {/* Current Status */}
      <div className={`rounded-xl border p-6 ${statusInfo.bgColor} ${statusInfo.borderColor}`}>
        <div className="flex items-center space-x-3 mb-3">
          <div className={`p-2 rounded-full bg-white ${statusInfo.color}`}>
            <Icon name={statusInfo.icon} size={16} />
          </div>
          <div>
            <h3 className={`font-semibold ${statusInfo.color}`}>
              {statusInfo.title}
            </h3>
            <p className={`text-sm ${statusInfo.color.replace('text-', 'text-').replace(/-(\d+)$/, '-700')}`}>
              {statusInfo.description}
            </p>
          </div>
        </div>
        
        {/* Estimated Completion */}
        {estimatedCompletion && (
          <div className="flex items-center space-x-2 text-sm">
            <Icon name="Calendar" size={14} className={statusInfo.color} />
            <span className={statusInfo.color.replace('text-', 'text-').replace(/-(\d+)$/, '-700')}>
              Expected completion: {formatDate(estimatedCompletion)}
            </span>
          </div>
        )}
      </div>

      {/* Expedited Review Info */}
      {expediteScheduled && (
        <div className="bg-secondary-50 border border-secondary-100 rounded-xl p-6">
          <div className="flex items-center space-x-3 mb-3">
            <div className="p-2 rounded-full bg-white text-secondary">
              <Icon name="Zap" size={16} />
            </div>
            <div>
              <h3 className="font-semibold text-secondary">
                Expedited Review Scheduled
              </h3>
              <p className="text-sm text-secondary-700">
                Priority processing activated
              </p>
            </div>
          </div>
          
          <div className="space-y-2 text-sm text-secondary-700">
            <div className="flex items-center space-x-2">
              <Icon name="Calendar" size={14} />
              <span>Video call: {formatDate(expediteScheduled)}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Clock" size={14} />
              <span>Time: {formatTime(expediteScheduled)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Processing Steps */}
      <div className="bg-white rounded-xl shadow-soft border border-border p-6">
        <h3 className="font-semibold text-text-primary mb-4 flex items-center space-x-2">
          <Icon name="List" size={16} className="text-primary" />
          <span>Processing Steps</span>
        </h3>
        
        <div className="space-y-3">
          <div className="flex items-center space-x-3 text-sm">
            <Icon name="CheckCircle2" size={16} className="text-success" />
            <span className="text-text-primary">Initial review completed</span>
          </div>
          
          <div className="flex items-center space-x-3 text-sm">
            <Icon 
              name={status === 'under-review' ? "Clock" : "CheckCircle2"} 
              size={16} 
              className={status === 'under-review' ? "text-warning" : "text-success"}
            />
            <span className="text-text-primary">Document verification</span>
          </div>
          
          <div className="flex items-center space-x-3 text-sm">
            <Icon 
              name={status === 'approved' ? "CheckCircle2" : "Circle"} 
              size={16} 
              className={status === 'approved' ? "text-success" : "text-text-muted"}
            />
            <span className="text-text-primary">Impact validation</span>
          </div>
          
          <div className="flex items-center space-x-3 text-sm">
            <Icon 
              name={status === 'approved' ? "CheckCircle2" : "Circle"} 
              size={16} 
              className={status === 'approved' ? "text-success" : "text-text-muted"}
            />
            <span className="text-text-primary">Final approval</span>
          </div>
        </div>
      </div>

      {/* Help & Support */}
      <div className="bg-white rounded-xl shadow-soft border border-border p-6">
        <h3 className="font-semibold text-text-primary mb-4 flex items-center space-x-2">
          <Icon name="MessageCircle" size={16} className="text-primary" />
          <span>Need Updates?</span>
        </h3>
        
        <div className="space-y-3 text-sm">
          <div className="flex items-center space-x-3">
            <Icon name="Mail" size={14} className="text-text-muted" />
            <span className="text-text-secondary">
              Email notifications sent to your registered address
            </span>
          </div>
          
          <div className="flex items-center space-x-3">
            <Icon name="Bell" size={14} className="text-text-muted" />
            <span className="text-text-secondary">
              In-app notifications for status changes
            </span>
          </div>
          
          <div className="flex items-center space-x-3">
            <Icon name="Phone" size={14} className="text-text-muted" />
            <span className="text-text-secondary">
              Call support: (555) 123-4567
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatusUpdates;