// src/pages/organization-verification/components/EntityTypeSelector.jsx
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const EntityTypeSelector = ({
  entityTypes,
  selectedType,
  organizationName,
  ein,
  onTypeSelect,
  onNameChange,
  onEinChange,
  onNext
}) => {
  const [errors, setErrors] = useState({});
  const [showRequirements, setShowRequirements] = useState({});

  const validateForm = () => {
    const newErrors = {};
    
    if (!selectedType) {
      newErrors.entityType = 'Please select your organization type';
    }
    
    if (!organizationName?.trim()) {
      newErrors.organizationName = 'Organization name is required';
    }
    
    if (!ein?.trim()) {
      newErrors.ein = 'EIN/Tax ID is required';
    } else if (!/^\d{2}-?\d{7}$/.test(ein.trim())) {
      newErrors.ein = 'Please enter a valid EIN format (XX-XXXXXXX)';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateForm()) {
      onNext();
    }
  };

  const formatEIN = (value) => {
    // Remove all non-digits
    const digits = value.replace(/\D/g, '');
    // Add hyphen after first 2 digits
    if (digits.length >= 2) {
      return `${digits.slice(0, 2)}-${digits.slice(2, 9)}`;
    }
    return digits;
  };

  const handleEINChange = (e) => {
    const formatted = formatEIN(e.target.value);
    onEinChange(formatted);
    // Clear error when user starts typing
    if (errors.ein) {
      setErrors(prev => ({ ...prev, ein: null }));
    }
  };

  const toggleRequirements = (typeId) => {
    setShowRequirements(prev => ({
      ...prev,
      [typeId]: !prev[typeId]
    }));
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-text-primary mb-2">
          Basic Information
        </h2>
        <p className="text-text-secondary">
          Start by telling us about your organization and selecting your entity type.
        </p>
      </div>

      {/* Organization Details Form */}
      <div className="mb-8 space-y-6">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Organization Name <span className="text-error">*</span>
          </label>
          <input
            type="text"
            placeholder="Enter your organization's legal name"
            value={organizationName || ''}
            onChange={(e) => {
              onNameChange(e.target.value);
              if (errors.organizationName) {
                setErrors(prev => ({ ...prev, organizationName: null }));
              }
            }}
            className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition-colors ${
              errors.organizationName ? 'border-error' : 'border-border'
            }`}
          />
          {errors.organizationName && (
            <p className="mt-1 text-sm text-error flex items-center space-x-1">
              <Icon name="AlertCircle" size={14} />
              <span>{errors.organizationName}</span>
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            EIN / Tax ID Number <span className="text-error">*</span>
          </label>
          <input
            type="text"
            placeholder="XX-XXXXXXX"
            value={ein || ''}
            onChange={handleEINChange}
            maxLength={10}
            className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition-colors ${
              errors.ein ? 'border-error' : 'border-border'
            }`}
          />
          {errors.ein && (
            <p className="mt-1 text-sm text-error flex items-center space-x-1">
              <Icon name="AlertCircle" size={14} />
              <span>{errors.ein}</span>
            </p>
          )}
          <p className="mt-1 text-sm text-text-muted">
            Enter your Employer Identification Number as it appears on your tax documents
          </p>
        </div>
      </div>

      {/* Entity Type Selection */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-text-primary mb-4">
          Select Your Organization Type <span className="text-error">*</span>
        </h3>
        
        <div className="grid md:grid-cols-2 gap-4">
          {entityTypes?.map((type) => {
            const isSelected = selectedType === type.id;
            return (
              <div key={type.id} className="relative">
                <div
                  className={`p-6 border-2 rounded-xl cursor-pointer transition-all duration-200 hover:shadow-soft ${
                    isSelected 
                      ? 'border-primary bg-primary-50 shadow-soft' 
                      : 'border-border hover:border-primary-200'
                  }`}
                  onClick={() => {
                    onTypeSelect(type.id);
                    if (errors.entityType) {
                      setErrors(prev => ({ ...prev, entityType: null }));
                    }
                  }}
                >
                  <div className="flex items-start space-x-4">
                    <div className={`p-3 rounded-lg ${
                      isSelected ? 'bg-primary-100 text-primary' : 'bg-surface text-text-muted'
                    }`}>
                      <Icon name={type.icon} size={24} />
                    </div>
                    
                    <div className="flex-1">
                      <h4 className={`font-semibold mb-2 ${
                        isSelected ? 'text-primary' : 'text-text-primary'
                      }`}>
                        {type.title}
                      </h4>
                      <p className="text-sm text-text-secondary mb-3">
                        {type.description}
                      </p>
                      
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleRequirements(type.id);
                        }}
                        className="flex items-center space-x-1 text-sm text-primary hover:text-primary-700 transition-colors"
                      >
                        <Icon name="FileText" size={14} />
                        <span>View Requirements</span>
                        <Icon 
                          name={showRequirements[type.id] ? 'ChevronUp' : 'ChevronDown'} 
                          size={14} 
                        />
                      </button>
                    </div>
                    
                    {isSelected && (
                      <div className="text-primary">
                        <Icon name="CheckCircle2" size={24} />
                      </div>
                    )}
                  </div>
                  
                  {/* Requirements Dropdown */}
                  {showRequirements[type.id] && (
                    <div className="mt-4 pt-4 border-t border-border">
                      <h5 className="text-sm font-medium text-text-primary mb-2">
                        Required Documents:
                      </h5>
                      <ul className="space-y-1">
                        {type.requirements?.map((req, index) => (
                          <li key={index} className="flex items-center space-x-2 text-sm text-text-secondary">
                            <Icon name="Check" size={12} className="text-success" />
                            <span>{req}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        
        {errors.entityType && (
          <p className="mt-2 text-sm text-error flex items-center space-x-1">
            <Icon name="AlertCircle" size={14} />
            <span>{errors.entityType}</span>
          </p>
        )}
      </div>

      {/* Help Text */}
      <div className="mb-8 p-4 bg-primary-50 rounded-lg border border-primary-100">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={20} className="text-primary mt-0.5" />
          <div>
            <h4 className="font-medium text-primary mb-1">Not sure which type applies to you?</h4>
            <p className="text-sm text-primary-700">
              Each organization type has different verification requirements. Selecting the correct type 
              ensures we can process your application efficiently.
            </p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-between pt-6 border-t border-border">
        <Link 
          to="/"
          className="px-6 py-3 text-text-secondary hover:text-text-primary transition-colors"
        >
          ← Back to Home
        </Link>
        
        <button
          onClick={handleNext}
          className="btn-primary px-8 py-3 flex items-center space-x-2"
        >
          <span>Continue to Documents</span>
          <Icon name="ArrowRight" size={16} />
        </button>
      </div>
    </div>
  );
};

export default EntityTypeSelector;