// src/pages/organization-verification/components/DocumentUpload.jsx
import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';

const DocumentUpload = ({ 
  entityType, 
  documents, 
  uploadProgress, 
  onUpload, 
  onNext,
  showMobileCapture,
  setShowMobileCapture 
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [showChecklist, setShowChecklist] = useState(false);
  const fileInputRef = useRef(null);
  const cameraInputRef = useRef(null);

  const getRequiredDocuments = () => {
    const docMap = {
      '501c3': [
        { name: 'IRS Determination Letter', required: true, formats: ['PDF', 'JPG', 'PNG'] },
        { name: 'Form 990 (Most Recent)', required: true, formats: ['PDF'] },
        { name: 'State Registration Certificate', required: true, formats: ['PDF', 'JPG', 'PNG'] },
        { name: 'Board Resolution (Optional)', required: false, formats: ['PDF', 'DOC', 'DOCX'] }
      ],
      'bcorp': [
        { name: 'B-Corp Certification', required: true, formats: ['PDF'] },
        { name: 'Articles of Incorporation', required: true, formats: ['PDF', 'JPG', 'PNG'] },
        { name: 'Impact Assessment Report', required: true, formats: ['PDF'] },
        { name: 'Annual Disclosure Report', required: false, formats: ['PDF'] }
      ],
      'social-enterprise': [
        { name: 'Business Registration', required: true, formats: ['PDF', 'JPG', 'PNG'] },
        { name: 'Social Impact Statement', required: true, formats: ['PDF', 'DOC', 'DOCX'] },
        { name: 'Financial Records (Last 2 Years)', required: true, formats: ['PDF', 'XLS', 'XLSX'] },
        { name: 'Mission Statement', required: false, formats: ['PDF', 'DOC', 'DOCX'] }
      ],
      'international-ngo': [
        { name: 'Registration Certificate', required: true, formats: ['PDF', 'JPG', 'PNG'] },
        { name: 'International Status Proof', required: true, formats: ['PDF'] },
        { name: 'Activity Report (Annual)', required: true, formats: ['PDF'] },
        { name: 'Funding Sources Documentation', required: false, formats: ['PDF', 'XLS', 'XLSX'] }
      ]
    };
    return docMap[entityType] || [];
  };

  const requiredDocs = getRequiredDocuments();
  const uploadedDocNames = documents?.map(doc => doc.name.toLowerCase()) || [];
  
  const getDocumentStatus = (docName) => {
    const hasUploaded = uploadedDocNames.some(uploaded => 
      uploaded.includes(docName.toLowerCase().split(' ')[0])
    );
    return hasUploaded ? 'uploaded' : 'pending';
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer?.files && e.dataTransfer.files[0]) {
      onUpload(e.dataTransfer.files);
    }
  };

  const handleFileSelect = (e) => {
    if (e.target.files && e.target.files[0]) {
      onUpload(e.target.files);
    }
  };

  const handleCameraCapture = (e) => {
    if (e.target.files && e.target.files[0]) {
      onUpload(e.target.files);
      setShowMobileCapture(false);
    }
  };

  const removeDocument = (docId) => {
    // This would typically call a parent function to remove the document
    console.log('Remove document:', docId);
  };

  const canProceed = () => {
    const requiredDocs = getRequiredDocuments().filter(doc => doc.required);
    return requiredDocs.every(doc => getDocumentStatus(doc.name) === 'uploaded');
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-text-primary mb-2">
          Legal Documentation
        </h2>
        <p className="text-text-secondary">
          Upload the required documents to verify your organization's legal status and eligibility.
        </p>
      </div>

      {/* Document Checklist */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-text-primary">
            Required Documents
          </h3>
          <button
            onClick={() => setShowChecklist(!showChecklist)}
            className="flex items-center space-x-2 text-primary hover:text-primary-700 transition-colors"
          >
            <Icon name="List" size={16} />
            <span className="text-sm">View Checklist</span>
            <Icon name={showChecklist ? 'ChevronUp' : 'ChevronDown'} size={14} />
          </button>
        </div>

        {showChecklist && (
          <div className="bg-surface rounded-lg border border-border p-6 mb-6">
            <div className="space-y-4">
              {requiredDocs?.map((doc, index) => {
                const status = getDocumentStatus(doc.name);
                return (
                  <div key={index} className="flex items-center justify-between p-4 bg-white rounded-lg border border-border">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-full ${
                        status === 'uploaded' ?'bg-success-50 text-success' :'bg-surface text-text-muted'
                      }`}>
                        <Icon 
                          name={status === 'uploaded' ? 'CheckCircle2' : 'Circle'} 
                          size={16} 
                        />
                      </div>
                      <div>
                        <h4 className="font-medium text-text-primary">
                          {doc.name}
                          {doc.required && <span className="text-error ml-1">*</span>}
                        </h4>
                        <p className="text-sm text-text-secondary">
                          Formats: {doc.formats.join(', ')}
                        </p>
                      </div>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                      status === 'uploaded' ?'bg-success-50 text-success'
                        : doc.required
                        ? 'bg-error-50 text-error' :'bg-surface text-text-muted'
                    }`}>
                      {status === 'uploaded' ? 'Uploaded' : doc.required ? 'Required' : 'Optional'}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Upload Area */}
      <div className="mb-8">
        <div
          className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200 ${
            dragActive 
              ? 'border-primary bg-primary-50' :'border-border hover:border-primary-200 hover:bg-primary-50/30'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <div className="space-y-4">
            <div className="mx-auto w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center">
              <Icon name="Upload" size={32} className="text-primary" />
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-text-primary mb-2">
                Drop files here or click to browse
              </h3>
              <p className="text-text-secondary mb-4">
                Supports PDF, JPG, PNG, DOC, DOCX, XLS, XLSX files up to 10MB each
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="btn-primary px-6 py-3 flex items-center space-x-2 justify-center"
              >
                <Icon name="FolderOpen" size={16} />
                <span>Browse Files</span>
              </button>
              
              <button
                onClick={() => cameraInputRef.current?.click()}
                className="border border-border text-text-primary px-6 py-3 rounded-lg hover:bg-surface transition-colors flex items-center space-x-2 justify-center"
              >
                <Icon name="Camera" size={16} />
                <span>Take Photo</span>
              </button>
            </div>
          </div>
          
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx"
            onChange={handleFileSelect}
            className="hidden"
          />
          
          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleCameraCapture}
            className="hidden"
          />
        </div>
        
        {/* Upload Progress */}
        {uploadProgress > 0 && uploadProgress < 100 && (
          <div className="mt-4 p-4 bg-primary-50 rounded-lg border border-primary-100">
            <div className="flex items-center space-x-3 mb-2">
              <Icon name="Upload" size={16} className="text-primary" />
              <span className="text-sm font-medium text-primary">Uploading...</span>
              <span className="text-sm text-primary">{uploadProgress}%</span>
            </div>
            <div className="w-full bg-primary-100 rounded-full h-2">
              <div
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Uploaded Documents List */}
      {documents && documents.length > 0 && (
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-text-primary mb-4">
            Uploaded Documents ({documents.length})
          </h3>
          <div className="space-y-3">
            {documents.map((doc, index) => (
              <div key={doc.id || index} className="flex items-center justify-between p-4 bg-white rounded-lg border border-border hover:shadow-soft transition-shadow">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-full ${
                    doc.status === 'uploaded' ?'bg-success-50 text-success' :'bg-warning-50 text-warning'
                  }`}>
                    <Icon 
                      name={doc.status === 'uploaded' ? 'FileCheck' : 'Loader'} 
                      size={16}
                      className={doc.status === 'uploading' ? 'animate-spin' : ''}
                    />
                  </div>
                  <div>
                    <h4 className="font-medium text-text-primary">{doc.name}</h4>
                    <p className="text-sm text-text-secondary">
                      {formatFileSize(doc.size)} • {doc.type}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                    doc.status === 'uploaded' ?'bg-success-50 text-success' :'bg-warning-50 text-warning'
                  }`}>
                    {doc.status === 'uploaded' ? 'Ready' : 'Processing'}
                  </div>
                  
                  <button
                    onClick={() => removeDocument(doc.id)}
                    className="p-2 text-text-muted hover:text-error hover:bg-error-50 rounded-lg transition-colors"
                  >
                    <Icon name="Trash2" size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Help Tips */}
      <div className="mb-8 p-4 bg-accent-50 rounded-lg border border-accent-100">
        <div className="flex items-start space-x-3">
          <Icon name="Lightbulb" size={20} className="text-accent mt-0.5" />
          <div>
            <h4 className="font-medium text-accent mb-2">Tips for Better Results</h4>
            <ul className="text-sm text-accent-600 space-y-1">
              <li>• Ensure documents are clear and fully visible</li>
              <li>• Use high-quality scans or photos (minimum 300 DPI)</li>
              <li>• Avoid shadows, glare, or blurry images</li>
              <li>• Make sure all text is readable</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-between pt-6 border-t border-border">
        <button
          onClick={() => window.history.back()}
          className="px-6 py-3 text-text-secondary hover:text-text-primary transition-colors flex items-center space-x-2"
        >
          <Icon name="ArrowLeft" size={16} />
          <span>Back to Basic Info</span>
        </button>
        
        <button
          onClick={onNext}
          disabled={!canProceed()}
          className={`px-8 py-3 rounded-lg font-semibold flex items-center space-x-2 transition-all ${
            canProceed()
              ? 'bg-primary text-white hover:bg-primary-700' :'bg-surface text-text-muted cursor-not-allowed'
          }`}
        >
          <span>Continue to Impact Validation</span>
          <Icon name="ArrowRight" size={16} />
        </button>
      </div>
    </div>
  );
};

export default DocumentUpload;