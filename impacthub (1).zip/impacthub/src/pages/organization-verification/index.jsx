// src/pages/organization-verification/index.jsx
import React, { useState, useEffect } from 'react';

import Icon from '../../components/AppIcon';
import ProgressTracker from './components/ProgressTracker';
import EntityTypeSelector from './components/EntityTypeSelector';
import DocumentUpload from './components/DocumentUpload';
import ImpactValidation from './components/ImpactValidation';
import FinalReview from './components/FinalReview';
import StatusUpdates from './components/StatusUpdates';
import HelpCenter from './components/HelpCenter';

const OrganizationVerification = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [verificationData, setVerificationData] = useState({
    entityType: '',
    organizationName: '',
    ein: '',
    documents: [],
    impactData: {
      mission: '',
      metrics: [],
      testimonials: [],
      programs: []
    },
    status: 'in-progress',
    estimatedCompletion: null
  });
  const [showMobileCapture, setShowMobileCapture] = useState(false);
  const [showHelpCenter, setShowHelpCenter] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [validationStatus, setValidationStatus] = useState({});

  const steps = [
    { id: 1, title: 'Basic Information', status: 'current' },
    { id: 2, title: 'Legal Documentation', status: 'pending' },
    { id: 3, title: 'Impact Validation', status: 'pending' },
    { id: 4, title: 'Final Review', status: 'pending' }
  ];

  const entityTypes = [
    {
      id: '501c3',
      title: '501(c)(3) Nonprofit',
      description: 'Charitable organizations exempt from federal income tax',
      icon: 'Heart',
      requirements: ['IRS Determination Letter', 'Form 990', 'State Registration']
    },
    {
      id: 'bcorp',
      title: 'B-Corporation',
      description: 'Certified benefit corporations balancing profit and purpose',
      icon: 'Award',
      requirements: ['B-Corp Certification', 'Articles of Incorporation', 'Impact Report']
    },
    {
      id: 'social-enterprise',
      title: 'Social Enterprise',
      description: 'Organizations using business methods to solve social problems',
      icon: 'Building2',
      requirements: ['Business Registration', 'Social Impact Statement', 'Financial Records']
    },
    {
      id: 'international-ngo',
      title: 'International NGO',
      description: 'Non-governmental organizations operating across borders',
      icon: 'Globe',
      requirements: ['Registration Certificate', 'International Status Proof', 'Activity Report']
    }
  ];

  // Auto-save functionality
  useEffect(() => {
    const autoSaveInterval = setInterval(() => {
      if (verificationData?.organizationName) {
        localStorage.setItem('verification-progress', JSON.stringify(verificationData));
      }
    }, 30000); // Auto-save every 30 seconds

    return () => clearInterval(autoSaveInterval);
  }, [verificationData]);

  // Load saved progress on mount
  useEffect(() => {
    const savedProgress = localStorage.getItem('verification-progress');
    if (savedProgress) {
      try {
        const parsedData = JSON.parse(savedProgress);
        setVerificationData(prev => ({ ...prev, ...parsedData }));
      } catch (error) {
        console.error('Error loading saved progress:', error);
      }
    }
  }, []);

  const handleStepComplete = (stepId) => {
    const updatedSteps = steps.map(step => {
      if (step.id === stepId) {
        return { ...step, status: 'completed' };
      } else if (step.id === stepId + 1) {
        return { ...step, status: 'current' };
      }
      return step;
    });
    
    if (stepId < 4) {
      setCurrentStep(stepId + 1);
    }
  };

  const handleDataUpdate = (field, value) => {
    setVerificationData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleDocumentUpload = (files) => {
    const newDocuments = Array.from(files).map(file => ({
      id: Date.now() + Math.random(),
      name: file.name,
      size: file. size,
      type: file.type,
      uploadDate: new Date().toISOString(),
      status: 'uploading'
    }));
    
    setVerificationData(prev => ({
      ...prev,
      documents: [...prev.documents, ...newDocuments]
    }));
    
    // Simulate upload progress
    let progress = 0;
    const progressInterval = setInterval(() => {
      progress += 10;
      setUploadProgress(progress);
      if (progress >= 100) {
        clearInterval(progressInterval);
        setUploadProgress(0);
        // Mark documents as uploaded
        setVerificationData(prev => ({
          ...prev,
          documents: prev.documents.map(doc => 
            newDocuments.find(newDoc => newDoc.id === doc.id) 
              ? { ...doc, status: 'uploaded' }
              : doc
          )
        }));
      }
    }, 200);
  };

  const handleExpediteReview = () => {
    // Simulate scheduling video call
    const scheduledTime = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours from now
    setVerificationData(prev => ({
      ...prev,
      expediteScheduled: scheduledTime,
      estimatedCompletion: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000) // 3 days
    }));
  };

  const getCurrentStepComponent = () => {
    switch (currentStep) {
      case 1:
        return (
          <EntityTypeSelector
            entityTypes={entityTypes}
            selectedType={verificationData.entityType}
            organizationName={verificationData.organizationName}
            ein={verificationData.ein}
            onTypeSelect={(type) => handleDataUpdate('entityType', type)}
            onNameChange={(name) => handleDataUpdate('organizationName', name)}
            onEinChange={(ein) => handleDataUpdate('ein', ein)}
            onNext={() => handleStepComplete(1)}
          />
        );
      case 2:
        return (
          <DocumentUpload
            entityType={verificationData.entityType}
            documents={verificationData.documents}
            uploadProgress={uploadProgress}
            onUpload={handleDocumentUpload}
            onNext={() => handleStepComplete(2)}
            showMobileCapture={showMobileCapture}
            setShowMobileCapture={setShowMobileCapture}
          />
        );
      case 3:
        return (
          <ImpactValidation
            impactData={verificationData.impactData}
            onDataUpdate={(data) => handleDataUpdate('impactData', data)}
            onNext={() => handleStepComplete(3)}
          />
        );
      case 4:
        return (
          <FinalReview
            verificationData={verificationData}
            onSubmit={() => {
              setVerificationData(prev => ({ ...prev, status: 'submitted' }));
              handleDataUpdate('status', 'submitted');
            }}
            onExpedite={handleExpediteReview}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background pt-20">
      {/* Header Section */}
      <div className="bg-gradient-to-r from-primary-50 to-secondary-50 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Icon name="Shield" size={32} className="text-primary" />
              <h1 className="text-3xl lg:text-4xl font-bold text-text-primary">
                Organization Verification
              </h1>
            </div>
            <p className="text-lg text-text-secondary max-w-3xl mx-auto">
              Streamlined verification process to authenticate your nonprofit or social enterprise 
              and unlock access to discounted software and services.
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Left Sidebar - Progress & Help */}
          <div className="lg:col-span-1 space-y-6">
            <ProgressTracker 
              steps={steps} 
              currentStep={currentStep} 
              onStepClick={(stepId) => stepId <= currentStep && setCurrentStep(stepId)}
            />
            
            <StatusUpdates 
              status={verificationData.status}
              estimatedCompletion={verificationData.estimatedCompletion}
              expediteScheduled={verificationData?.expediteScheduled}
            />
            
            <div className="bg-white rounded-xl shadow-soft border border-border p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Icon name="LifeBuoy" size={20} className="text-primary" />
                <h3 className="font-semibold text-text-primary">Need Help?</h3>
              </div>
              <p className="text-sm text-text-secondary mb-4">
                Get assistance with the verification process.
              </p>
              <button
                onClick={() => setShowHelpCenter(true)}
                className="w-full btn-primary text-sm py-2"
              >
                Open Help Center
              </button>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-xl shadow-soft border border-border overflow-hidden">
              {getCurrentStepComponent()}
            </div>
          </div>
        </div>
      </div>

      {/* Help Center Modal */}
      {showHelpCenter && (
        <HelpCenter onClose={() => setShowHelpCenter(false)} />
      )}

      {/* Mobile-specific features */}
      <div className="lg:hidden fixed bottom-6 right-6 z-50">
        <button
          onClick={() => setShowHelpCenter(true)}
          className="bg-primary text-white p-4 rounded-full shadow-strong hover:bg-primary-700 transition-all duration-300"
        >
          <Icon name="MessageCircle" size={24} />
        </button>
      </div>
    </div>
  );
};

export default OrganizationVerification;