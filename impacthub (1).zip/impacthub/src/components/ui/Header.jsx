import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  const navigationItems = [
    { name: 'Home', path: '/homepage', icon: 'Home' },
    { name: 'Software Catalog', path: '/software-catalog', icon: 'Grid3X3' },
    { name: 'Application Details', path: '/software-detail-application', icon: 'FileText' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const isActivePath = (path) => {
    return location.pathname === path;
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-glass shadow-soft border-b border-border' 
          : 'bg-white/90 backdrop-blur-glass'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link 
            to="/homepage" 
            className="flex items-center space-x-3 group"
            onClick={closeMenu}
          >
            <div className="relative">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center shadow-soft group-hover:shadow-medium transition-all duration-300 group-hover:scale-105">
                <Icon 
                  name="Zap" 
                  size={24} 
                  color="white" 
                  strokeWidth={2.5}
                />
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-accent rounded-full animate-pulse-soft"></div>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-xl lg:text-2xl font-bold text-text-primary group-hover:text-primary transition-colors duration-300">
                ImpactHub
              </h1>
              <p className="text-xs text-text-secondary font-medium">
                Premium Purpose
              </p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navigationItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 hover:bg-surface group ${
                  isActivePath(item.path)
                    ? 'text-primary bg-primary-50 shadow-soft'
                    : 'text-text-secondary hover:text-text-primary'
                }`}
              >
                <Icon 
                  name={item.icon} 
                  size={18} 
                  className={`transition-colors duration-300 ${
                    isActivePath(item.path) ? 'text-primary' : 'text-text-muted group-hover:text-text-primary'
                  }`}
                />
                <span>{item.name}</span>
              </Link>
            ))}
          </nav>

          {/* CTA Buttons - Desktop */}
          <div className="hidden lg:flex items-center space-x-3">
            <button className="px-4 py-2 text-sm font-semibold text-text-secondary hover:text-primary transition-colors duration-300 hover:bg-surface rounded-lg">
              Sign In
            </button>
            <button className="btn-primary text-sm px-6 py-2.5 hover:transform hover:scale-105 transition-all duration-300">
              Get Started
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="lg:hidden p-2 rounded-lg text-text-secondary hover:text-text-primary hover:bg-surface transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
            aria-label="Toggle menu"
          >
            <Icon 
              name={isMenuOpen ? "X" : "Menu"} 
              size={24} 
              className="transition-transform duration-300"
            />
          </button>
        </div>

        {/* Mobile Navigation */}
        <div 
          className={`lg:hidden transition-all duration-300 ease-smooth ${
            isMenuOpen 
              ? 'max-h-96 opacity-100 pb-6' :'max-h-0 opacity-0 overflow-hidden'
          }`}
        >
          <nav className="flex flex-col space-y-2 pt-4 border-t border-border">
            {navigationItems.map((item, index) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={closeMenu}
                className={`flex items-center space-x-3 px-4 py-3 rounded-lg text-base font-medium transition-all duration-300 hover:bg-surface group animate-slide-down ${
                  isActivePath(item.path)
                    ? 'text-primary bg-primary-50 shadow-soft'
                    : 'text-text-secondary hover:text-text-primary'
                }`}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <Icon 
                  name={item.icon} 
                  size={20} 
                  className={`transition-colors duration-300 ${
                    isActivePath(item.path) ? 'text-primary' : 'text-text-muted group-hover:text-text-primary'
                  }`}
                />
                <span>{item.name}</span>
              </Link>
            ))}
            
            {/* Mobile CTA Buttons */}
            <div className="flex flex-col space-y-3 pt-4 border-t border-border">
              <button className="w-full px-4 py-3 text-base font-semibold text-text-secondary hover:text-primary transition-colors duration-300 hover:bg-surface rounded-lg text-left">
                Sign In
              </button>
              <button className="btn-primary w-full text-base py-3 hover:transform hover:scale-105 transition-all duration-300">
                Get Started
              </button>
            </div>
          </nav>
        </div>
      </div>

      {/* Impact Metrics Bar */}
      <div className={`bg-gradient-to-r from-primary-50 to-secondary-50 border-t border-border transition-all duration-300 ${
        isScrolled ? 'opacity-0 max-h-0 overflow-hidden' : 'opacity-100 max-h-16'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center lg:justify-between py-2 text-sm">
            <div className="flex items-center space-x-6 text-text-secondary">
              <div className="flex items-center space-x-2">
                <Icon name="Users" size={16} className="text-primary" />
                <span className="font-medium">2,847 Organizations Served</span>
              </div>
              <div className="hidden sm:flex items-center space-x-2">
                <Icon name="DollarSign" size={16} className="text-secondary" />
                <span className="font-medium">$12.4M Total Savings</span>
              </div>
              <div className="hidden lg:flex items-center space-x-2">
                <Icon name="TrendingUp" size={16} className="text-accent" />
                <span className="font-medium">94% Success Rate</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;