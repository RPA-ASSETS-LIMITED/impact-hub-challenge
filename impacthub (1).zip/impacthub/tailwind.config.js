/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Primary Colors
        'primary': '#1E3A8A', // Deep trust blue - blue-800
        'primary-50': '#EFF6FF', // Light blue background - blue-50
        'primary-100': '#DBEAFE', // Light blue shade - blue-100
        'primary-500': '#3B82F6', // Medium blue - blue-500
        'primary-600': '#2563EB', // Brand blue - blue-600
        'primary-700': '#1D4ED8', // Dark blue - blue-700
        'primary-900': '#1E3A8A', // Deep blue primary - blue-900

        // Secondary Colors
        'secondary': '#059669', // Growth green - emerald-600
        'secondary-50': '#ECFDF5', // Light green background - emerald-50
        'secondary-100': '#D1FAE5', // Light green shade - emerald-100
        'secondary-500': '#10B981', // Medium green - emerald-500
        'secondary-600': '#059669', // Secondary green - emerald-600
        'secondary-700': '#047857', // Dark green - emerald-700

        // Accent Colors
        'accent': '#F97316', // Achievement orange - orange-500
        'accent-50': '#FFF7ED', // Light orange background - orange-50
        'accent-100': '#FFEDD5', // Light orange shade - orange-100
        'accent-400': '#FB923C', // Medium orange - orange-400
        'accent-500': '#F97316', // Accent orange - orange-500
        'accent-600': '#EA580C', // Dark orange - orange-600

        // Background Colors
        'background': '#FAFAFA', // Clean canvas - gray-50
        'surface': '#F1F5F9', // Subtle elevation - slate-100
        'surface-hover': '#E2E8F0', // Surface hover - slate-200

        // Text Colors
        'text-primary': '#1F2937', // Primary text - gray-800
        'text-secondary': '#6B7280', // Secondary text - gray-500
        'text-muted': '#9CA3AF', // Muted text - gray-400

        // Status Colors
        'success': '#10B981', // Success green - emerald-500
        'success-50': '#ECFDF5', // Success background - emerald-50
        'success-100': '#D1FAE5', // Success light - emerald-100

        'warning': '#F59E0B', // Warning amber - amber-500
        'warning-50': '#FFFBEB', // Warning background - amber-50
        'warning-100': '#FEF3C7', // Warning light - amber-100

        'error': '#EF4444', // Error red - red-500
        'error-50': '#FEF2F2', // Error background - red-50
        'error-100': '#FEE2E2', // Error light - red-100

        // Trust Builder
        'trust': '#6366F1', // Trust indigo - indigo-500
        'trust-50': '#EEF2FF', // Trust background - indigo-50
        'trust-100': '#E0E7FF', // Trust light - indigo-100

        // Conversion Colors
        'conversion': '#DC2626', // Conversion red - red-600
        'conversion-50': '#FEF2F2', // Conversion background - red-50
        'conversion-100': '#FEE2E2', // Conversion light - red-100

        // Border Colors
        'border': '#E5E7EB', // Border gray - gray-200
        'border-light': '#F3F4F6', // Light border - gray-100
        'border-dark': '#D1D5DB', // Dark border - gray-300
      },
      fontFamily: {
        'sans': ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        'serif': ['Crimson Text', 'serif'],
        'accent': ['Crimson Text', 'serif'],
      },
      fontSize: {
        'xs': ['0.75rem', { lineHeight: '1rem' }],
        'sm': ['0.875rem', { lineHeight: '1.25rem' }],
        'base': ['1rem', { lineHeight: '1.5rem' }],
        'lg': ['1.125rem', { lineHeight: '1.75rem' }],
        'xl': ['1.25rem', { lineHeight: '1.75rem' }],
        '2xl': ['1.5rem', { lineHeight: '2rem' }],
        '3xl': ['1.875rem', { lineHeight: '2.25rem' }],
        '4xl': ['2.25rem', { lineHeight: '2.5rem' }],
        '5xl': ['3rem', { lineHeight: '1.2' }],
        '6xl': ['3.75rem', { lineHeight: '1.2' }],
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
        '128': '32rem',
      },
      borderRadius: {
        'xl': '0.75rem',
        '2xl': '1rem',
        '3xl': '1.5rem',
      },
      boxShadow: {
        'soft': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        'medium': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
        'strong': '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
        'glass': '0 4px 20px rgba(0, 0, 0, 0.08)',
        'card': '0 4px 20px rgba(0, 0, 0, 0.08)',
        'elevated': '0 8px 40px rgba(0, 0, 0, 0.12)',
        'hero': '0 12px 60px rgba(0, 0, 0, 0.16)',
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease-out',
        'slide-up': 'slideUp 0.4s ease-out',
        'slide-down': 'slideDown 0.4s ease-out',
        'scale-in': 'scaleIn 0.3s ease-out',
        'pulse-soft': 'pulseSoft 3s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
        'gradient-shift': 'gradientShift 8s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(40px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        slideDown: {
          '0%': { transform: 'translateY(-40px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        scaleIn: {
          '0%': { transform: 'scale(0.95)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
        pulseSoft: {
          '0%, 100%': { transform: 'scale(1)', opacity: '0.7' },
          '50%': { transform: 'scale(1.1)', opacity: '1' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        gradientShift: {
          '0%, 100%': { backgroundPosition: '0% 50%' },
          '50%': { backgroundPosition: '100% 50%' },
        },
      },
      transitionTimingFunction: {
        'smooth': 'cubic-bezier(0.4, 0, 0.2, 1)',
        'bounce-soft': 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
      },
      backdropBlur: {
        'glass': '10px',
      },
      zIndex: {
        '60': '60',
        '70': '70',
        '80': '80',
        '90': '90',
        '100': '100',
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
    require('@tailwindcss/aspect-ratio'),
  ],
}